﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AsistenBendahara.Lain_Lain
{
    
    public partial class UCApproval : UserControl
    {
       

        public UCApproval()
        {
            InitializeComponent();
        }

        private DataTable LoadDataRequest()
        {
            string con = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
            DataTable tbl = new DataTable();
            SqlConnection sqlconnect = new SqlConnection(con);
            SqlCommand command;
            SqlDataAdapter sqldata;

            sqlconnect.Open();
            command = new SqlCommand("sp_LoadDataRequest", sqlconnect);
            sqldata = new SqlDataAdapter(command);
            command.CommandType = CommandType.StoredProcedure;
            sqldata.Fill(tbl);
            sqlconnect.Close();

            return tbl;
        }

        private void UCApproval_Load(object sender, EventArgs e)
        {
            loadtbl();
        }

        public void loadtbl()
        {
            dgPermintaan.DataSource = null;
            dgPermintaan.DataSource = LoadDataRequest();

            this.dgPermintaan.Columns["permintaan_id"].Visible = false;
            this.dgPermintaan.Columns["acara_id"].Visible = false;
            this.dgPermintaan.Columns["user_id"].Visible = false;
            this.dgPermintaan.Columns["Budget"].DefaultCellStyle.Format = "C0";
            this.dgPermintaan.Columns["Jumlah Permintaan"].DefaultCellStyle.Format = "C0";
        }

        String idAcara = "";
        
        private void clear()
        {
            txtNama.Text = "";
            txtNamaAcara.Text = "";
            txtSisaBudget.Text = "";
            txtKeterangan.Text = "";
            txtJumlahPengeluaran.Text = "";

            idAcara = "";
        }

        private void dgPermintaan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            foreach(DataGridViewRow row in dgPermintaan.SelectedRows)
            {
                try
                {
                    idAcara = row.Cells[1].Value.ToString();
                    txtNamaAcara.Text = row.Cells[3].Value.ToString();

                }
                catch
                {

                }
            }
        }

        private void txtKeterangan_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNamaAcara_TextChanged(object sender, EventArgs e)
        {

        }

        private void dtTglRequest_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtJumlahPengeluaran_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNama_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgPermintaan_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnBayar_Click(object sender, EventArgs e)
        {
            string connectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand insert = new SqlCommand("sp_Approval", connection);

            insert.CommandType = CommandType.StoredProcedure;
            try
            {
                if (txtNama.Text == "" || txtJumlahPengeluaran.Text == "" || txtKeterangan.Text == "")
                {
                    MessageBox.Show(this, "Data Tidak Boleh Kosong!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {

                    insert.Parameters.AddWithValue("dtl_id", generateID());
                    insert.Parameters.AddWithValue("acara_id", acara_ID);
                    insert.Parameters.AddWithValue("user_id", user_ID);
                    insert.Parameters.AddWithValue("dtl_jumlah", ToTrimmedString(tagihan));
                    insert.Parameters.AddWithValue("dtl_tanggal", DateTime.Now.ToString("yyyy-MM-dd"));
                    insert.Parameters.AddWithValue("dtl_keterangan", txtKeterangan.Text);
                    insert.Parameters.AddWithValue("permintaan_id", permintaan_id);
                    try
                    {
                        connection.Open();
                        insert.ExecuteNonQuery();
                        MessageBox.Show(this, "Data berhasil disimpan", "Information",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //LoadFormUser();
                        loadtbl();
                        clear();


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Tidak berhasil disimpan!: " + ex.Message);
                    }
                }
            }
            catch
            {
                MessageBox.Show(this, "Data Tidak Boleh Kosong!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public static string ToTrimmedString(string target)
        {
            string strValue = target.ToString(); //Get the stock string

            //If there is a decimal point present
            if (strValue.Contains(","))
            {
                //Remove all trailing zeros
                strValue = strValue.TrimEnd('0');

                //If all we are left with is a decimal point
                if (strValue.EndsWith(",")) //then remove it
                    strValue = strValue.TrimEnd(',');
            }

            return strValue;
        }
        public string generateID()
        {
            return Guid.NewGuid().ToString("N");
        }

        string acara_ID, user_ID, tagihan, budget,permintaan_id;
        private void dgPermintaan_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            foreach (DataGridViewRow row in dgPermintaan.SelectedRows)
            {
                try
                {
                    permintaan_id = row.Cells[0].Value.ToString();
                    acara_ID = row.Cells[1].Value.ToString();
                    user_ID = row.Cells[2].Value.ToString();
                    txtNamaAcara.Text = row.Cells[3].Value.ToString();
                    budget= row.Cells[4].Value.ToString();
                    txtNama.Text = row.Cells[5].Value.ToString();
                    tagihan = row.Cells[6].Value.ToString();
                    txtKeterangan.Text = row.Cells[7].Value.ToString();

                } 
                catch
                {

                }
                

                decimal moneyvalue = decimal.Parse(budget);
                txtSisaBudget.Text = String.Format("{0:C} ", moneyvalue);

                decimal moneyvalue2 = decimal.Parse(tagihan);
                txtJumlahPengeluaran.Text = String.Format("{0:C} ", moneyvalue2);

            }
        }
    }
}
