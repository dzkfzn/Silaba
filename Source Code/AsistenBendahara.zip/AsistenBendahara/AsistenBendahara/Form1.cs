﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsistenBendahara
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'zPemasukan.DataTable1' table. You can move, or remove it, as needed.
            
            // TODO: This line of code loads data into the 'zPemasukan.DataTable3' table. You can move, or remove it, as needed.
            
            //// TODO: This line of code loads data into the 'zPemasukan.DataTable1' table. You can move, or remove it, as needed.
            //this.DataTable1TableAdapter.Fill(this.zPemasukan.DataTable1);
            //// TODO: This line of code loads data into the 'zPemasukan.DataTable1' table. You can move, or remove it, as needed.

            //// TODO: This line of code loads data into the 'ReportBaru.DataTable1' table. You can move, or remove it, as needed.
            //// this.DataTable1TableAdapter.Fill(this.ReportBaru.DataTable1);
            //// TODO: This line of code loads data into the 'ReportBaru.DataTable2' table. You can move, or remove it, as needed.

            //this.reportViewer1.RefreshReport();
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
          //  this.DataTable3TableAdapter.Fill(this.zPemasukan.DataTable3, dtTglMulai.Value.ToShortDateString(), dtTglAkhir.Value.ToShortDateString());

            this.reportViewer1.RefreshReport();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
