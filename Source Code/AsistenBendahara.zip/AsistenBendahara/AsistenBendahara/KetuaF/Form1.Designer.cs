﻿namespace AsistenBendahara.Ketua
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ms_userTableAdapter1 = new AsistenBendahara.ACARA_NAMA_IDTableAdapters.ms_userTableAdapter();
            this.requestPengeluaran1 = new AsistenBendahara.Transaksi.requestPengeluaran();
            this.SuspendLayout();
            // 
            // ms_userTableAdapter1
            // 
            this.ms_userTableAdapter1.ClearBeforeFill = true;
            // 
            // requestPengeluaran1
            // 
            this.requestPengeluaran1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.requestPengeluaran1.Location = new System.Drawing.Point(0, 3);
            this.requestPengeluaran1.Name = "requestPengeluaran1";
            this.requestPengeluaran1.Size = new System.Drawing.Size(1116, 608);
            this.requestPengeluaran1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 525);
            this.Controls.Add(this.requestPengeluaran1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private ACARA_NAMA_IDTableAdapters.ms_userTableAdapter ms_userTableAdapter1;
        private Transaksi.requestPengeluaran requestPengeluaran1;
    }
}