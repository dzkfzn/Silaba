﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace AsistenBendahara.Lain_Lain
{
    public partial class Ketua : Form
    {
        public Ketua()
        {
            InitializeComponent();
        }

        private void metroLabel2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
       
        }

        private void label2_Click(object sender, EventArgs e)
        {
           
        }

        private void label5_Click(object sender, EventArgs e)
        {
            
        }

        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void metroLabel4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            this.Hide();
            testReport a = new testReport();
            a.Show();
        }

        private void Menu_Utama_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            mostrarlogo();
            username = Lain_Lain.Login.passingNama;
            lblNama.Text = username;
        }
        string username;

        private void btnSlide_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Apakah Yakin Ingin Keluar?", "Peringatan", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                //tus codigos
                Application.Exit();
            }
            else {
                //tus codigos
            }
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnmenu_Click(object sender, EventArgs e)
        {
            if (panelKiri.Width == 250)
            {
                panelKiri.Width = 57;
                panelKiri.Enabled = false;
            }
            else
            {
                panelKiri.Width = 250;
                panelKiri.Enabled = true;
            }
        }

        private void AbrirFormInPanel(object formHijo)
        {
            // if (this.panelUtama.Controls.Count > 0)
            //     this.panelUtama.Controls.RemoveAt(0);
           // UserControl fh = formHijo as UserControl;
            UserControl fh = formHijo as UserControl;
           // fh.TopLevel = false;
           // fh.FormBorderStyle = FormBorderStyle.None;
            fh.Dock = DockStyle.Fill;
            //fh.Location = new Point(250, 47);
           
            this.panelUtama.Controls.Add(fh);
            this.panelUtama.Tag = fh;
            fh.Show();
            fh.BringToFront();
        }
        private void mostrarlogo()
        {
            AbrirFormInPanel(new Lain_Lain.LOGI_UC());
            panelBawah.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblHora.Text = DateTime.Now.ToString("hh:mm:ss");
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }

        private void panelAtas_MouseMove(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        int t1 = 40;
        int t2 = 40;
        int t3 = 40;
        int t4 = 40;
        int t5 = 40;

        private void btnKelAcara_MouseHover(object sender, EventArgs e)
        {
      
        }

        private void btnKelAcara_MouseLeave(object sender, EventArgs e)
        {
            timer2.Stop();
            t1 = 40;
           
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
   
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
        
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
    
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            if (t4 > 225)
            { timer5.Stop(); }
            else
            {
                this.panel4.Size = new Size(this.panel4.Size.Width, t4);
                t4 += 100;
            }
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            if (t5 > 225)
            { timer6.Stop(); }
            else
            {
                this.panel5.Size = new Size(this.panel5.Size.Width, t5);
                t5 += 100;
            }
        }

        private void btnPemasukan_MouseHover(object sender, EventArgs e)
        {
       
        }

        private void btnPemasukan_MouseLeave(object sender, EventArgs e)
        {
            timer3.Stop();
            t2 = 40;

        }

        private void panel1_MouseLeave(object sender, EventArgs e)
        {
           
        }

        private void panelUtama_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_MouseLeave(object sender, EventArgs e)
        {
            
        }

        private void panel3_MouseLeave(object sender, EventArgs e)
        {
            
        }

        private void panel4_MouseLeave(object sender, EventArgs e)
        {
          
        }

        private void panel5_MouseLeave(object sender, EventArgs e)
        {
           
        }

        private void btnPengeluaran_MouseHover(object sender, EventArgs e)
        {
           
        }

        private void btnTagihan_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void btnLaporan_MouseHover(object sender, EventArgs e)
        {
          
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Apakah Yakin Ingin Logout?", "Peringatan", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Hide();
                Lain_Lain.Login a = new Lain_Lain.Login();
                a.Show();
            }
            else {
                //tus codigos
            }
        }

        private void btnUser_Click(object sender, EventArgs e)
        {

            //Master.UCmasterAcara frm = new Master.UCmasterAcara();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            //AbrirFormInPanel(frm);


            Transaksi.UCtrTambahAnggotaAcara frm = new Transaksi.UCtrTambahAnggotaAcara();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void btnKelAcara_Click(object sender, EventArgs e)
        {
            Master.UCmasterAnggota frm = new Master.UCmasterAnggota();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Lain_Lain.LOGI_UC frm = new Lain_Lain.LOGI_UC();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void panelKiri_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnTagihan_Click(object sender, EventArgs e)
        {
             Transaksi.requestPengeluaran frm= new Transaksi.requestPengeluaran();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void btnLaporan_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LapPemasukan frm = new LapPemasukan();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LapPengeluaran frm = new LapPengeluaran();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }
    }
}
