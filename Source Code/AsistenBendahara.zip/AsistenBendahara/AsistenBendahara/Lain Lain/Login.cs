﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsistenBendahara.Lain_Lain
{
    public partial class Login : Form
    {

        public static string passingUsername;
        public static string passingNama;
        public static string passingRole;
        public static string passingidUser;
        public Login()
        {
            InitializeComponent();
           // label2.Hide();
        }


        public void login()
        {
            int tampungRole = 0;
            string connectionstring =
            "integrated security = true; data source = .; initial catalog = PRG2_SILABI";
            SqlConnection myConnection = new SqlConnection(connectionstring);

            SqlCommand search = new SqlCommand("sp_Login", myConnection);
            search.CommandType = CommandType.StoredProcedure;

            search.Parameters.AddWithValue("username", txtUsername.Text);
            search.Parameters.AddWithValue("password", txtPassword.Text);

            usernamelogin = txtUsername.Text;
            try
            {

                try
                {
                    using (Lain_Lain.DataClasses1DataContext context = new Lain_Lain.DataClasses1DataContext())
                    {
                        Lain_Lain.ms_user prodi = context.ms_users.Single(ms_user => ms_user.user_username == txtUsername.Text);

                        passingNama = prodi.user_nama;
                        passingRole = prodi.role_id;
                        passingidUser = prodi.user_id;
                    }
                }

                catch
                {
                   
                }
                myConnection.Open();
                SqlDataReader reader = search.ExecuteReader();
                while (reader.Read())
                {
                    tampungRole = Convert.ToInt32(reader[0]);
                }
                myConnection.Close();

                if (tampungRole == 1)
                {
                    passingUsername = txtUsername.Text;
                    this.Hide();
                    Lain_Lain.Menu_Utama Admin = new Lain_Lain.Menu_Utama();
                    Admin.Show();
                }
                else if ((tampungRole == 2))
                {
                    passingUsername = txtUsername.Text;
                    this.Hide();
                    Lain_Lain.anggota Admin = new Lain_Lain.anggota();
                    Admin.Show();

                } else if(tampungRole == 3)
                {
                    passingUsername = txtUsername.Text;
                    this.Hide();
                    Lain_Lain.Admin Admin = new Lain_Lain.Admin();
                    Admin.Show();
                }
                else if (tampungRole == 4)
                {
                    passingUsername = txtUsername.Text;
                    this.Hide();
                    Lain_Lain.Ketua Admin = new Lain_Lain.Ketua();
                    Admin.Show();
                }

                else
                {
                    MessageBox.Show("Username atau Password salah!", "Login gagal",
                           MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Username atau Password salah!", "Login gagal",
                           MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public string usernamelogin;
        private void button1_Click(object sender, EventArgs e)
        {
            login();
            
        }

        private void Login_Load(object sender, EventArgs e)
        {
            textBox1.Select();
            this.AcceptButton = button1;
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {
            login();
        }

        private void txtUsername_Click(object sender, EventArgs e)
        {
            
        }

        private void txtPassword_Click(object sender, EventArgs e)
        {
            
        }

        private void txtPassword_Leave(object sender, EventArgs e)
        {
            if (txtPassword.Text == "")
            {
                txtPassword.PasswordChar = '\0';
                txtPassword.Text = "password";
            }
        }

        private void txtUsername_Leave(object sender, EventArgs e)
        {
            if (txtUsername.Text == "")
            {
                txtUsername.PasswordChar = '\0';
                txtUsername.Text = "username";
            }
        }

        private void txtUsername_Enter(object sender, EventArgs e)
        {
            if (txtUsername.Text == "username")
                txtUsername.Text = "";
        }

        private void txtPassword_Enter(object sender, EventArgs e)
        {
            if (txtPassword.Text == "password")
                txtPassword.Text = "";
            if (txtPassword.Text == "password")
            {
                //nothing
            }
            else
            {
                txtPassword.PasswordChar = '*';
            }
        }

        private void rectangleShape4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
