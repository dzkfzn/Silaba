﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace AsistenBendahara.Lain_Lain
{
    public partial class Menu_Utama : Form
    {
        public Menu_Utama()
        {
            InitializeComponent();
        }

        private void metroLabel2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
           
        }

        private void label5_Click(object sender, EventArgs e)
        {
          
        }

        private void label4_Click(object sender, EventArgs e)
        {
           
        }

        private void label3_Click(object sender, EventArgs e)
        {
           
        }

        private void metroLabel4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            this.Hide();
            testReport a = new testReport();
            a.Show();
        }

        private void Menu_Utama_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            mostrarlogo();
            username = Lain_Lain.Login.passingNama;
            lblNama.Text = username;
        }
        string username;

        private void btnSlide_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Apakah Yakin Ingin Keluar?", "Peringatan", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                //tus codigos
                Application.Exit();
            }
            else {
                //tus codigos
            }
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]

        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnmenu_Click(object sender, EventArgs e)
        {
            if (panelKiri.Width == 250)
            {
                panelKiri.Width = 57;
                panelKiri.Enabled = false;
            }
            else
            {
                panelKiri.Width = 250;
                panelKiri.Enabled = true;
            }
        }

        private void AbrirFormInPanel(object formHijo)
        {
            // if (this.panelUtama.Controls.Count > 0)
            //     this.panelUtama.Controls.RemoveAt(0);
           // UserControl fh = formHijo as UserControl;
            UserControl fh = formHijo as UserControl;
           // fh.TopLevel = false;
           // fh.FormBorderStyle = FormBorderStyle.None;
            fh.Dock = DockStyle.Fill;
            //fh.Location = new Point(250, 47);
           
            this.panelUtama.Controls.Add(fh);
            this.panelUtama.Tag = fh;
            fh.Show();
            fh.BringToFront();
        }
        private void AbrirFormInPanelUC(object formHijo)
        {
             if (this.panelUtama.Controls.Count > 0)
                 this.panelUtama.Controls.RemoveAt(0);
             Form fh = formHijo as Form;
           // UserControl fh = formHijo as UserControl;
             fh.TopLevel = false;
             fh.FormBorderStyle = FormBorderStyle.None;
            //fh.Dock = DockStyle.Fill;
            //fh.Location = new Point(250, 47);

            this.panelUtama.Controls.Add(fh);
            this.panelUtama.Tag = fh;
            fh.Show();
            fh.BringToFront();
        }
        private void mostrarlogo()
        {
            AbrirFormInPanel(new Lain_Lain.LOGI_UC());
            panelBawah.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblHora.Text = DateTime.Now.ToString("hh:mm:ss");
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }

        private void panelAtas_MouseMove(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        int t1 = 40;
        int t2 = 40;
        int t3 = 40;
        int t4 = 40;
        int t5 = 40;

        private void btnKelAcara_MouseHover(object sender, EventArgs e)
        {
            this.panel2.Size = new Size(this.panel2.Size.Width, t2);
            this.panel3.Size = new Size(this.panel3.Size.Width, t3);
            this.panel4.Size = new Size(this.panel4.Size.Width, t4);
            this.panel5.Size = new Size(this.panel5.Size.Width, t5);
            this.panel1.BringToFront();
            timer2.Start();
        }

        private void btnKelAcara_MouseLeave(object sender, EventArgs e)
        {
            timer2.Stop();
            t1 = 40;
           
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (t1 > 225)
            { timer2.Stop(); }
            else
            {
                this.panel1.Size = new Size(this.panel1.Size.Width, t1);
                t1 += 100;
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (t2 > 225)
            { timer3.Stop(); }
            else
            {
                this.panel2.Size = new Size(this.panel2.Size.Width, t2);
                t2 += 100;
            }
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            if (t3 > 225)
            { timer4.Stop(); }
            else
            {
                this.panel3.Size = new Size(this.panel3.Size.Width, t3);
                t3 += 100;
            }
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            if (t4 > 225)
            { timer5.Stop(); }
            else
            {
                this.panel4.Size = new Size(this.panel4.Size.Width, t4);
                t4 += 100;
            }
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            if (t5 > 225)
            { timer6.Stop(); }
            else
            {
                this.panel5.Size = new Size(this.panel5.Size.Width, t5);
                t5 += 100;
            }
        }

        private void btnPemasukan_MouseHover(object sender, EventArgs e)
        {
            this.panel1.Size = new Size(this.panel1.Size.Width, t1);
            this.panel3.Size = new Size(this.panel3.Size.Width, t3);
            this.panel4.Size = new Size(this.panel3.Size.Width, t4);
            this.panel5.Size = new Size(this.panel3.Size.Width, t5);
            this.panel2.BringToFront();
            timer3.Start();
        }

        private void btnPemasukan_MouseLeave(object sender, EventArgs e)
        {
            timer3.Stop();
            t2 = 40;

        }

        private void panel1_MouseLeave(object sender, EventArgs e)
        {
            timer2.Stop();
            t1 = 40;
            this.panel1.Size = new Size(this.panel1.Size.Width, t1);
        }

        private void panelUtama_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_MouseLeave(object sender, EventArgs e)
        {
            timer3.Stop();
            t2 = 40;
            this.panel2.Size = new Size(this.panel2.Size.Width, t2);
        }

        private void panel3_MouseLeave(object sender, EventArgs e)
        {
            timer4.Stop();
            t3 = 40;
            this.panel3.Size = new Size(this.panel3.Size.Width, t3);
        }

        private void panel4_MouseLeave(object sender, EventArgs e)
        {
            timer5.Stop();
            t4 = 40;
            this.panel4.Size = new Size(this.panel4.Size.Width, t4);
        }

        private void panel5_MouseLeave(object sender, EventArgs e)
        {
            timer6.Stop();
            t5 = 40;
            this.panel5.Size = new Size(this.panel5.Size.Width, t5);
        }

        private void btnPengeluaran_MouseHover(object sender, EventArgs e)
        {
            this.panel1.Size = new Size(this.panel1.Size.Width, t1);
            this.panel2.Size = new Size(this.panel2.Size.Width, t2);
            this.panel4.Size = new Size(this.panel3.Size.Width, t4);
            this.panel5.Size = new Size(this.panel3.Size.Width, t5);
            this.panel3.BringToFront();
            timer4.Start();
        }

        private void btnTagihan_MouseHover(object sender, EventArgs e)
        {
            this.panel1.Size = new Size(this.panel1.Size.Width, t1);
            this.panel2.Size = new Size(this.panel2.Size.Width, t2);
            this.panel3.Size = new Size(this.panel3.Size.Width, t3);
            this.panel5.Size = new Size(this.panel3.Size.Width, t5);
            this.panel4.BringToFront();
            timer5.Start();
        }

        private void btnLaporan_MouseHover(object sender, EventArgs e)
        {
            this.panel1.Size = new Size(this.panel1.Size.Width, t1);
            this.panel2.Size = new Size(this.panel2.Size.Width, t2);
            this.panel3.Size = new Size(this.panel3.Size.Width, t3);
            this.panel4.Size = new Size(this.panel3.Size.Width, t4);
            this.panel5.BringToFront();
            timer6.Start();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Apakah Yakin Ingin Logout?", "Peringatan", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Hide();
                Lain_Lain.Login a = new Lain_Lain.Login();
                a.Show();
            }
            else {
                //tus codigos
            }
        }

        private void btnUser_Click(object sender, EventArgs e)
        {


            
        }

        private void btnKelAcara_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Lain_Lain.LOGI_UC frm = new Lain_Lain.LOGI_UC();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void btnTagihan3Bayar_Click(object sender, EventArgs e)
        {
            Transaksi.UCtrTagihanAdminView frm = new Transaksi.UCtrTagihanAdminView();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void btnPemasukan2Lihat_Click(object sender, EventArgs e)
        {
            Transaksi.UCLihatPemasukan frm = new Transaksi.UCLihatPemasukan();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void next_Click(object sender, EventArgs e)
        {
            if (panelBawah.Height == 0)
            {
                panelBawah.Height = 110;
                back.Visible = true;
                next.Visible = false;
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            if (panelBawah.Height == 110)
            {
                panelBawah.Height = 0;
                back.Visible = false;
                next.Visible = true;
                next.BringToFront();
            }
        }

        private void btnKelAcara2_Click(object sender, EventArgs e)
        {
            Master.UCmasterAcara frm = new Master.UCmasterAcara();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void btnKelAcara3anggotaAcara_Click(object sender, EventArgs e)
        {
            Transaksi.UCtrTambahAnggotaAcara frm = new Transaksi.UCtrTambahAnggotaAcara();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void btnTagihan2Lihat_Click(object sender, EventArgs e)
        {
            Transaksi.UCLihatTagihan frm = new Transaksi.UCLihatTagihan();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void btnPemasukan3Input_Click(object sender, EventArgs e)
        {
            Transaksi.UCtrPemasukanAcara frm = new Transaksi.UCtrPemasukanAcara();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void btnPengeluaran2Input_Click(object sender, EventArgs e)
        {
            Transaksi_Bendahara.UCLihatPengeluaran frm = new Transaksi_Bendahara.UCLihatPengeluaran();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void btnPengeluaran3Input_Click(object sender, EventArgs e)
        {
            Transaksi.PengeluaranAcara frm = new Transaksi.PengeluaranAcara();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void btnLaporan3Pengeluaran_Click(object sender, EventArgs e)
        {
            LapPengeluaran frm = new LapPengeluaran();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void btnLaporan2Pemasukan_Click(object sender, EventArgs e)
        {
            LapPemasukan frm = new LapPemasukan();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UCApproval frm = new UCApproval();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            about frm = new about();
            //frm. += new FormClosedEventHandler(mostrarlogoAlCerrarForm);
            AbrirFormInPanel(frm);
        }
    }
}
