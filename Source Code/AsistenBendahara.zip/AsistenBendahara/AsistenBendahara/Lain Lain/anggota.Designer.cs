﻿namespace AsistenBendahara.Lain_Lain
{
    partial class anggota
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(anggota));
            this.panelKiri = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnLaporan = new System.Windows.Forms.Button();
            this.btnLaporan3Pengeluaran = new System.Windows.Forms.Button();
            this.btnLaporan2Pemasukan = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnTagihan = new System.Windows.Forms.Button();
            this.btnTagihan3Bayar = new System.Windows.Forms.Button();
            this.btnTagihan2Lihat = new System.Windows.Forms.Button();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.panelAtas = new System.Windows.Forms.Panel();
            this.btnmenu = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelBawah = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblNama = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblFecha = new System.Windows.Forms.Label();
            this.lblHora = new System.Windows.Forms.Label();
            this.panelUtama = new System.Windows.Forms.Panel();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.timer6 = new System.Windows.Forms.Timer(this.components);
            this.panelKiri.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panelAtas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnmenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panelBawah.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelKiri
            // 
            this.panelKiri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.panelKiri.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelKiri.Controls.Add(this.panel5);
            this.panelKiri.Controls.Add(this.panel4);
            this.panelKiri.Controls.Add(this.pictureBox7);
            this.panelKiri.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelKiri.Location = new System.Drawing.Point(0, 0);
            this.panelKiri.Name = "panelKiri";
            this.panelKiri.Size = new System.Drawing.Size(250, 768);
            this.panelKiri.TabIndex = 3;
            this.panelKiri.Paint += new System.Windows.Forms.PaintEventHandler(this.panelKiri_Paint);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnLaporan);
            this.panel5.Controls.Add(this.btnLaporan3Pengeluaran);
            this.panel5.Controls.Add(this.btnLaporan2Pemasukan);
            this.panel5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel5.Location = new System.Drawing.Point(0, 197);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(250, 46);
            this.panel5.TabIndex = 4;
            this.panel5.MouseLeave += new System.EventHandler(this.panel5_MouseLeave);
            // 
            // btnLaporan
            // 
            this.btnLaporan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnLaporan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLaporan.FlatAppearance.BorderSize = 0;
            this.btnLaporan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.btnLaporan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnLaporan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLaporan.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLaporan.ForeColor = System.Drawing.Color.White;
            this.btnLaporan.Image = ((System.Drawing.Image)(resources.GetObject("btnLaporan.Image")));
            this.btnLaporan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLaporan.Location = new System.Drawing.Point(-1, 7);
            this.btnLaporan.Name = "btnLaporan";
            this.btnLaporan.Size = new System.Drawing.Size(250, 40);
            this.btnLaporan.TabIndex = 14;
            this.btnLaporan.Text = "Lihat Tagihan";
            this.btnLaporan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLaporan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLaporan.UseVisualStyleBackColor = false;
            this.btnLaporan.Click += new System.EventHandler(this.btnLaporan_Click);
            this.btnLaporan.MouseHover += new System.EventHandler(this.btnLaporan_MouseHover);
            // 
            // btnLaporan3Pengeluaran
            // 
            this.btnLaporan3Pengeluaran.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnLaporan3Pengeluaran.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLaporan3Pengeluaran.FlatAppearance.BorderSize = 0;
            this.btnLaporan3Pengeluaran.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.btnLaporan3Pengeluaran.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnLaporan3Pengeluaran.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLaporan3Pengeluaran.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLaporan3Pengeluaran.ForeColor = System.Drawing.Color.White;
            this.btnLaporan3Pengeluaran.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnLaporan3Pengeluaran.Location = new System.Drawing.Point(0, 80);
            this.btnLaporan3Pengeluaran.Name = "btnLaporan3Pengeluaran";
            this.btnLaporan3Pengeluaran.Size = new System.Drawing.Size(250, 40);
            this.btnLaporan3Pengeluaran.TabIndex = 12;
            this.btnLaporan3Pengeluaran.Text = "Pengeluaran";
            this.btnLaporan3Pengeluaran.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLaporan3Pengeluaran.UseVisualStyleBackColor = false;
            // 
            // btnLaporan2Pemasukan
            // 
            this.btnLaporan2Pemasukan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnLaporan2Pemasukan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLaporan2Pemasukan.FlatAppearance.BorderSize = 0;
            this.btnLaporan2Pemasukan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.btnLaporan2Pemasukan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnLaporan2Pemasukan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLaporan2Pemasukan.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLaporan2Pemasukan.ForeColor = System.Drawing.Color.White;
            this.btnLaporan2Pemasukan.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnLaporan2Pemasukan.Location = new System.Drawing.Point(0, 40);
            this.btnLaporan2Pemasukan.Name = "btnLaporan2Pemasukan";
            this.btnLaporan2Pemasukan.Size = new System.Drawing.Size(250, 40);
            this.btnLaporan2Pemasukan.TabIndex = 11;
            this.btnLaporan2Pemasukan.Text = "Pemasukan";
            this.btnLaporan2Pemasukan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLaporan2Pemasukan.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnTagihan);
            this.panel4.Controls.Add(this.btnTagihan3Bayar);
            this.panel4.Controls.Add(this.btnTagihan2Lihat);
            this.panel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel4.Location = new System.Drawing.Point(0, 148);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(250, 43);
            this.panel4.TabIndex = 3;
            this.panel4.MouseLeave += new System.EventHandler(this.panel4_MouseLeave);
            // 
            // btnTagihan
            // 
            this.btnTagihan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnTagihan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTagihan.FlatAppearance.BorderSize = 0;
            this.btnTagihan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.btnTagihan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnTagihan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTagihan.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTagihan.ForeColor = System.Drawing.Color.White;
            this.btnTagihan.Image = ((System.Drawing.Image)(resources.GetObject("btnTagihan.Image")));
            this.btnTagihan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTagihan.Location = new System.Drawing.Point(0, 0);
            this.btnTagihan.Name = "btnTagihan";
            this.btnTagihan.Size = new System.Drawing.Size(250, 49);
            this.btnTagihan.TabIndex = 13;
            this.btnTagihan.Text = "Bayar Tagihan";
            this.btnTagihan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTagihan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTagihan.UseVisualStyleBackColor = false;
            this.btnTagihan.Click += new System.EventHandler(this.btnTagihan_Click);
            this.btnTagihan.MouseHover += new System.EventHandler(this.btnTagihan_MouseHover);
            // 
            // btnTagihan3Bayar
            // 
            this.btnTagihan3Bayar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnTagihan3Bayar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTagihan3Bayar.FlatAppearance.BorderSize = 0;
            this.btnTagihan3Bayar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.btnTagihan3Bayar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnTagihan3Bayar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTagihan3Bayar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTagihan3Bayar.ForeColor = System.Drawing.Color.White;
            this.btnTagihan3Bayar.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnTagihan3Bayar.Location = new System.Drawing.Point(0, 83);
            this.btnTagihan3Bayar.Name = "btnTagihan3Bayar";
            this.btnTagihan3Bayar.Size = new System.Drawing.Size(250, 40);
            this.btnTagihan3Bayar.TabIndex = 12;
            this.btnTagihan3Bayar.Text = "Bayar Tagihan";
            this.btnTagihan3Bayar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTagihan3Bayar.UseVisualStyleBackColor = false;
            // 
            // btnTagihan2Lihat
            // 
            this.btnTagihan2Lihat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnTagihan2Lihat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTagihan2Lihat.FlatAppearance.BorderSize = 0;
            this.btnTagihan2Lihat.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.btnTagihan2Lihat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnTagihan2Lihat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTagihan2Lihat.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTagihan2Lihat.ForeColor = System.Drawing.Color.White;
            this.btnTagihan2Lihat.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnTagihan2Lihat.Location = new System.Drawing.Point(0, 43);
            this.btnTagihan2Lihat.Name = "btnTagihan2Lihat";
            this.btnTagihan2Lihat.Size = new System.Drawing.Size(250, 40);
            this.btnTagihan2Lihat.TabIndex = 11;
            this.btnTagihan2Lihat.Text = "Lihat Tagihan";
            this.btnTagihan2Lihat.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTagihan2Lihat.UseVisualStyleBackColor = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(0, 0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(190, 111);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 4;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // panelAtas
            // 
            this.panelAtas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.panelAtas.Controls.Add(this.btnmenu);
            this.panelAtas.Controls.Add(this.pictureBox9);
            this.panelAtas.Controls.Add(this.pictureBox8);
            this.panelAtas.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelAtas.Location = new System.Drawing.Point(250, 0);
            this.panelAtas.Name = "panelAtas";
            this.panelAtas.Size = new System.Drawing.Size(1116, 50);
            this.panelAtas.TabIndex = 13;
            this.panelAtas.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelAtas_MouseMove);
            // 
            // btnmenu
            // 
            this.btnmenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmenu.Image = ((System.Drawing.Image)(resources.GetObject("btnmenu.Image")));
            this.btnmenu.Location = new System.Drawing.Point(3, 5);
            this.btnmenu.Name = "btnmenu";
            this.btnmenu.Size = new System.Drawing.Size(35, 36);
            this.btnmenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnmenu.TabIndex = 5;
            this.btnmenu.TabStop = false;
            this.btnmenu.Click += new System.EventHandler(this.btnmenu_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(1067, 3);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(20, 20);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 16;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(1093, 3);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(20, 20);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 15;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panelBawah
            // 
            this.panelBawah.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.panelBawah.Controls.Add(this.pictureBox2);
            this.panelBawah.Controls.Add(this.lblNama);
            this.panelBawah.Controls.Add(this.label2);
            this.panelBawah.Controls.Add(this.label1);
            this.panelBawah.Controls.Add(this.pictureBox1);
            this.panelBawah.Controls.Add(this.lblFecha);
            this.panelBawah.Controls.Add(this.lblHora);
            this.panelBawah.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBawah.Location = new System.Drawing.Point(250, 658);
            this.panelBawah.Name = "panelBawah";
            this.panelBawah.Size = new System.Drawing.Size(1116, 110);
            this.panelBawah.TabIndex = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(126, 62);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(76, 45);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // lblNama
            // 
            this.lblNama.AutoSize = true;
            this.lblNama.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.lblNama.ForeColor = System.Drawing.Color.White;
            this.lblNama.Location = new System.Drawing.Point(123, 24);
            this.lblNama.Name = "lblNama";
            this.lblNama.Size = new System.Drawing.Size(48, 18);
            this.lblNama.TabIndex = 9;
            this.lblNama.Text = "Nama";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(123, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 18);
            this.label2.TabIndex = 8;
            this.label2.Text = "Hello,";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(123, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 18);
            this.label1.TabIndex = 7;
            this.label1.Text = "Anggota";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(122, 107);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // lblFecha
            // 
            this.lblFecha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFecha.AutoSize = true;
            this.lblFecha.BackColor = System.Drawing.Color.Transparent;
            this.lblFecha.Font = new System.Drawing.Font("Century Gothic", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFecha.ForeColor = System.Drawing.Color.SeaGreen;
            this.lblFecha.Location = new System.Drawing.Point(755, 67);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(121, 40);
            this.lblFecha.TabIndex = 6;
            this.lblFecha.Text = "Fecha";
            // 
            // lblHora
            // 
            this.lblHora.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHora.AutoSize = true;
            this.lblHora.Font = new System.Drawing.Font("Century Gothic", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHora.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lblHora.Location = new System.Drawing.Point(773, 3);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(217, 78);
            this.lblHora.TabIndex = 5;
            this.lblHora.Text = "HORA";
            // 
            // panelUtama
            // 
            this.panelUtama.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.panelUtama.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelUtama.Location = new System.Drawing.Point(250, 50);
            this.panelUtama.Name = "panelUtama";
            this.panelUtama.Size = new System.Drawing.Size(1116, 608);
            this.panelUtama.TabIndex = 14;
            this.panelUtama.Paint += new System.Windows.Forms.PaintEventHandler(this.panelUtama_Paint);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // timer5
            // 
            this.timer5.Tick += new System.EventHandler(this.timer5_Tick);
            // 
            // timer6
            // 
            this.timer6.Tick += new System.EventHandler(this.timer6_Tick);
            // 
            // anggota
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.ClientSize = new System.Drawing.Size(1366, 768);
            this.Controls.Add(this.panelUtama);
            this.Controls.Add(this.panelBawah);
            this.Controls.Add(this.panelAtas);
            this.Controls.Add(this.panelKiri);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "anggota";
            this.Opacity = 0.99D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Menu_Utama_Load);
            this.panelKiri.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panelAtas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnmenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panelBawah.ResumeLayout(false);
            this.panelBawah.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelKiri;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Panel panelAtas;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox btnmenu;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panelBawah;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Panel panelUtama;
        private System.Windows.Forms.Label lblNama;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnTagihan;
        private System.Windows.Forms.Button btnTagihan3Bayar;
        private System.Windows.Forms.Button btnTagihan2Lihat;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnLaporan;
        private System.Windows.Forms.Button btnLaporan3Pengeluaran;
        private System.Windows.Forms.Button btnLaporan2Pemasukan;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.Timer timer6;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}