﻿namespace AsistenBendahara
{
    partial class LapPemasukan
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.DataTable3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zPemasukan = new AsistenBendahara.zPemasukan();
            this.DataTable1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ReportBaru = new AsistenBendahara.ReportBaru();
            this.DataTable4BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dtTglMulai = new MetroFramework.Controls.MetroDateTime();
            this.dtTglAkhir = new MetroFramework.Controls.MetroDateTime();
            this.msacaraBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aCARA_ID_NAMA = new AsistenBendahara.ACARA_ID_NAMA();
            this.ms_acaraTableAdapter = new AsistenBendahara.ACARA_ID_NAMATableAdapters.ms_acaraTableAdapter();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.DataTable1TableAdapter = new AsistenBendahara.ReportBaruTableAdapters.DataTable1TableAdapter();
            this.DataTable4TableAdapter = new AsistenBendahara.ReportBaruTableAdapters.DataTable4TableAdapter();
            this.DataTable3TableAdapter = new AsistenBendahara.zPemasukanTableAdapters.DataTable3TableAdapter();
            this.label4 = new System.Windows.Forms.Label();
            this.cbJenisTagihan = new MetroFramework.Controls.MetroComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.DataTable3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zPemasukan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataTable1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReportBaru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataTable4BindingSource)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCARA_ID_NAMA)).BeginInit();
            this.SuspendLayout();
            // 
            // DataTable3BindingSource
            // 
            this.DataTable3BindingSource.DataMember = "DataTable3";
            this.DataTable3BindingSource.DataSource = this.zPemasukan;
            this.DataTable3BindingSource.CurrentChanged += new System.EventHandler(this.DataTable3BindingSource_CurrentChanged);
            // 
            // zPemasukan
            // 
            this.zPemasukan.DataSetName = "zPemasukan";
            this.zPemasukan.EnforceConstraints = false;
            this.zPemasukan.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // DataTable1BindingSource
            // 
            this.DataTable1BindingSource.DataMember = "DataTable1";
            this.DataTable1BindingSource.DataSource = this.ReportBaru;
            this.DataTable1BindingSource.CurrentChanged += new System.EventHandler(this.DataTable1BindingSource_CurrentChanged);
            // 
            // ReportBaru
            // 
            this.ReportBaru.DataSetName = "ReportBaru";
            this.ReportBaru.EnforceConstraints = false;
            this.ReportBaru.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // DataTable4BindingSource
            // 
            this.DataTable4BindingSource.DataMember = "DataTable4";
            this.DataTable4BindingSource.DataSource = this.ReportBaru;
            this.DataTable4BindingSource.CurrentChanged += new System.EventHandler(this.DataTable4BindingSource_CurrentChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(77, 211);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(998, 35);
            this.button1.TabIndex = 84;
            this.button1.Text = "Tampil";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(49, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(381, 42);
            this.label3.TabIndex = 83;
            this.label3.Text = "Laporan Pemasukan";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.962244F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.66019F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 3.77562F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 46.60194F));
            this.tableLayoutPanel2.Controls.Add(this.label1, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label14, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.dtTglMulai, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.dtTglAkhir, 3, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(77, 107);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(927, 57);
            this.tableLayoutPanel2.TabIndex = 82;
            this.tableLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel2_Paint);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(462, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 18);
            this.label1.TabIndex = 94;
            this.label1.Text = "Ke";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(3, 19);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 18);
            this.label14.TabIndex = 93;
            this.label14.Text = "Dari";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // dtTglMulai
            // 
            this.dtTglMulai.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dtTglMulai.CustomFormat = "dd-MM-yyyy";
            this.dtTglMulai.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTglMulai.Location = new System.Drawing.Point(49, 14);
            this.dtTglMulai.MinimumSize = new System.Drawing.Size(0, 29);
            this.dtTglMulai.Name = "dtTglMulai";
            this.dtTglMulai.Size = new System.Drawing.Size(227, 29);
            this.dtTglMulai.TabIndex = 38;
            this.dtTglMulai.ValueChanged += new System.EventHandler(this.dtTglMulai_ValueChanged);
            // 
            // dtTglAkhir
            // 
            this.dtTglAkhir.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dtTglAkhir.CustomFormat = "dd-MM-yyyy";
            this.dtTglAkhir.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTglAkhir.Location = new System.Drawing.Point(496, 14);
            this.dtTglAkhir.MinimumSize = new System.Drawing.Size(0, 29);
            this.dtTglAkhir.Name = "dtTglAkhir";
            this.dtTglAkhir.Size = new System.Drawing.Size(239, 29);
            this.dtTglAkhir.TabIndex = 39;
            this.dtTglAkhir.ValueChanged += new System.EventHandler(this.dtTglAkhir_ValueChanged);
            // 
            // msacaraBindingSource
            // 
            this.msacaraBindingSource.DataMember = "ms_acara";
            this.msacaraBindingSource.DataSource = this.aCARA_ID_NAMA;
            this.msacaraBindingSource.CurrentChanged += new System.EventHandler(this.msacaraBindingSource_CurrentChanged);
            // 
            // aCARA_ID_NAMA
            // 
            this.aCARA_ID_NAMA.DataSetName = "ACARA_ID_NAMA";
            this.aCARA_ID_NAMA.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ms_acaraTableAdapter
            // 
            this.ms_acaraTableAdapter.ClearBeforeFill = true;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.DataTable3BindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "AsistenBendahara.Report5.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(75, 252);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(1000, 309);
            this.reportViewer1.TabIndex = 85;
            this.reportViewer1.Load += new System.EventHandler(this.reportViewer1_Load);
            // 
            // DataTable1TableAdapter
            // 
            this.DataTable1TableAdapter.ClearBeforeFill = true;
            // 
            // DataTable4TableAdapter
            // 
            this.DataTable4TableAdapter.ClearBeforeFill = true;
            // 
            // DataTable3TableAdapter
            // 
            this.DataTable3TableAdapter.ClearBeforeFill = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(75, 181);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 18);
            this.label4.TabIndex = 96;
            this.label4.Text = "Acara";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // cbJenisTagihan
            // 
            this.cbJenisTagihan.DataSource = this.msacaraBindingSource;
            this.cbJenisTagihan.DisplayMember = "acara_nama";
            this.cbJenisTagihan.FormattingEnabled = true;
            this.cbJenisTagihan.ItemHeight = 23;
            this.cbJenisTagihan.Location = new System.Drawing.Point(127, 170);
            this.cbJenisTagihan.Name = "cbJenisTagihan";
            this.cbJenisTagihan.Size = new System.Drawing.Size(226, 29);
            this.cbJenisTagihan.TabIndex = 95;
            this.cbJenisTagihan.UseSelectable = true;
            this.cbJenisTagihan.ValueMember = "acara_id";
            this.cbJenisTagihan.SelectedIndexChanged += new System.EventHandler(this.cbJenisTagihan_SelectedIndexChanged);
            // 
            // LapPemasukan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbJenisTagihan);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Name = "LapPemasukan";
            this.Size = new System.Drawing.Size(1116, 608);
            this.Load += new System.EventHandler(this.LapPemasukan_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataTable3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zPemasukan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataTable1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReportBaru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataTable4BindingSource)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCARA_ID_NAMA)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label14;
        private MetroFramework.Controls.MetroDateTime dtTglMulai;
        private MetroFramework.Controls.MetroDateTime dtTglAkhir;
        private System.Windows.Forms.BindingSource msacaraBindingSource;
        private ACARA_ID_NAMA aCARA_ID_NAMA;
        private zPemasukan zPemasukan;
        private ACARA_ID_NAMATableAdapters.ms_acaraTableAdapter ms_acaraTableAdapter;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource DataTable1BindingSource;
        private ReportBaru ReportBaru;
        private System.Windows.Forms.BindingSource DataTable3BindingSource;
        private System.Windows.Forms.BindingSource DataTable4BindingSource;
        private ReportBaruTableAdapters.DataTable1TableAdapter DataTable1TableAdapter;
        private zPemasukanTableAdapters.DataTable3TableAdapter DataTable3TableAdapter;
        private ReportBaruTableAdapters.DataTable4TableAdapter DataTable4TableAdapter;
        private System.Windows.Forms.Label label4;
        private MetroFramework.Controls.MetroComboBox cbJenisTagihan;
    }
}
