﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsistenBendahara
{
    public partial class LapPemasukan : UserControl
    {
        public LapPemasukan()
        {
            InitializeComponent();
        }

        private void LapPemasukan_Load(object sender, EventArgs e)
        {
             this.ms_acaraTableAdapter.Fill(this.aCARA_ID_NAMA.ms_acara);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //zPemasukanTableAdapters.DataTable3TableAdapter.Fill(zPemasukan.DataTable3, dtTglMulai.Value.ToShortDateString(), dtTglAkhir.Value.ToShortDateString());
            this.DataTable4TableAdapter.Fill(this.ReportBaru.DataTable4, dtTglMulai.Value.ToShortDateString(), dtTglAkhir.Value.ToShortDateString());
            this.DataTable3TableAdapter.Fill(this.zPemasukan.DataTable3, dtTglMulai.Value.ToShortDateString(), dtTglAkhir.Value.ToShortDateString(), cbJenisTagihan.SelectedValue.ToString());
            this.reportViewer1.RefreshReport();
        }

        private void DataTable1BindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void DataTable4BindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void dtTglMulai_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dtTglAkhir_ValueChanged(object sender, EventArgs e)
        {

        }

        private void msacaraBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void cbJenisTagihan_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void DataTable3BindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }
    }
}
