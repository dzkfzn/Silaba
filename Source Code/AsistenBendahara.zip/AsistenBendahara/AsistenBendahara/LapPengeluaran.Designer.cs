﻿namespace AsistenBendahara
{
    partial class LapPengeluaran
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.DataTable1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ReportBaru = new AsistenBendahara.ReportBaru();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbJenisTagihan = new MetroFramework.Controls.MetroComboBox();
            this.msacaraBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aCARA_ID_NAMA = new AsistenBendahara.ACARA_ID_NAMA();
            this.label14 = new System.Windows.Forms.Label();
            this.dtTglMulai = new MetroFramework.Controls.MetroDateTime();
            this.dtTglAkhir = new MetroFramework.Controls.MetroDateTime();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.DataTable1TableAdapter = new AsistenBendahara.ReportBaruTableAdapters.DataTable1TableAdapter();
            this.ms_acaraTableAdapter = new AsistenBendahara.ACARA_ID_NAMATableAdapters.ms_acaraTableAdapter();
            this.pRG2_SILABIDataSet11 = new AsistenBendahara.PRG2_SILABIDataSet11();
            this.pRG2SILABIDataSet11BindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.DataTable1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReportBaru)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCARA_ID_NAMA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2SILABIDataSet11BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // DataTable1BindingSource
            // 
            this.DataTable1BindingSource.DataMember = "DataTable1";
            this.DataTable1BindingSource.DataSource = this.ReportBaru;
            // 
            // ReportBaru
            // 
            this.ReportBaru.DataSetName = "ReportBaru";
            this.ReportBaru.EnforceConstraints = false;
            this.ReportBaru.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(18, 276);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(394, 35);
            this.button1.TabIndex = 80;
            this.button1.Text = "Tampil";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(10, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(398, 42);
            this.label3.TabIndex = 79;
            this.label3.Text = "Laporan Pengeluaran";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.137055F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.11675F));
            this.tableLayoutPanel2.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label1, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.cbJenisTagihan, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label14, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.dtTglMulai, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.dtTglAkhir, 3, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(18, 152);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(394, 118);
            this.tableLayoutPanel2.TabIndex = 78;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(3, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 18);
            this.label4.TabIndex = 94;
            this.label4.Text = "Acara";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(199, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 18);
            this.label1.TabIndex = 94;
            this.label1.Text = "Ke";
            // 
            // cbJenisTagihan
            // 
            this.cbJenisTagihan.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cbJenisTagihan.DataSource = this.msacaraBindingSource;
            this.cbJenisTagihan.DisplayMember = "acara_nama";
            this.cbJenisTagihan.FormattingEnabled = true;
            this.cbJenisTagihan.ItemHeight = 23;
            this.cbJenisTagihan.Location = new System.Drawing.Point(101, 74);
            this.cbJenisTagihan.Name = "cbJenisTagihan";
            this.cbJenisTagihan.Size = new System.Drawing.Size(92, 29);
            this.cbJenisTagihan.TabIndex = 38;
            this.cbJenisTagihan.UseSelectable = true;
            this.cbJenisTagihan.ValueMember = "acara_id";
            // 
            // msacaraBindingSource
            // 
            this.msacaraBindingSource.DataMember = "ms_acara";
            this.msacaraBindingSource.DataSource = this.aCARA_ID_NAMA;
            // 
            // aCARA_ID_NAMA
            // 
            this.aCARA_ID_NAMA.DataSetName = "ACARA_ID_NAMA";
            this.aCARA_ID_NAMA.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(3, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 18);
            this.label14.TabIndex = 93;
            this.label14.Text = "Dari";
            // 
            // dtTglMulai
            // 
            this.dtTglMulai.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dtTglMulai.CustomFormat = "dd-MM-yyyy";
            this.dtTglMulai.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTglMulai.Location = new System.Drawing.Point(101, 15);
            this.dtTglMulai.MinimumSize = new System.Drawing.Size(0, 29);
            this.dtTglMulai.Name = "dtTglMulai";
            this.dtTglMulai.Size = new System.Drawing.Size(92, 29);
            this.dtTglMulai.TabIndex = 38;
            // 
            // dtTglAkhir
            // 
            this.dtTglAkhir.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dtTglAkhir.CustomFormat = "dd-MM-yyyy";
            this.dtTglAkhir.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTglAkhir.Location = new System.Drawing.Point(234, 15);
            this.dtTglAkhir.MinimumSize = new System.Drawing.Size(0, 29);
            this.dtTglAkhir.Name = "dtTglAkhir";
            this.dtTglAkhir.Size = new System.Drawing.Size(115, 29);
            this.dtTglAkhir.TabIndex = 39;
            // 
            // reportViewer1
            // 
            this.reportViewer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.DataTable1BindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "AsistenBendahara.Report3.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(474, 143);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(576, 397);
            this.reportViewer1.TabIndex = 77;
            // 
            // DataTable1TableAdapter
            // 
            this.DataTable1TableAdapter.ClearBeforeFill = true;
            // 
            // ms_acaraTableAdapter
            // 
            this.ms_acaraTableAdapter.ClearBeforeFill = true;
            // 
            // pRG2_SILABIDataSet11
            // 
            this.pRG2_SILABIDataSet11.DataSetName = "PRG2_SILABIDataSet11";
            this.pRG2_SILABIDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pRG2SILABIDataSet11BindingSource
            // 
            this.pRG2SILABIDataSet11BindingSource.DataSource = this.pRG2_SILABIDataSet11;
            this.pRG2SILABIDataSet11BindingSource.Position = 0;
            // 
            // LapPengeluaran
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.reportViewer1);
            this.Name = "LapPengeluaran";
            this.Size = new System.Drawing.Size(1116, 608);
            this.Load += new System.EventHandler(this.LapPengeluaran_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataTable1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReportBaru)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCARA_ID_NAMA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2SILABIDataSet11BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroComboBox cbJenisTagihan;
        private System.Windows.Forms.Label label14;
        private MetroFramework.Controls.MetroDateTime dtTglMulai;
        private MetroFramework.Controls.MetroDateTime dtTglAkhir;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource DataTable1BindingSource;
        private ReportBaru ReportBaru;
        private ReportBaruTableAdapters.DataTable1TableAdapter DataTable1TableAdapter;
        private System.Windows.Forms.BindingSource msacaraBindingSource;
        private ACARA_ID_NAMA aCARA_ID_NAMA;
        private ACARA_ID_NAMATableAdapters.ms_acaraTableAdapter ms_acaraTableAdapter;
        private PRG2_SILABIDataSet11 pRG2_SILABIDataSet11;
        private System.Windows.Forms.BindingSource pRG2SILABIDataSet11BindingSource;
    }
}
