﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsistenBendahara
{
    public partial class LapPengeluaran : UserControl
    {
        public LapPengeluaran()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DataTable1TableAdapter.Fill(this.ReportBaru.DataTable1, dtTglMulai.Value.ToShortDateString(), dtTglAkhir.Value.ToShortDateString(), cbJenisTagihan.SelectedValue.ToString());
            //this.DataTable2TableAdapter.Fill(this.ReportBaru.DataTable1, dtTglMulai.Value.ToShortDateString(), dtTglAkhir.Value.ToShortDateString(), cbJenisTagihan.SelectedValue.ToString());
            this.reportViewer1.RefreshReport();
        }

        private void LapPengeluaran_Load(object sender, EventArgs e)
        {
            this.ms_acaraTableAdapter.Fill(this.aCARA_ID_NAMA.ms_acara);


        }
    }
}
