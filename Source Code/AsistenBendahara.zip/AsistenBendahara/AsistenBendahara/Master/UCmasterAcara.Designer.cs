﻿namespace AsistenBendahara.Master
{
    partial class UCmasterAcara
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCmasterAcara));
            this.txtCari = new System.Windows.Forms.TextBox();
            this.dgAcara = new MetroFramework.Controls.MetroGrid();
            this.acaraidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.acaranamaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.acarabudgetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.acarajenistagihanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.acarajumlahtagihanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.acaratanggalmulaiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.acaratanggalberakhirDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.msacaraBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsAcaraDataSet = new AsistenBendahara.dsAcaraDataSet();
            this.dtTglAkhir = new MetroFramework.Controls.MetroDateTime();
            this.txtTagihan = new System.Windows.Forms.TextBox();
            this.dtTglMulai = new MetroFramework.Controls.MetroDateTime();
            this.cbJenisTagihan = new MetroFramework.Controls.MetroComboBox();
            this.txtBudgetAwal = new System.Windows.Forms.TextBox();
            this.txtNama = new System.Windows.Forms.TextBox();
            this.dsAcara_update = new AsistenBendahara.dsAcara_update();
            this.dsAcaraupdateBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pRG2_SILABIDataSet3 = new AsistenBendahara.PRG2_SILABIDataSet3();
            this.pRG2SILABIDataSet3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trdetailjenistagihanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tr_detail_jenis_tagihanTableAdapter = new AsistenBendahara.PRG2_SILABIDataSet3TableAdapters.tr_detail_jenis_tagihanTableAdapter();
            this.pRG2_SILABIDataSet5 = new AsistenBendahara.PRG2_SILABIDataSet5();
            this.msacaraBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ms_acaraTableAdapter1 = new AsistenBendahara.PRG2_SILABIDataSet5TableAdapters.ms_acaraTableAdapter();
            this.ms_acaraTableAdapter = new AsistenBendahara.dsAcaraDataSetTableAdapters.ms_acaraTableAdapter();
            this.errorWarning = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorBenar = new System.Windows.Forms.ErrorProvider(this.components);
            this.lblNotif = new System.Windows.Forms.Label();
            this.btnSimpan = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelBudgetAwal = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnBatal = new System.Windows.Forms.Button();
            this.btnHapus = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgAcara)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAcaraDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAcara_update)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAcaraupdateBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2SILABIDataSet3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trdetailjenistagihanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorWarning)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorBenar)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCari
            // 
            this.txtCari.Location = new System.Drawing.Point(489, 92);
            this.txtCari.Name = "txtCari";
            this.txtCari.Size = new System.Drawing.Size(605, 20);
            this.txtCari.TabIndex = 26;
            this.txtCari.TextChanged += new System.EventHandler(this.txtCari_TextChanged);
            // 
            // dgAcara
            // 
            this.dgAcara.AllowUserToAddRows = false;
            this.dgAcara.AllowUserToDeleteRows = false;
            this.dgAcara.AllowUserToResizeRows = false;
            this.dgAcara.AutoGenerateColumns = false;
            this.dgAcara.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.dgAcara.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgAcara.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgAcara.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgAcara.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgAcara.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAcara.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.acaraidDataGridViewTextBoxColumn,
            this.acaranamaDataGridViewTextBoxColumn,
            this.acarabudgetDataGridViewTextBoxColumn,
            this.acarajenistagihanDataGridViewTextBoxColumn,
            this.acarajumlahtagihanDataGridViewTextBoxColumn,
            this.acaratanggalmulaiDataGridViewTextBoxColumn,
            this.acaratanggalberakhirDataGridViewTextBoxColumn});
            this.dgAcara.DataSource = this.msacaraBindingSource;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgAcara.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgAcara.EnableHeadersVisualStyles = false;
            this.dgAcara.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgAcara.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.dgAcara.Location = new System.Drawing.Point(429, 134);
            this.dgAcara.Name = "dgAcara";
            this.dgAcara.ReadOnly = true;
            this.dgAcara.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgAcara.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgAcara.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgAcara.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgAcara.Size = new System.Drawing.Size(665, 430);
            this.dgAcara.TabIndex = 24;
            this.dgAcara.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgAcara_CellClick);
            this.dgAcara.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgAcara_CellContentClick);
            // 
            // acaraidDataGridViewTextBoxColumn
            // 
            this.acaraidDataGridViewTextBoxColumn.DataPropertyName = "acara_id";
            this.acaraidDataGridViewTextBoxColumn.HeaderText = "ID Acara";
            this.acaraidDataGridViewTextBoxColumn.Name = "acaraidDataGridViewTextBoxColumn";
            this.acaraidDataGridViewTextBoxColumn.ReadOnly = true;
            this.acaraidDataGridViewTextBoxColumn.Width = 90;
            // 
            // acaranamaDataGridViewTextBoxColumn
            // 
            this.acaranamaDataGridViewTextBoxColumn.DataPropertyName = "acara_nama";
            this.acaranamaDataGridViewTextBoxColumn.HeaderText = "Nama Acara";
            this.acaranamaDataGridViewTextBoxColumn.Name = "acaranamaDataGridViewTextBoxColumn";
            this.acaranamaDataGridViewTextBoxColumn.ReadOnly = true;
            this.acaranamaDataGridViewTextBoxColumn.Width = 90;
            // 
            // acarabudgetDataGridViewTextBoxColumn
            // 
            this.acarabudgetDataGridViewTextBoxColumn.DataPropertyName = "acara_budget";
            dataGridViewCellStyle2.Format = "C0";
            dataGridViewCellStyle2.NullValue = "Rp #.###";
            this.acarabudgetDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.acarabudgetDataGridViewTextBoxColumn.HeaderText = "Budget Acara";
            this.acarabudgetDataGridViewTextBoxColumn.Name = "acarabudgetDataGridViewTextBoxColumn";
            this.acarabudgetDataGridViewTextBoxColumn.ReadOnly = true;
            this.acarabudgetDataGridViewTextBoxColumn.Width = 90;
            // 
            // acarajenistagihanDataGridViewTextBoxColumn
            // 
            this.acarajenistagihanDataGridViewTextBoxColumn.DataPropertyName = "acara_jenis_tagihan";
            this.acarajenistagihanDataGridViewTextBoxColumn.HeaderText = "Jenis Tagihan";
            this.acarajenistagihanDataGridViewTextBoxColumn.Name = "acarajenistagihanDataGridViewTextBoxColumn";
            this.acarajenistagihanDataGridViewTextBoxColumn.ReadOnly = true;
            this.acarajenistagihanDataGridViewTextBoxColumn.Width = 91;
            // 
            // acarajumlahtagihanDataGridViewTextBoxColumn
            // 
            this.acarajumlahtagihanDataGridViewTextBoxColumn.DataPropertyName = "acara_jumlah_tagihan";
            dataGridViewCellStyle3.Format = "C0";
            dataGridViewCellStyle3.NullValue = "Rp #.###";
            this.acarajumlahtagihanDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.acarajumlahtagihanDataGridViewTextBoxColumn.HeaderText = "Jumlah Tagihan";
            this.acarajumlahtagihanDataGridViewTextBoxColumn.Name = "acarajumlahtagihanDataGridViewTextBoxColumn";
            this.acarajumlahtagihanDataGridViewTextBoxColumn.ReadOnly = true;
            this.acarajumlahtagihanDataGridViewTextBoxColumn.Width = 90;
            // 
            // acaratanggalmulaiDataGridViewTextBoxColumn
            // 
            this.acaratanggalmulaiDataGridViewTextBoxColumn.DataPropertyName = "acara_tanggal_mulai";
            dataGridViewCellStyle4.Format = "D";
            dataGridViewCellStyle4.NullValue = null;
            this.acaratanggalmulaiDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.acaratanggalmulaiDataGridViewTextBoxColumn.HeaderText = "Tanggal Mulai";
            this.acaratanggalmulaiDataGridViewTextBoxColumn.Name = "acaratanggalmulaiDataGridViewTextBoxColumn";
            this.acaratanggalmulaiDataGridViewTextBoxColumn.ReadOnly = true;
            this.acaratanggalmulaiDataGridViewTextBoxColumn.Width = 90;
            // 
            // acaratanggalberakhirDataGridViewTextBoxColumn
            // 
            this.acaratanggalberakhirDataGridViewTextBoxColumn.DataPropertyName = "acara_tanggal_berakhir";
            dataGridViewCellStyle5.Format = "D";
            this.acaratanggalberakhirDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle5;
            this.acaratanggalberakhirDataGridViewTextBoxColumn.HeaderText = "Tanggal Berakhir";
            this.acaratanggalberakhirDataGridViewTextBoxColumn.Name = "acaratanggalberakhirDataGridViewTextBoxColumn";
            this.acaratanggalberakhirDataGridViewTextBoxColumn.ReadOnly = true;
            this.acaratanggalberakhirDataGridViewTextBoxColumn.Width = 90;
            // 
            // msacaraBindingSource
            // 
            this.msacaraBindingSource.DataMember = "ms_acara";
            this.msacaraBindingSource.DataSource = this.dsAcaraDataSet;
            // 
            // dsAcaraDataSet
            // 
            this.dsAcaraDataSet.DataSetName = "dsAcaraDataSet";
            this.dsAcaraDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dtTglAkhir
            // 
            this.dtTglAkhir.CustomFormat = "dd-MM-yyyy";
            this.dtTglAkhir.Enabled = false;
            this.dtTglAkhir.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTglAkhir.Location = new System.Drawing.Point(199, 399);
            this.dtTglAkhir.MinimumSize = new System.Drawing.Size(0, 29);
            this.dtTglAkhir.Name = "dtTglAkhir";
            this.dtTglAkhir.Size = new System.Drawing.Size(162, 29);
            this.dtTglAkhir.TabIndex = 39;
            this.dtTglAkhir.ValueChanged += new System.EventHandler(this.dtTglAkhir_ValueChanged);
            // 
            // txtTagihan
            // 
            this.txtTagihan.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.txtTagihan.Location = new System.Drawing.Point(199, 286);
            this.txtTagihan.MaxLength = 15;
            this.txtTagihan.Name = "txtTagihan";
            this.txtTagihan.Size = new System.Drawing.Size(162, 23);
            this.txtTagihan.TabIndex = 36;
            this.txtTagihan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTagihan_KeyPress_1);
            // 
            // dtTglMulai
            // 
            this.dtTglMulai.CustomFormat = "dd-MM-yyyy";
            this.dtTglMulai.Enabled = false;
            this.dtTglMulai.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTglMulai.Location = new System.Drawing.Point(199, 340);
            this.dtTglMulai.MinimumSize = new System.Drawing.Size(0, 29);
            this.dtTglMulai.Name = "dtTglMulai";
            this.dtTglMulai.Size = new System.Drawing.Size(162, 29);
            this.dtTglMulai.TabIndex = 38;
            this.dtTglMulai.ValueChanged += new System.EventHandler(this.dtTglMulai_ValueChanged);
            // 
            // cbJenisTagihan
            // 
            this.cbJenisTagihan.FormattingEnabled = true;
            this.cbJenisTagihan.ItemHeight = 23;
            this.cbJenisTagihan.Items.AddRange(new object[] {
            "Mingguan",
            "Bulanan",
            "Tahunan"});
            this.cbJenisTagihan.Location = new System.Drawing.Point(199, 228);
            this.cbJenisTagihan.Name = "cbJenisTagihan";
            this.cbJenisTagihan.Size = new System.Drawing.Size(162, 29);
            this.cbJenisTagihan.TabIndex = 37;
            this.cbJenisTagihan.UseSelectable = true;
            this.cbJenisTagihan.DropDown += new System.EventHandler(this.cbJenisTagihan_DropDown_1);
            this.cbJenisTagihan.SelectedIndexChanged += new System.EventHandler(this.cbJenisTagihan_SelectedIndexChanged);
            this.cbJenisTagihan.DropDownClosed += new System.EventHandler(this.cbJenisTagihan_DropDownClosed_1);
            // 
            // txtBudgetAwal
            // 
            this.txtBudgetAwal.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.txtBudgetAwal.Location = new System.Drawing.Point(199, 168);
            this.txtBudgetAwal.MaxLength = 15;
            this.txtBudgetAwal.Name = "txtBudgetAwal";
            this.txtBudgetAwal.Size = new System.Drawing.Size(162, 23);
            this.txtBudgetAwal.TabIndex = 35;
            this.txtBudgetAwal.TextChanged += new System.EventHandler(this.txtBudgetAwal_TextChanged);
            this.txtBudgetAwal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBudgetAwal_KeyPress_1);
            this.txtBudgetAwal.Leave += new System.EventHandler(this.txtBudgetAwal_Leave_1);
            // 
            // txtNama
            // 
            this.txtNama.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNama.Location = new System.Drawing.Point(199, 109);
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(162, 23);
            this.txtNama.TabIndex = 34;
            this.txtNama.Click += new System.EventHandler(this.txtNama_Click);
            this.txtNama.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNama_KeyPress_1);
            this.txtNama.MouseMove += new System.Windows.Forms.MouseEventHandler(this.txtNama_MouseMove);
            this.txtNama.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.txtNama_PreviewKeyDown);
            // 
            // dsAcara_update
            // 
            this.dsAcara_update.DataSetName = "dsAcara_update";
            this.dsAcara_update.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dsAcaraupdateBindingSource
            // 
            this.dsAcaraupdateBindingSource.DataSource = this.dsAcara_update;
            this.dsAcaraupdateBindingSource.Position = 0;
            // 
            // pRG2_SILABIDataSet3
            // 
            this.pRG2_SILABIDataSet3.DataSetName = "PRG2_SILABIDataSet3";
            this.pRG2_SILABIDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pRG2SILABIDataSet3BindingSource
            // 
            this.pRG2SILABIDataSet3BindingSource.DataSource = this.pRG2_SILABIDataSet3;
            this.pRG2SILABIDataSet3BindingSource.Position = 0;
            // 
            // trdetailjenistagihanBindingSource
            // 
            this.trdetailjenistagihanBindingSource.DataMember = "tr_detail_jenis_tagihan";
            this.trdetailjenistagihanBindingSource.DataSource = this.pRG2SILABIDataSet3BindingSource;
            // 
            // tr_detail_jenis_tagihanTableAdapter
            // 
            this.tr_detail_jenis_tagihanTableAdapter.ClearBeforeFill = true;
            // 
            // pRG2_SILABIDataSet5
            // 
            this.pRG2_SILABIDataSet5.DataSetName = "PRG2_SILABIDataSet5";
            this.pRG2_SILABIDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // msacaraBindingSource1
            // 
            this.msacaraBindingSource1.DataMember = "ms_acara";
            this.msacaraBindingSource1.DataSource = this.pRG2_SILABIDataSet5;
            // 
            // ms_acaraTableAdapter1
            // 
            this.ms_acaraTableAdapter1.ClearBeforeFill = true;
            // 
            // ms_acaraTableAdapter
            // 
            this.ms_acaraTableAdapter.ClearBeforeFill = true;
            // 
            // errorWarning
            // 
            this.errorWarning.ContainerControl = this;
            this.errorWarning.Icon = ((System.Drawing.Icon)(resources.GetObject("errorWarning.Icon")));
            // 
            // errorBenar
            // 
            this.errorBenar.ContainerControl = this;
            this.errorBenar.Icon = ((System.Drawing.Icon)(resources.GetObject("errorBenar.Icon")));
            // 
            // lblNotif
            // 
            this.lblNotif.AutoSize = true;
            this.lblNotif.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotif.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblNotif.Location = new System.Drawing.Point(41, 442);
            this.lblNotif.Name = "lblNotif";
            this.lblNotif.Size = new System.Drawing.Size(45, 14);
            this.lblNotif.TabIndex = 28;
            this.lblNotif.Text = "label1";
            this.lblNotif.Click += new System.EventHandler(this.lblNotif_Click);
            // 
            // btnSimpan
            // 
            this.btnSimpan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnSimpan.FlatAppearance.BorderSize = 0;
            this.btnSimpan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSimpan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSimpan.ForeColor = System.Drawing.Color.White;
            this.btnSimpan.Location = new System.Drawing.Point(41, 488);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(154, 35);
            this.btnSimpan.TabIndex = 29;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.UseVisualStyleBackColor = false;
            this.btnSimpan.Click += new System.EventHandler(this.btnSimpan_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(38, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 18);
            this.label1.TabIndex = 40;
            this.label1.Text = "Nama Acara";
            // 
            // labelBudgetAwal
            // 
            this.labelBudgetAwal.AutoSize = true;
            this.labelBudgetAwal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBudgetAwal.ForeColor = System.Drawing.Color.White;
            this.labelBudgetAwal.Location = new System.Drawing.Point(38, 169);
            this.labelBudgetAwal.Name = "labelBudgetAwal";
            this.labelBudgetAwal.Size = new System.Drawing.Size(89, 18);
            this.labelBudgetAwal.TabIndex = 41;
            this.labelBudgetAwal.Text = "Budget Awal";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(38, 287);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 18);
            this.label3.TabIndex = 43;
            this.label3.Text = "Jumlah Tagihan";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(38, 228);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 18);
            this.label4.TabIndex = 42;
            this.label4.Text = "Jenis Tagihan";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(38, 405);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 18);
            this.label5.TabIndex = 45;
            this.label5.Text = "Tanggal Berakhir";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(38, 346);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 18);
            this.label6.TabIndex = 44;
            this.label6.Text = "Tanggal Mulai";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label7.Location = new System.Drawing.Point(125, 110);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 14);
            this.label7.TabIndex = 46;
            this.label7.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label8.Location = new System.Drawing.Point(125, 168);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 14);
            this.label8.TabIndex = 47;
            this.label8.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label9.Location = new System.Drawing.Point(133, 228);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 14);
            this.label9.TabIndex = 48;
            this.label9.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label10.Location = new System.Drawing.Point(144, 287);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 14);
            this.label10.TabIndex = 49;
            this.label10.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label11.Location = new System.Drawing.Point(133, 346);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 14);
            this.label11.TabIndex = 50;
            this.label11.Text = "*";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label12.Location = new System.Drawing.Point(155, 405);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 14);
            this.label12.TabIndex = 51;
            this.label12.Text = "*";
            // 
            // btnBatal
            // 
            this.btnBatal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnBatal.FlatAppearance.BorderSize = 0;
            this.btnBatal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBatal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBatal.ForeColor = System.Drawing.Color.White;
            this.btnBatal.Location = new System.Drawing.Point(201, 488);
            this.btnBatal.Name = "btnBatal";
            this.btnBatal.Size = new System.Drawing.Size(160, 35);
            this.btnBatal.TabIndex = 52;
            this.btnBatal.Text = "Batal";
            this.btnBatal.UseVisualStyleBackColor = false;
            this.btnBatal.Click += new System.EventHandler(this.btnBatal_Click_1);
            // 
            // btnHapus
            // 
            this.btnHapus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnHapus.FlatAppearance.BorderSize = 0;
            this.btnHapus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHapus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHapus.ForeColor = System.Drawing.Color.White;
            this.btnHapus.Location = new System.Drawing.Point(41, 529);
            this.btnHapus.Name = "btnHapus";
            this.btnHapus.Size = new System.Drawing.Size(320, 35);
            this.btnHapus.TabIndex = 53;
            this.btnHapus.Text = "Hapus";
            this.btnHapus.UseVisualStyleBackColor = false;
            this.btnHapus.Click += new System.EventHandler(this.btnHapus_Click_1);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(426, 93);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 18);
            this.label13.TabIndex = 54;
            this.label13.Text = "Cari :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(41, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(242, 42);
            this.label2.TabIndex = 55;
            this.label2.Text = "Kelola Acara";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(426, 567);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(463, 18);
            this.label14.TabIndex = 56;
            this.label14.Text = "*Klik Baris Pada Table Diatas Untuk Memperbaharui atau Menghapus";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(426, 115);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(72, 15);
            this.label18.TabIndex = 76;
            this.label18.Text = "Table Acara";
            // 
            // UCmasterAcara
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.btnHapus);
            this.Controls.Add(this.btnBatal);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelBudgetAwal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtTglAkhir);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.txtTagihan);
            this.Controls.Add(this.lblNotif);
            this.Controls.Add(this.dtTglMulai);
            this.Controls.Add(this.cbJenisTagihan);
            this.Controls.Add(this.txtBudgetAwal);
            this.Controls.Add(this.txtNama);
            this.Controls.Add(this.txtCari);
            this.Controls.Add(this.dgAcara);
            this.Name = "UCmasterAcara";
            this.Size = new System.Drawing.Size(1116, 608);
            this.Load += new System.EventHandler(this.UCmasterAcara_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgAcara)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAcaraDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAcara_update)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAcaraupdateBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2SILABIDataSet3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trdetailjenistagihanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorWarning)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorBenar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtCari;
        private MetroFramework.Controls.MetroGrid dgAcara;
        private System.Windows.Forms.BindingSource msacaraBindingSource;
        private dsAcaraDataSet dsAcaraDataSet;
        private dsAcaraDataSetTableAdapters.ms_acaraTableAdapter ms_acaraTableAdapter;
        private System.Windows.Forms.BindingSource dsAcaraupdateBindingSource;
        private dsAcara_update dsAcara_update;
        private PRG2_SILABIDataSet3 pRG2_SILABIDataSet3;
        private System.Windows.Forms.BindingSource pRG2SILABIDataSet3BindingSource;
        private System.Windows.Forms.BindingSource trdetailjenistagihanBindingSource;
        private PRG2_SILABIDataSet3TableAdapters.tr_detail_jenis_tagihanTableAdapter tr_detail_jenis_tagihanTableAdapter;
        private PRG2_SILABIDataSet5 pRG2_SILABIDataSet5;
        private System.Windows.Forms.BindingSource msacaraBindingSource1;
        private PRG2_SILABIDataSet5TableAdapters.ms_acaraTableAdapter ms_acaraTableAdapter1;
        private System.Windows.Forms.TextBox txtTagihan;
        private System.Windows.Forms.TextBox txtBudgetAwal;
        private System.Windows.Forms.TextBox txtNama;
        private MetroFramework.Controls.MetroComboBox cbJenisTagihan;
        private MetroFramework.Controls.MetroDateTime dtTglAkhir;
        private MetroFramework.Controls.MetroDateTime dtTglMulai;
        private System.Windows.Forms.ErrorProvider errorWarning;
        private System.Windows.Forms.ErrorProvider errorBenar;
        private System.Windows.Forms.DataGridViewTextBoxColumn acaraidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn acaranamaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn acarabudgetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn acarajenistagihanDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn acarajumlahtagihanDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn acaratanggalmulaiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn acaratanggalberakhirDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lblNotif;
        private System.Windows.Forms.Button btnSimpan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelBudgetAwal;
        private System.Windows.Forms.Button btnHapus;
        private System.Windows.Forms.Button btnBatal;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label18;
    }
}
