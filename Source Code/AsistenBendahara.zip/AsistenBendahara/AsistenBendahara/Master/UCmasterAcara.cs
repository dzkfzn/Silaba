﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using MetroFramework;

namespace AsistenBendahara.Master
{
    public partial class UCmasterAcara : UserControl
    {
        public UCmasterAcara()
        {
            InitializeComponent();
            
        }
        int itungBatal;
        string acara_ID;
        string connectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
        string tagihan="";
        string budgetAwal = "";

        int hari;
        private string autoid()
        {
            DataSet myDataSet = new DataSet();
            string maxid = "";
            int id_user;
            string id = "";
            try
            {

                string myConnectionString = "integrated security=true;data source =.; initial catalog = PRG2_SILABI";

                SqlConnection myConnection = new SqlConnection(myConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Connection = myConnection;

                myCommand.CommandText = "SELECT MAX(acara_id) AS acara_id FROM ms_acara";
                myCommand.CommandType = CommandType.Text;

                SqlDataAdapter myDataAdapter = new SqlDataAdapter();
                myDataAdapter.SelectCommand = myCommand;
                myDataAdapter.TableMappings.Add("Table", "ms_acara");
                myDataAdapter.Fill(myDataSet);

                maxid = Convert.ToString(myDataSet.Tables[0].Rows[0]["acara_id"]);

                if (maxid != "")
                {
                    //Substring digunakan untuk memecah string id_karyawan jadi KRY + 05
                    //Substring(3, 2) maksudnya, mulai dari digit ke 3 (K = 0, R = 1, Y = 2, 0 = 3) dan diambil 2 karakter (0 dan 5)
                    //Kemudian di convert ke int, sehingga 5 + 1 = 6
                    id_user = Convert.ToInt32(maxid.Substring(3, 2)) + 1;
                    //Jika idbrg nya kurang dari 10 maka "KRY0" + 6 = "KRY06"
                    if (id_user < 10)
                    {
                        id = "ACR0" + id_user;
                    }
                    //Jika idbrg nya lebih dari sama dengan 10 dan kurang dari 100 (10 - 99) maka "KRY" + idbrg, idbrg = 10 jadi KRY10
                    else if (id_user >= 10 && id_user < 100)
                    {
                        id = "ACR" + id_user;
                    }
                }
                //Jika maxid kosong berarti tidak ada data karyawan, maka id dimulai dari KRY01
                else
                {
                    id = "ACR01";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            return id;
        }

        private void UCmasterAcara_Load(object sender, EventArgs e)
        {
            lblNotif.Hide();
            btnHapus.Hide();
            cbJenisTagihan.Text = "Pilih Jenis Tagihan";
            this.ms_acaraTableAdapter.Fill(this.dsAcaraDataSet.ms_acara);
            acara_ID = autoid();


            if (!cbJenisTagihan.Items.Contains("---Pilih Jenis Tagihan---"))
            {
                cbJenisTagihan.Items.Add("--Pilih Jenis Tagihan--");
            }

            cbJenisTagihan.Text = "--Pilih Jenis Tagihan--";
            
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Anda yakin ingin menghapus data ini?", "Konfirmasi", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                string myConnectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                SqlConnection myConnection = new SqlConnection(myConnectionstring);

                // buka connection
                myConnection.Open();

                // membuat data adapter
                SqlDataAdapter myAdapter = new SqlDataAdapter();

                // update command
                SqlCommand delete = new SqlCommand("sp_DeleteAcara", myConnection);
                delete.CommandType = CommandType.StoredProcedure;

                delete.Parameters.Add("@acara_id", SqlDbType.VarChar, 10).Value = acara_ID;


                myAdapter.UpdateCommand = delete;

                // coba untuk update, jika sukses commit
                // jika tidak roll back
                try
                {
                    delete.ExecuteNonQuery();

                    // tampilkan pesan jumlah baros data yang diupdate ke layar
                    MessageBox.Show(this, "Data berhasil dihapus! ", "Informasi",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    

                    this.ms_acaraTableAdapter.Fill(this.dsAcaraDataSet.ms_acara);
                    clear();
                    itungBatal = itungBatal + 1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Data gagal dihapus! : " + ex.Message);
                    // jika terjadi kegagalan dalam transaksi, batalkan semua (rollback)
                }
            }
            else if (dr == DialogResult.No)
            {

            }
        }


        private void clear()
        {
            labelBudgetAwal.Text = "Budget Awal";
            txtNama.Clear();
            txtBudgetAwal.Clear();
            txtTagihan.Clear();
            txtCari.Clear();
            cbJenisTagihan.Text = "--- Pilih Jenis Tagihan ---";
            btnSimpan.Enabled = true;
            btnHapus.Enabled = false;
            acara_ID = autoid();
            btnSimpan.Text = "Simpan";
            btnHapus.Hide();
            txtBudgetAwal.Enabled = true;
            hari = 0;
            cbJenisTagihan.Enabled = true;
            dtTglMulai.Enabled = true;
            txtTagihan.Enabled = true;
            tagihan = "";

            txtBudgetAwal.Text = "";
            budgetAwal = "";
            if (!cbJenisTagihan.Items.Contains("---Pilih Jenis Tagihan---"))
            {
                cbJenisTagihan.Items.Add("--Pilih Jenis Tagihan--");
            }

            cbJenisTagihan.Text = "--Pilih Jenis Tagihan--";
        }

        private void btnBatal_Click(object sender, EventArgs e)
        {
            clear();
            itungBatal = itungBatal + 1;
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            

        }

        private void dgAcara_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            foreach (DataGridViewRow row in dgAcara.SelectedRows)
            {
                try
                {
                    acara_ID = row.Cells[0].Value.ToString();
                    txtNama.Text = row.Cells[1].Value.ToString();
                    budgetAwal = row.Cells[2].Value.ToString();
                    cbJenisTagihan.SelectedItem = row.Cells[3].Value.ToString();
                    tagihan = row.Cells[4].Value.ToString();
                    dtTglMulai.Value = Convert.ToDateTime(dgAcara.Rows[e.RowIndex].Cells[5].Value);
                    dtTglAkhir.Value = Convert.ToDateTime(dgAcara.Rows[e.RowIndex].Cells[6].Value);


                    string sql = "SELECT acara_hari FROM ms_acara WHERE (acara_id = '" + acara_ID + "') ";
                    using (SqlConnection conn = new SqlConnection(connectionstring))
                    {
                        SqlCommand cmd = new SqlCommand(sql, conn);
                        conn.Open();
                        hari = (int)cmd.ExecuteScalar();

                    }
                }
                catch
                {

                }
                


                decimal moneyvalue = decimal.Parse(tagihan);
                txtTagihan.Text = String.Format("{0:C} ", moneyvalue);

                decimal moneyvalue2 = decimal.Parse(budgetAwal);
                txtBudgetAwal.Text = String.Format("{0:C} ", moneyvalue2);

            }
            dtTglMulai.Enabled = false;
            txtTagihan.Enabled = false;

            btnHapus.Show();
            btnHapus.Enabled = true;
            btnSimpan.Text = "Perbaharui";
            labelBudgetAwal.Text = "Budget";
            txtBudgetAwal.Enabled = false;
            cbJenisTagihan.Enabled = false;
        }

        private void txtCari_TextChanged(object sender, EventArgs e)
        {
            SqlConnection myConnection = new SqlConnection(connectionstring);

            SqlCommand search = new SqlCommand("sp_SearchAcara", myConnection);
            search.CommandType = CommandType.StoredProcedure;

            search.Parameters.AddWithValue("@kata_kunci", txtCari.Text);

            using (var adapter = new SqlDataAdapter(search))
            {
                myConnection.Open();
                var myTable = new DataTable();
                adapter.Fill(myTable);
                dgAcara.DataSource = myTable;
                myConnection.Close();
            }
        }

        private void cbJenisTagihan_DropDown(object sender, EventArgs e)
        {
            if (cbJenisTagihan.Items.Contains("--Pilih Jenis Tagihan--"))
                cbJenisTagihan.Items.Remove("--Pilih Jenis Tagihan--");
            for (int i = 0; i < itungBatal; i++)
            {
                cbJenisTagihan.Items.Remove("--Pilih Jenis Tagihan--");
            }
            itungBatal = 0;
        }

        private void cbJenisTagihan_DropDownClosed(object sender, EventArgs e)
        {
            if (!cbJenisTagihan.Items.Contains("--Pilih Jenis Tagihan--"))
            {
                cbJenisTagihan.Items.Add("--Pilih Jenis Tagihan--");
            }
            if (cbJenisTagihan.Text == "")
                cbJenisTagihan.Text = "--Pilih Jenis Tagihan--";
        }

        private void txtBudgetAwal_Leave(object sender, EventArgs e)
        {
            
        }

        private void txtBudgetAwal_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)8;
            if (e.KeyChar == (char)13)
            {
                txtBudgetAwal.Text = string.Format("{0:n0}", double.Parse(txtBudgetAwal.Text));
            }
        }

        private void txtNama_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void cbJenisTagihan_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)8;
        }

        private void txtTagihan_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)8;
        }

        private void txtNama_Click(object sender, EventArgs e)
        {
            
        }

        private void txtNama_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
           // txtCari.Text = e.KeyCode.ToString();
            
        }

        private void txtNama_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txtBudgetAwal_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtBudgetAwal_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            try
            {

                if (char.IsNumber(e.KeyChar) && !char.IsControl(e.KeyChar))
                {

                    e.Handled = true;

                }

                if (char.IsLetter(e.KeyChar))
                {

                    e.Handled = true;

                }

                if (char.IsControl(e.KeyChar))
                {

                    txtBudgetAwal.Text = "";
                    budgetAwal = "";

                }

               

                if (char.IsNumber(e.KeyChar))
                {

                    budgetAwal = budgetAwal + e.KeyChar.ToString();
                    decimal moneyvalue = decimal.Parse(budgetAwal);
                    txtBudgetAwal.Text = String.Format("{0:C} ", moneyvalue);
                }
            }
            catch
            {
                
            }



        }

        private void txtBudgetAwal_Leave_1(object sender, EventArgs e)
        {
           // decimal moneyvalue = decimal.Parse(txtBudgetAwal.Text);
           // txtBudgetAwal.Text = String.Format("{0:C} ", moneyvalue);
        }

        private void txtTagihan_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            try
            {


                if (char.IsNumber(e.KeyChar) && !char.IsControl(e.KeyChar))
                {

                    e.Handled = true;

                }

                if (char.IsLetter(e.KeyChar))
                {

                    e.Handled = true;

                }

                if (char.IsControl(e.KeyChar))
                {

                    txtTagihan.Text = "";
                    tagihan = "";

                }

                if (char.IsNumber(e.KeyChar))
                {

                    tagihan = tagihan + e.KeyChar.ToString();
                    decimal moneyvalue = decimal.Parse(tagihan);
                    txtTagihan.Text = String.Format("{0:C} ", moneyvalue);
                }
            }
            catch
            {
                e.Handled = true;
            }

        }

        private void cbJenisTagihan_DropDown_1(object sender, EventArgs e)
        {
            if (cbJenisTagihan.Items.Contains("--Pilih Jenis Tagihan--"))
                cbJenisTagihan.Items.Remove("--Pilih Jenis Tagihan--");
            for (int i = 0; i < itungBatal; i++)
            {
                cbJenisTagihan.Items.Remove("--Pilih Jenis Tagihan--");
            }
            itungBatal = 0;
        }

        private void txtNama_MouseMove(object sender, MouseEventArgs e)
        {

        }

  

        TimeSpan getDateDifference(DateTime date1, DateTime date2)
        {
            TimeSpan ts = date1 - date2;

            return ts;
        }

        public void isValidNama()
        {
            if (txtNama.Text != "")
            {
                errorWarning.SetError(txtNama, "");
                errorBenar.SetError(txtNama, "Benar");

            }
            if (txtNama.Text == "")
            {
                errorBenar.SetError(txtNama, "");
                errorWarning.SetError(txtNama, "Nama harus diisi");
                btnSimpan.Enabled = false;
            }

        }

        private void dtTglAkhir_ValueChanged(object sender, EventArgs e)
        {
            if(cbJenisTagihan.Text == "Mingguan")
            {
                
                if (dtTglMulai.Value.AddDays(6) >= dtTglAkhir.Value)
                {
                    lblNotif.Show();
                    lblNotif.Text = "Tanggal selesai acara harus \nlebih dari 1 minggu dari tanggal mulai acara";
                    
                    btnSimpan.Enabled = false;

                }
                else
                {
                    lblNotif.Hide();
                    btnSimpan.Enabled = true;
                }
            }else
            if (cbJenisTagihan.Text == "Bulanan")
            {

                if (dtTglMulai.Value.AddMonths(1) >= dtTglAkhir.Value.AddDays(1))
                {
                    lblNotif.Show();
                    lblNotif.Text = "Tanggal selesai acara harus \nlebih dari 1 bulan dari tanggal mulai acara";

                    btnSimpan.Enabled = false;

                }
                else
                {
                    lblNotif.Hide();
                    btnSimpan.Enabled = true;
                }
            }
            else
            if (cbJenisTagihan.Text == "Tahunan")
            {

                if (dtTglMulai.Value.AddYears(1) >= dtTglAkhir.Value.AddDays(1))
                {
                    lblNotif.Show();
                    lblNotif.Text = "Tanggal selesai acara harus \nlebih dari 1 tahun dari tanggal mulai acara";
                    btnSimpan.Enabled = false;
                }
                else
                {
                    lblNotif.Hide();
                    btnSimpan.Enabled = true;
                } 
            }

        }

        private void cbJenisTagihan_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void cbJenisTagihan_DropDownClosed_1(object sender, EventArgs e)
        {
            if (cbJenisTagihan.Text == "Mingguan")
                dtTglAkhir.Value = dtTglMulai.Value.AddDays(7);
            if (cbJenisTagihan.Text == "Bulanan")
                dtTglAkhir.Value = dtTglMulai.Value.AddMonths(1);
            if (cbJenisTagihan.Text == "Tahunan")
                dtTglAkhir.Value = dtTglMulai.Value.AddYears(1);

            if (cbJenisTagihan.Text == "")
            {

            }
            else
            {
                dtTglAkhir.Enabled = true;
                dtTglMulai.Enabled = true;
            }
        }

        private void dtTglMulai_ValueChanged(object sender, EventArgs e)
        {
            if(cbJenisTagihan.Text == "Mingguan")
            dtTglAkhir.Value = dtTglMulai.Value.AddDays(7);
            if (cbJenisTagihan.Text == "Bulanan")
                dtTglAkhir.Value = dtTglMulai.Value.AddMonths(1);
            if (cbJenisTagihan.Text == "Tahunan")
                dtTglAkhir.Value = dtTglMulai.Value.AddYears(1);
        }

        private void btnSimpan_Click_1(object sender, EventArgs e)
        {
            if (btnSimpan.Text == "Simpan")
            {
                connectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                SqlConnection connection = new SqlConnection(connectionstring);
                SqlCommand insert = new SqlCommand("sp_InputAcara", connection);

                insert.CommandType = CommandType.StoredProcedure;
                try
                {
                    if (txtNama.Text == "" || cbJenisTagihan.SelectedItem.ToString() == "" || txtBudgetAwal.Text == "" || txtTagihan.Text == "")
                    {
                        MessageBox.Show(this, "Data Tidak Boleh Kosong!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {

                        insert.Parameters.AddWithValue("acara_id", acara_ID);
                        insert.Parameters.AddWithValue("acara_nama", txtNama.Text);
                        insert.Parameters.AddWithValue("acara_budget", budgetAwal);
                        insert.Parameters.AddWithValue("acara_jenis_tagihan", cbJenisTagihan.SelectedItem.ToString());
                        insert.Parameters.AddWithValue("acara_jumlah_tagihan", tagihan);
                        insert.Parameters.AddWithValue("acara_tanggal_mulai", dtTglMulai.Value.Date);
                        insert.Parameters.AddWithValue("acara_tanggal_berakhir", dtTglAkhir.Value.Date);

                        TimeSpan difference = getDateDifference(dtTglAkhir.Value, dtTglMulai.Value);
                        int differenceInDays = difference.Days;
                        hari = differenceInDays;


                        insert.Parameters.AddWithValue("acara_hari", hari);
                        try
                        {
                            connection.Open();
                            insert.ExecuteNonQuery();
                            MessageBox.Show(this, "Data berhasil disimpan", "Information",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            clear();
                            this.ms_acaraTableAdapter.Fill(this.dsAcaraDataSet.ms_acara);

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(this, "Tidak berhasil disimpan!: " + ex.Message);
                        }
                    }
                }
                catch
                {
                    MessageBox.Show(this, "Data Tidak Boleh Kosong!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }



            if (btnSimpan.Text == "Perbaharui")
            {
                string id = acara_ID;
                string nama = txtNama.Text;
                string budget = txtBudgetAwal.Text;
                string jenistagihan = cbJenisTagihan.SelectedItem.ToString();
                string jumlahtagihan = txtTagihan.Text;


                string connectionstring =
                  "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                SqlConnection connection = new SqlConnection(connectionstring);
                SqlCommand insert = new SqlCommand("sp_UpdateAcara", connection);
                insert.CommandType = CommandType.StoredProcedure;


                if (txtNama.Text == "" || cbJenisTagihan.SelectedItem.ToString() == "" || txtBudgetAwal.Text == "" || txtTagihan.Text == "")
                {
                    MessageBox.Show(this, "Data Tidak Boleh Kosong!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {
                    insert.Parameters.AddWithValue("acara_id", acara_ID);
                    insert.Parameters.AddWithValue("acara_nama", txtNama.Text);
                    insert.Parameters.AddWithValue("acara_tanggal_mulai", dtTglMulai.Value.Date);
                    insert.Parameters.AddWithValue("acara_tanggal_berakhir", dtTglAkhir.Value.Date);


                    TimeSpan difference = getDateDifference(dtTglAkhir.Value, dtTglMulai.Value);
                    int differenceInDays = difference.Days;
                    hari = differenceInDays;


                    insert.Parameters.AddWithValue("acara_hari", hari);
                    try
                    {
                        connection.Open();
                        insert.ExecuteNonQuery();
                        MessageBox.Show(this, "Data Berhasil diperbarui!", "Informasi",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                        clear();
                        this.ms_acaraTableAdapter.Fill(this.dsAcaraDataSet.ms_acara);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Data gagal diperbarui! : " + ex.Message);
                    }
                }
            }
        }

        private void btnBatal_Click_1(object sender, EventArgs e)
        {
            clear();
            itungBatal = itungBatal + 1;
        }

        private void btnHapus_Click_1(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Anda yakin ingin menghapus data ini?", "Konfirmasi", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                string myConnectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                SqlConnection myConnection = new SqlConnection(myConnectionstring);

                // buka connection
                myConnection.Open();

                // membuat data adapter
                SqlDataAdapter myAdapter = new SqlDataAdapter();

                // update command
                SqlCommand delete = new SqlCommand("sp_DeleteAcara", myConnection);
                delete.CommandType = CommandType.StoredProcedure;

                delete.Parameters.Add("@acara_id", SqlDbType.VarChar, 10).Value = acara_ID;


                myAdapter.UpdateCommand = delete;

                // coba untuk update, jika sukses commit
                // jika tidak roll back
                try
                {
                    delete.ExecuteNonQuery();

                    // tampilkan pesan jumlah baros data yang diupdate ke layar
                    MessageBox.Show(this, "Data berhasil dihapus! ", "Informasi",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);


                    this.ms_acaraTableAdapter.Fill(this.dsAcaraDataSet.ms_acara);
                    clear();
                    itungBatal = itungBatal + 1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Data Tidak Dapat dihapus\nKarena Berhubungan Dengan Tabel Lain");
                    // jika terjadi kegagalan dalam transaksi, batalkan semua (rollback)
                }
            }
            else if (dr == DialogResult.No)
            {

            }
        }

        private void lblNotif_Click(object sender, EventArgs e)
        {

        }

        private void dgAcara_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
