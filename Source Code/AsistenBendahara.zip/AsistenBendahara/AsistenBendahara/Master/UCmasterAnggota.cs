﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MetroFramework;
using System.Text.RegularExpressions;

namespace AsistenBendahara.Master
{
    public partial class UCmasterAnggota : UserControl
    {
        string user_ID;
        string connectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
        public UCmasterAnggota()
        {
            InitializeComponent();
        }

        private string autoid()
        {
            DataSet myDataSet = new DataSet();
            string maxid = "";
            int id_user;
            string id = "";

            try
            {

                string myConnectionString = "integrated security=true;data source =.; initial catalog = PRG2_SILABI";

                SqlConnection myConnection = new SqlConnection(myConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Connection = myConnection;

                myCommand.CommandText = "SELECT MAX(user_id) AS user_id FROM ms_user";
                myCommand.CommandType = CommandType.Text;

                SqlDataAdapter myDataAdapter = new SqlDataAdapter();
                myDataAdapter.SelectCommand = myCommand;
                myDataAdapter.TableMappings.Add("Table", "ms_user");
                myDataAdapter.Fill(myDataSet);

                maxid = Convert.ToString(myDataSet.Tables[0].Rows[0]["user_id"]);

                if (maxid != "")
                {
                    //Substring digunakan untuk memecah string id_karyawan jadi KRY + 05
                    //Substring(3, 2) maksudnya, mulai dari digit ke 3 (K = 0, R = 1, Y = 2, 0 = 3) dan diambil 2 karakter (0 dan 5)
                    //Kemudian di convert ke int, sehingga 5 + 1 = 6
                    id_user = Convert.ToInt32(maxid.Substring(3, 2)) + 1;
                    //Jika idbrg nya kurang dari 10 maka "KRY0" + 6 = "KRY06"
                    if (id_user < 10)
                    {
                        id = "USR0" + id_user;
                    }
                    //Jika idbrg nya lebih dari sama dengan 10 dan kurang dari 100 (10 - 99) maka "KRY" + idbrg, idbrg = 10 jadi KRY10
                    else if (id_user >= 10 && id_user < 100)
                    {
                        id = "USR" + id_user;
                    }
                }
                //Jika maxid kosong berarti tidak ada data karyawan, maka id dimulai dari KRY01
                else
                {
                    id = "USR01";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            return id;
        }

        private void txtNoTelepon_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void UCmasterAnggota_Load(object sender, EventArgs e)
        {
            btnHapus.Hide();
            if (rbLaki.Checked)
            {
                rbLaki.Checked = false;
            }

            this.ms_userTableAdapter.Fill(this.pRG2_SILABIDataSet.ms_user);
            user_ID = autoid();
            btnSimpan.Enabled = false;


            

        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            
        }

        private void clear()
        {
            re3.Clear();
            re1.Hide();
            re2.Hide();
            re3.Hide();
            txtUsername.Enabled = Enabled;
            txtNama.Clear();
            txtAlamat.Clear();
            txtCari.Clear();
            txtEmail.Clear();
            txtNoTelepon.Clear();
            txtUsername.Clear();
            txtPassword.Clear();
            if (rbLaki.Checked)
            {
                rbLaki.Checked = false;
            }
            if (rbPerempuan.Checked)
            {
                rbPerempuan.Checked = false;
            }
            btnSimpan.Enabled = true;

            btnHapus.Enabled = false;
            user_ID = autoid();
            btnSimpan.Text = "Simpan";
            btnHapus.Hide();
            btnSimpan.Enabled = false;

            cbJenisTagihan.Enabled = true;
        }

        private void btnBatal_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {



        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void metroGrid2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            foreach (DataGridViewRow row in dgUser.SelectedRows)
            {
                String tempGender = "";

                user_ID = row.Cells[0].Value.ToString();
                txtNama.Text = row.Cells[1].Value.ToString();
                txtEmail.Text = row.Cells[2].Value.ToString();
                txtAlamat.Text = row.Cells[3].Value.ToString();
                txtNoTelepon.Text = row.Cells[4].Value.ToString();
                tempGender = row.Cells[5].Value.ToString();
                txtUsername.Text = row.Cells[6].Value.ToString(); ;
                txtPassword.Text = row.Cells[7].Value.ToString(); ;
                if (tempGender == "Laki - Laki")
                {
                    rbLaki.Checked = true;

                }
                if (tempGender == "Perempuan")
                {
                    rbPerempuan.Checked = true;

                }
                cbJenisTagihan.Enabled = false;


            }
            btnHapus.Show();
            btnHapus.Enabled = true;
            btnSimpan.Text = "Perbaharui";
            btnSimpan.Enabled = true;
            txtUsername.Enabled = false;
        }

        private void txtCari_TextChanged(object sender, EventArgs e)
        {
            SqlConnection myConnection = new SqlConnection(connectionstring);

            SqlCommand search = new SqlCommand("sp_SearchUser", myConnection);
            search.CommandType = CommandType.StoredProcedure;

            search.Parameters.AddWithValue("@kata_kunci", txtCari.Text);

            using (var adapter = new SqlDataAdapter(search))
            {
                myConnection.Open();
                var myTable = new DataTable();
                adapter.Fill(myTable);
                dgUser.DataSource = myTable;
                myConnection.Close();
            }
        }

        private void txtNama_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {

        }

        private void txtNama_Leave(object sender, EventArgs e)
        {

        }

        private void metroLabel4_Click(object sender, EventArgs e)
        {

        }

        private void cbJenisKelamin_DropDown(object sender, EventArgs e)
        {

        }

        private void txtNoTelepon_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtNoTelepon_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtUsername_Leave(object sender, EventArgs e)
        {
            connectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand cmd = new SqlCommand("Select user_id from ms_user where user_username= @user_username", connection);
            cmd.Parameters.AddWithValue("@user_username", this.txtUsername.Text);
            connection.Open();
            var result = cmd.ExecuteScalar();
            if (result != null)
            {
                errorBenar.SetError(txtUsername, "");
                errorWarning.SetError(txtUsername, "Username "+ this.txtUsername.Text+" Sudah ada");
                btnSimpan.Enabled = false;
              
            }
            
        }

        private void txtPassword_Leave(object sender, EventArgs e)
        {

        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtNoTelepon_Leave(object sender, EventArgs e)
        {


        }

        private void btnSimpan_MouseMove(object sender, MouseEventArgs e)
        {



        }

        private void btnSimpan_Move(object sender, EventArgs e)
        {
        }


        public void isValidTelp()
        {
            if (txtNoTelepon.TextLength > 10)
            {
                errorWarning.SetError(txtNoTelepon, "");
                errorBenar.SetError(txtNoTelepon, "Benar");

            }
            if (txtNoTelepon.TextLength <= 10)
            {
                errorBenar.SetError(txtNoTelepon, "");
                errorWarning.SetError(txtNoTelepon, "Nomor HP minimal 10 digit");
                btnSimpan.Enabled = false;
            }


        }

        public void isValidUsername()
        {
            if (txtUsername.TextLength > 5)
            {
                errorWarning.SetError(txtUsername, "");
                errorBenar.SetError(txtUsername, "Benar");

            }
            if (txtUsername.TextLength <= 5)
            {
                errorBenar.SetError(txtUsername, "");
                errorWarning.SetError(txtUsername, "Username minimal 6 karakter");
                btnSimpan.Enabled = false;
            }

        }


        public void isValidNama()
        {
            if (txtNama.Text == "")
            {
                errorBenar.SetError(txtNama, "");
                errorWarning.SetError(txtNama, "Data tidak boleh kosong");
                btnSimpan.Enabled = false;
            }
            else
            {
                errorWarning.SetError(txtNama, "");
                errorBenar.SetError(txtNama, "Benar");

            }

        }

        public void isValidEmail()
        {
            if (Regex.IsMatch(txtEmail.Text, @"^^[^@\s]+@[^@\s]+(\.[^@\s]+)+$"))
            {
                errorWarning.SetError(txtEmail, "");
                errorBenar.SetError(txtEmail, "Benar");

            }
            if (!Regex.IsMatch(txtEmail.Text, @"^^[^@\s]+@[^@\s]+(\.[^@\s]+)+$"))
            {
                errorBenar.SetError(txtEmail, "");
                errorWarning.SetError(txtEmail, "Format Email Salah.");
                btnSimpan.Enabled = false;
            }

        }

        public void isValidPassword()
        {
            if (txtPassword.TextLength > 5  && isValidrePassword())
            {
                errorWarning.SetError(txtPassword, "");
                errorBenar.SetError(txtPassword, "Benar");

            }else
            if (txtPassword.TextLength <= 5)
            {
                errorBenar.SetError(txtPassword, "");
                errorWarning.SetError(txtPassword, "Password minimal 6 karakter");
                btnSimpan.Enabled = false;
            }

        }

        public void isValidKelamin()
        {
            if (rbLaki.Checked == true || rbPerempuan.Checked == true)
            {
                errorWarning.SetError(rbPerempuan, "");
                errorBenar.SetError(rbPerempuan, "Benar");

            }
            if (rbLaki.Checked == false && rbPerempuan.Checked == false)
            {
                errorBenar.SetError(rbPerempuan, "");
                errorWarning.SetError(rbPerempuan, "Wajib memilih jenis kelamin");
                btnSimpan.Enabled = false;
            }

        }
        private void UCmasterAnggota_MouseMove(object sender, MouseEventArgs e)
        {
            isValidEmail();
            isValidKelamin();
            isValidNama();
            isValidTelp();
            isValidUsername();
            isValidPassword();


            if (errorBenar.GetError(txtNama) == "Benar" && errorBenar.GetError(txtUsername) == "Benar" && errorBenar.GetError(txtPassword) == "Benar" && errorBenar.GetError(txtNoTelepon) == "Benar"
        && errorBenar.GetError(txtEmail) == "Benar" && errorBenar.GetError(rbPerempuan) == "Benar" && errorBenar.GetError(txtNoTelepon) == "Benar")
            {
                btnSimpan.Enabled = Enabled;
            }
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUsername_MouseHover(object sender, EventArgs e)
        {

        }

        private void btnSimpan_Click_1(object sender, EventArgs e)
        {




            if (btnSimpan.Text == "Simpan")
            {
                connectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                SqlConnection connection = new SqlConnection(connectionstring);
                SqlCommand insert = new SqlCommand("sp_InputUser", connection);

                insert.CommandType = CommandType.StoredProcedure;
                if (txtEmail.Text == "" || txtNama.Text == "" || txtNoTelepon.Text == "")
                {
                    MessageBox.Show(this, "Data Tidak Boleh Kosong!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {
                    String tempGender = "";
                    if (rbLaki.Checked)
                    {
                        tempGender = "Laki - Laki";
                    }
                    if (rbPerempuan.Checked)
                    {
                        tempGender = "Perempuan";
                    }

                    insert.Parameters.AddWithValue("user_id", user_ID);
                    insert.Parameters.AddWithValue("user_nama", txtNama.Text);
                    insert.Parameters.AddWithValue("user_email", txtEmail.Text);
                    insert.Parameters.AddWithValue("user_no_hp", txtNoTelepon.Text);
                    insert.Parameters.AddWithValue("user_alamat", txtAlamat.Text);
                    insert.Parameters.AddWithValue("user_jenis_kelamin", tempGender);
                    insert.Parameters.AddWithValue("user_username", txtUsername.Text);
                    insert.Parameters.AddWithValue("user_password", txtPassword.Text);
                    int role = 0;

                    if (cbJenisTagihan.SelectedItem.ToString() == "Bendahara")
                    {
                        role = 1;
                    }else if(cbJenisTagihan.SelectedItem.ToString() == "Ketua")
                    {
                        role = 4;
                    }
                    else
                    {
                        role = 2;
                    }
                    insert.Parameters.AddWithValue("role_id",role );
                   // insert.Parameters.AddWithValue("role_id", "2");

                    try
                    {
                        connection.Open();
                        insert.ExecuteNonQuery();
                        MessageBox.Show(this, "Data berhasil disimpan", "Information",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        clear();
                        this.ms_userTableAdapter.Fill(this.pRG2_SILABIDataSet.ms_user);

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Tidak berhasil disimpan!: " + ex.Message);
                    }
                }
            }
            if (btnSimpan.Text == "Perbaharui")
            {
                string id = user_ID;
                string nama = txtNama.Text;
                string alamat = txtAlamat.Text;
                string email = txtEmail.Text;
                string no_telepon = txtNoTelepon.Text;
                string jenis_kel = "";
                if (rbLaki.Checked)
                {
                    jenis_kel = "Laki - Laki";
                }
                if (rbPerempuan.Checked)
                {
                    jenis_kel = "Perempuan";
                }



                string connectionstring =
                  "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                SqlConnection connection = new SqlConnection(connectionstring);
                SqlCommand insert = new SqlCommand("sp_UpdateUser", connection);
                insert.CommandType = CommandType.StoredProcedure;


                if ( txtEmail.Text == "" || txtNama.Text == "" || txtNoTelepon.Text == "")
                {
                    MessageBox.Show(this, "Data Tidak Boleh Kosong!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {
                    String tempGender = "";
                    if (rbLaki.Checked)
                    {
                        tempGender = "Laki - Laki";
                    }
                    if (rbPerempuan.Checked)
                    {
                        tempGender = "Perempuan";
                    }
                    insert.Parameters.AddWithValue("user_id", user_ID);
                    insert.Parameters.AddWithValue("user_nama", txtNama.Text);
                    insert.Parameters.AddWithValue("user_email", txtEmail.Text);
                    insert.Parameters.AddWithValue("user_no_hp", txtNoTelepon.Text);
                    insert.Parameters.AddWithValue("user_alamat", txtAlamat.Text);
                    insert.Parameters.AddWithValue("user_jenis_kelamin", tempGender);
                    int role = 0;

                   
                    try
                    {
                        connection.Open();
                        insert.ExecuteNonQuery();
                        MessageBox.Show(this, "Data Berhasil diperbarui!", "Informasi",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        clear();
                        this.ms_userTableAdapter.Fill(this.pRG2_SILABIDataSet.ms_user);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Data gagal diperbarui! : " + ex.Message);
                    }
                }
            }

        }

        private void btnHapus_Click_1(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Anda yakin ingin menghapus data ini?", "Konfirmasi", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                string myConnectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                SqlConnection myConnection = new SqlConnection(myConnectionstring);

                // buka connection
                myConnection.Open();

                // membuat data adapter
                SqlDataAdapter myAdapter = new SqlDataAdapter();

                // update command
                SqlCommand delete = new SqlCommand("sp_DeleteUser", myConnection);
                delete.CommandType = CommandType.StoredProcedure;

                delete.Parameters.Add("@user_id", SqlDbType.VarChar, 10).Value = user_ID;


                myAdapter.UpdateCommand = delete;

                // coba untuk update, jika sukses commit
                // jika tidak roll back
                try
                {
                    delete.ExecuteNonQuery();

                    // tampilkan pesan jumlah baros data yang diupdate ke layar
                    MessageBox.Show(this, "Data berhasil dihapus! ", "Informasi",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.ms_userTableAdapter.Fill(this.pRG2_SILABIDataSet.ms_user);
                    clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Data Tidak Dapat dihapus\nKarena Berhubungan Dengan Tabel Lain");
                    // jika terjadi kegagalan dalam transaksi, batalkan semua (rollback)
                }
            }
            else if (dr == DialogResult.No)
            {

            }
        }

        private void btnBatal_Click_1(object sender, EventArgs e)
        {
            clear();
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            re1.Visible = true;
            re2.Visible = true;
            re3.Visible = true;
            isValidrePassword();
        }

        public Boolean isValidrePassword()
        {
            if (txtPassword.Text == re3.Text)
            {
                errorWarning.SetError(txtPassword, "");
                errorBenar.SetError(txtPassword, "Benar");
                return true;
            }
            else
            {
                errorBenar.SetError(txtPassword, "");
                errorWarning.SetError(txtPassword, "re-Password tidak sama");
                btnSimpan.Enabled = false;
                return false;
            }
            return false;

        }

        private void re3_MouseLeave(object sender, EventArgs e)
        {
            if (isValidrePassword())
            {
                re1.Visible = false;
                re2.Visible = false;
                re3.Visible = false;
            }
        }

        private void re3_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }


}

