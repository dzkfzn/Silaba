﻿namespace AsistenBendahara
{


    partial class PRG2_SILABIDataSet
    {
        partial class ms_userDataTable
        {
        }

        partial class ms_userDataTable
        {
        }
    }
}
