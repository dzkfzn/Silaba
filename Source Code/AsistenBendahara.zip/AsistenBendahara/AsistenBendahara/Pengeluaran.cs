﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsistenBendahara.Laporan
{
    public partial class Pengeluaran : UserControl
    {
        public Pengeluaran()
        {
            InitializeComponent();
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void Pengeluaran_Load(object sender, EventArgs e)
        {
          //  this.ms_acaraTableAdapter.Fill(this.pRG2_SILABIDataSet11.ms_acara);
        }
    }
}
