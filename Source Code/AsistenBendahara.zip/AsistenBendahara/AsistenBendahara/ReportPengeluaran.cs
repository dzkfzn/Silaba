﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsistenBendahara.Lain_Lain
{
    public partial class ReportPengeluaran : MetroFramework.Forms.MetroForm
    {
        public ReportPengeluaran()
        {
            InitializeComponent();
        }

        private void ReportPengeluaran_Load(object sender, EventArgs e)
        {
          //  this..Fill(this.ReportBaru.DataTable1, dtTglMulai.Value.ToShortDateString(), dtTglAkhir.Value.ToShortDateString(), cbJenisTagihan.SelectedValue.ToString());

            this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {

        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
