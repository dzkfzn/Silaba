﻿namespace AsistenBendahara.Transaksi
{
    partial class UCLihatPemasukan
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtCari = new System.Windows.Forms.TextBox();
            this.dgPemasukan = new MetroFramework.Controls.MetroGrid();
            this.rbNonAnggota = new System.Windows.Forms.RadioButton();
            this.rbPemasukanAnggota = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgPemasukan)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCari
            // 
            this.txtCari.Location = new System.Drawing.Point(86, 119);
            this.txtCari.Name = "txtCari";
            this.txtCari.Size = new System.Drawing.Size(814, 20);
            this.txtCari.TabIndex = 63;
            // 
            // dgPemasukan
            // 
            this.dgPemasukan.AllowUserToAddRows = false;
            this.dgPemasukan.AllowUserToDeleteRows = false;
            this.dgPemasukan.AllowUserToResizeRows = false;
            this.dgPemasukan.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.dgPemasukan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgPemasukan.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgPemasukan.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPemasukan.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgPemasukan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgPemasukan.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgPemasukan.EnableHeadersVisualStyles = false;
            this.dgPemasukan.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgPemasukan.GridColor = System.Drawing.Color.White;
            this.dgPemasukan.Location = new System.Drawing.Point(39, 161);
            this.dgPemasukan.Name = "dgPemasukan";
            this.dgPemasukan.ReadOnly = true;
            this.dgPemasukan.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPemasukan.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgPemasukan.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgPemasukan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgPemasukan.Size = new System.Drawing.Size(861, 331);
            this.dgPemasukan.TabIndex = 60;
            // 
            // rbNonAnggota
            // 
            this.rbNonAnggota.AutoSize = true;
            this.rbNonAnggota.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.rbNonAnggota.ForeColor = System.Drawing.Color.White;
            this.rbNonAnggota.Location = new System.Drawing.Point(209, 95);
            this.rbNonAnggota.Name = "rbNonAnggota";
            this.rbNonAnggota.Size = new System.Drawing.Size(196, 22);
            this.rbNonAnggota.TabIndex = 70;
            this.rbNonAnggota.TabStop = true;
            this.rbNonAnggota.Text = "Pemasukan Non-Anggota";
            this.rbNonAnggota.UseVisualStyleBackColor = true;
            this.rbNonAnggota.CheckedChanged += new System.EventHandler(this.rbNonAnggota_CheckedChanged_1);
            // 
            // rbPemasukanAnggota
            // 
            this.rbPemasukanAnggota.AutoSize = true;
            this.rbPemasukanAnggota.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.rbPemasukanAnggota.ForeColor = System.Drawing.Color.White;
            this.rbPemasukanAnggota.Location = new System.Drawing.Point(40, 95);
            this.rbPemasukanAnggota.Name = "rbPemasukanAnggota";
            this.rbPemasukanAnggota.Size = new System.Drawing.Size(163, 22);
            this.rbPemasukanAnggota.TabIndex = 69;
            this.rbPemasukanAnggota.TabStop = true;
            this.rbPemasukanAnggota.Text = "Pemasukan Anggota";
            this.rbPemasukanAnggota.UseVisualStyleBackColor = true;
            this.rbPemasukanAnggota.CheckedChanged += new System.EventHandler(this.rbPemasukanAnggota_CheckedChanged_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(33, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(322, 42);
            this.label3.TabIndex = 71;
            this.label3.Text = "Lihat Pemasukan";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(37, 119);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 18);
            this.label13.TabIndex = 72;
            this.label13.Text = "Cari :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(37, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 15);
            this.label5.TabIndex = 115;
            this.label5.Text = "Table Pemasukan";
            // 
            // UCLihatPemasukan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rbNonAnggota);
            this.Controls.Add(this.rbPemasukanAnggota);
            this.Controls.Add(this.txtCari);
            this.Controls.Add(this.dgPemasukan);
            this.Name = "UCLihatPemasukan";
            this.Size = new System.Drawing.Size(1116, 608);
            this.Load += new System.EventHandler(this.UCLihatPemasukan_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgPemasukan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtCari;
        private MetroFramework.Controls.MetroGrid dgPemasukan;
        private System.Windows.Forms.RadioButton rbNonAnggota;
        private System.Windows.Forms.RadioButton rbPemasukanAnggota;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label5;
    }
}
