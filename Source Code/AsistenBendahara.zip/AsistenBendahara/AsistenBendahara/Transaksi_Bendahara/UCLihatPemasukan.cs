﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AsistenBendahara.Transaksi
{
    public partial class UCLihatPemasukan : UserControl
    {
        public UCLihatPemasukan()
        {
            InitializeComponent();
        }

        private void UCLihatPemasukan_Load(object sender, EventArgs e)
        {
            //LoadAnggotaNonAnggota();
            LoadFormAnggota();
            rbPemasukanAnggota.Checked = true;
        }

        public void LoadFormAnggota()
        {
            dgPemasukan.DataSource = null;

            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";

            var select = @"
SELECT        tr_detail_pemasukan_acara.tagihan_id AS [ID Tagihan], ms_user.user_nama AS [Nama Anggota], ms_acara.acara_nama AS [Nama Acara], tr_detail_pemasukan_acara.dtl_tanggal AS [Tanggal Bayar], 
                         tr_detail_pemasukan_acara.dtl_jumlah AS Jumlah, tr_tagihan.tagihan_status AS [Status Tagihan], tr_tagihan.tagihan_tgl_deadline AS [Tanggal Deadline Tagihan]
FROM            tr_detail_pemasukan_acara INNER JOIN
                         tr_tagihan ON tr_detail_pemasukan_acara.tagihan_id = tr_tagihan.tagihan_id INNER JOIN
                         ms_acara ON tr_detail_pemasukan_acara.acara_id = ms_acara.acara_id AND tr_tagihan.acara_id = ms_acara.acara_id INNER JOIN
                         ms_user ON tr_detail_pemasukan_acara.user_id = ms_user.user_id AND tr_tagihan.user_id = ms_user.user_id";
            var c = new SqlConnection(ConnectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dgPemasukan.ReadOnly = true;
            dgPemasukan.DataSource = ds.Tables[0];
            this.dgPemasukan.Columns["Tanggal Bayar"].DefaultCellStyle.Format = "D";
            this.dgPemasukan.Columns["Tanggal Deadline Tagihan"].DefaultCellStyle.Format = "D";
            this.dgPemasukan.Columns["Jumlah"].DefaultCellStyle.Format = "C0";

            //dgPemasukan.AutoResizeColumns();
            //dgPemasukan.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            //dgPemasukan.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

            for (int i = 0; i < dgPemasukan.Columns.Count; i++)
            {
                dgPemasukan.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                int colw = dgPemasukan.Columns[i].Width;
                dgPemasukan.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                dgPemasukan.Columns[i].Width = 130;
            }
            //    rbSemua.Checked = true;
        }

        public void LoadAnggotaNonAnggota()
        {
            dgPemasukan.DataSource = null;

            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";

            var select = @"SELECT        ms_acara.acara_nama AS 'Nama Acara', tr_detail_pemasukan_acara.dtl_nama AS 'Nama Penyumbang', tr_detail_pemasukan_acara.dtl_tanggal AS 'Tanggal Transaksi', tr_detail_pemasukan_acara.dtl_jumlah AS 'Jumlah Pemasukan', tr_detail_pemasukan_acara.dtl_keterangan AS 'Keterangan'
FROM            ms_acara INNER JOIN
                         tr_detail_pemasukan_acara ON ms_acara.acara_id = tr_detail_pemasukan_acara.acara_id WHERE NOT tr_detail_pemasukan_acara.dtl_nama = ''";
            var c = new SqlConnection(ConnectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dgPemasukan.ReadOnly = true;
            dgPemasukan.DataSource = ds.Tables[0];
            this.dgPemasukan.Columns["Tanggal Transaksi"].DefaultCellStyle.Format = "D";

            this.dgPemasukan.Columns["Jumlah Pemasukan"].DefaultCellStyle.Format = "C0";

            //    rbSemua.Checked = true;
        }

        private void rbPemasukanAnggota_CheckedChanged(object sender, EventArgs e)
        {
            LoadFormAnggota();
        }

        private void rbNonAnggota_CheckedChanged(object sender, EventArgs e)
        {
            LoadAnggotaNonAnggota();
        }

        private void btnBatal_Click(object sender, EventArgs e)
        {

        }

        private void rbPemasukanAnggota_CheckedChanged_1(object sender, EventArgs e)
        {
            LoadFormAnggota();
        }

        private void rbNonAnggota_CheckedChanged_1(object sender, EventArgs e)
        {
            LoadAnggotaNonAnggota();
        }
    }
}
