﻿namespace AsistenBendahara.Transaksi_Bendahara
{
    partial class UCLihatPengeluaran
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtCari = new System.Windows.Forms.TextBox();
            this.dgPemasukan = new MetroFramework.Controls.MetroGrid();
            this.label1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.silaba = new AsistenBendahara.silaba();
            this.lihatPengeluaranBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lihatPengeluaranTableAdapter = new AsistenBendahara.silabaTableAdapters.lihatPengeluaranTableAdapter();
            this.namaAcaraDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.namaAnggotaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tanggalTransaksiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jumlahDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.keteranganDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgPemasukan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.silaba)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lihatPengeluaranBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCari
            // 
            this.txtCari.Location = new System.Drawing.Point(104, 101);
            this.txtCari.Name = "txtCari";
            this.txtCari.Size = new System.Drawing.Size(814, 20);
            this.txtCari.TabIndex = 68;
            // 
            // dgPemasukan
            // 
            this.dgPemasukan.AllowUserToAddRows = false;
            this.dgPemasukan.AllowUserToDeleteRows = false;
            this.dgPemasukan.AllowUserToResizeRows = false;
            this.dgPemasukan.AutoGenerateColumns = false;
            this.dgPemasukan.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.dgPemasukan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgPemasukan.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgPemasukan.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPemasukan.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgPemasukan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPemasukan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.namaAcaraDataGridViewTextBoxColumn,
            this.namaAnggotaDataGridViewTextBoxColumn,
            this.tanggalTransaksiDataGridViewTextBoxColumn,
            this.jumlahDataGridViewTextBoxColumn,
            this.keteranganDataGridViewTextBoxColumn});
            this.dgPemasukan.DataSource = this.lihatPengeluaranBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgPemasukan.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgPemasukan.EnableHeadersVisualStyles = false;
            this.dgPemasukan.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgPemasukan.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgPemasukan.Location = new System.Drawing.Point(57, 144);
            this.dgPemasukan.Name = "dgPemasukan";
            this.dgPemasukan.ReadOnly = true;
            this.dgPemasukan.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPemasukan.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgPemasukan.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgPemasukan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgPemasukan.Size = new System.Drawing.Size(861, 331);
            this.dgPemasukan.TabIndex = 65;
            this.dgPemasukan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPemasukan_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(50, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(339, 42);
            this.label1.TabIndex = 69;
            this.label1.Text = "Lihat Pengeluaran";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(55, 101);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 18);
            this.label13.TabIndex = 70;
            this.label13.Text = "Cari :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(54, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 15);
            this.label5.TabIndex = 115;
            this.label5.Text = "Table Pengeluaran";
            // 
            // silaba
            // 
            this.silaba.DataSetName = "silaba";
            this.silaba.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lihatPengeluaranBindingSource
            // 
            this.lihatPengeluaranBindingSource.DataMember = "lihatPengeluaran";
            this.lihatPengeluaranBindingSource.DataSource = this.silaba;
            // 
            // lihatPengeluaranTableAdapter
            // 
            this.lihatPengeluaranTableAdapter.ClearBeforeFill = true;
            // 
            // namaAcaraDataGridViewTextBoxColumn
            // 
            this.namaAcaraDataGridViewTextBoxColumn.DataPropertyName = "Nama Acara";
            this.namaAcaraDataGridViewTextBoxColumn.HeaderText = "Nama Acara";
            this.namaAcaraDataGridViewTextBoxColumn.Name = "namaAcaraDataGridViewTextBoxColumn";
            this.namaAcaraDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // namaAnggotaDataGridViewTextBoxColumn
            // 
            this.namaAnggotaDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.namaAnggotaDataGridViewTextBoxColumn.DataPropertyName = "Nama Anggota";
            this.namaAnggotaDataGridViewTextBoxColumn.HeaderText = "Nama Anggota";
            this.namaAnggotaDataGridViewTextBoxColumn.Name = "namaAnggotaDataGridViewTextBoxColumn";
            this.namaAnggotaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tanggalTransaksiDataGridViewTextBoxColumn
            // 
            this.tanggalTransaksiDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.tanggalTransaksiDataGridViewTextBoxColumn.DataPropertyName = "Tanggal Transaksi";
            this.tanggalTransaksiDataGridViewTextBoxColumn.HeaderText = "Tanggal Transaksi";
            this.tanggalTransaksiDataGridViewTextBoxColumn.Name = "tanggalTransaksiDataGridViewTextBoxColumn";
            this.tanggalTransaksiDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // jumlahDataGridViewTextBoxColumn
            // 
            this.jumlahDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.jumlahDataGridViewTextBoxColumn.DataPropertyName = "Jumlah";
            this.jumlahDataGridViewTextBoxColumn.HeaderText = "Jumlah";
            this.jumlahDataGridViewTextBoxColumn.Name = "jumlahDataGridViewTextBoxColumn";
            this.jumlahDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // keteranganDataGridViewTextBoxColumn
            // 
            this.keteranganDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.keteranganDataGridViewTextBoxColumn.DataPropertyName = "Keterangan";
            this.keteranganDataGridViewTextBoxColumn.HeaderText = "Keterangan";
            this.keteranganDataGridViewTextBoxColumn.Name = "keteranganDataGridViewTextBoxColumn";
            this.keteranganDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // UCLihatPengeluaran
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCari);
            this.Controls.Add(this.dgPemasukan);
            this.Name = "UCLihatPengeluaran";
            this.Size = new System.Drawing.Size(1116, 608);
            this.Load += new System.EventHandler(this.UCLihatPengeluaran_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgPemasukan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.silaba)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lihatPengeluaranBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCari;
        private MetroFramework.Controls.MetroGrid dgPemasukan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn namaAcaraDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn namaAnggotaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tanggalTransaksiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jumlahDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn keteranganDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource lihatPengeluaranBindingSource;
        private silaba silaba;
        private silabaTableAdapters.lihatPengeluaranTableAdapter lihatPengeluaranTableAdapter;
    }
}
