﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AsistenBendahara.Transaksi_Bendahara
{
    public partial class UCLihatPengeluaran : UserControl
    {
        public UCLihatPengeluaran()
        {
            InitializeComponent();
        }

        private void UCLihatPengeluaran_Load(object sender, EventArgs e)
        {
          //  LoadFormAnggota();
            this.lihatPengeluaranTableAdapter.Fill(this.silaba.lihatPengeluaran);

        }

        public void LoadFormAnggota()
        {
            dgPemasukan.DataSource = null;

            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";

            var select = @"SELECT        ms_acara.acara_nama AS 'Nama Acara', ms_user.user_nama AS 'Nama Anggota', tr_detail_pengeluaran_acara.dtl_tanggal AS 'Tanggal Transaksi', tr_detail_pengeluaran_acara.dtl_jumlah AS 'Jumlah', tr_detail_pengeluaran_acara.dtl_keterangan AS 'Keterangan'
FROM            tr_detail_pengeluaran_acara INNER JOIN
                         ms_acara ON tr_detail_pengeluaran_acara.acara_id = ms_acara.acara_id INNER JOIN
                         ms_user ON tr_detail_pengeluaran_acara.user_id = ms_user.user_id";
            var c = new SqlConnection(ConnectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dgPemasukan.ReadOnly = true;
            dgPemasukan.DataSource = ds.Tables[0];
            this.dgPemasukan.Columns["Tanggal Transaksi"].DefaultCellStyle.Format = "D";
         
            this.dgPemasukan.Columns["Jumlah"].DefaultCellStyle.Format = "C0";

            //    rbSemua.Checked = true;
        }

        private void dgPemasukan_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
