﻿namespace AsistenBendahara.Transaksi
{
    partial class UCLihatTagihan
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtCari = new System.Windows.Forms.TextBox();
            this.dgTagihan = new MetroFramework.Controls.MetroGrid();
            this.rbBelumLunas = new System.Windows.Forms.RadioButton();
            this.rbSemua = new System.Windows.Forms.RadioButton();
            this.rbSudahLunas1 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgTagihan)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCari
            // 
            this.txtCari.Location = new System.Drawing.Point(128, 146);
            this.txtCari.Name = "txtCari";
            this.txtCari.Size = new System.Drawing.Size(824, 20);
            this.txtCari.TabIndex = 55;
            this.txtCari.TextChanged += new System.EventHandler(this.txtCari_TextChanged);
            // 
            // dgTagihan
            // 
            this.dgTagihan.AllowUserToAddRows = false;
            this.dgTagihan.AllowUserToDeleteRows = false;
            this.dgTagihan.AllowUserToResizeRows = false;
            this.dgTagihan.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.dgTagihan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgTagihan.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgTagihan.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgTagihan.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgTagihan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgTagihan.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgTagihan.EnableHeadersVisualStyles = false;
            this.dgTagihan.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgTagihan.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgTagihan.Location = new System.Drawing.Point(91, 189);
            this.dgTagihan.Name = "dgTagihan";
            this.dgTagihan.ReadOnly = true;
            this.dgTagihan.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgTagihan.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgTagihan.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgTagihan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgTagihan.Size = new System.Drawing.Size(861, 331);
            this.dgTagihan.TabIndex = 52;
            // 
            // rbBelumLunas
            // 
            this.rbBelumLunas.AutoSize = true;
            this.rbBelumLunas.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.rbBelumLunas.ForeColor = System.Drawing.Color.White;
            this.rbBelumLunas.Location = new System.Drawing.Point(224, 118);
            this.rbBelumLunas.Name = "rbBelumLunas";
            this.rbBelumLunas.Size = new System.Drawing.Size(168, 22);
            this.rbBelumLunas.TabIndex = 72;
            this.rbBelumLunas.TabStop = true;
            this.rbBelumLunas.Text = "Tagihan Belum Lunas";
            this.rbBelumLunas.UseVisualStyleBackColor = true;
            this.rbBelumLunas.CheckedChanged += new System.EventHandler(this.rbBelumLunas_CheckedChanged_1);
            // 
            // rbSemua
            // 
            this.rbSemua.AutoSize = true;
            this.rbSemua.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.rbSemua.ForeColor = System.Drawing.Color.White;
            this.rbSemua.Location = new System.Drawing.Point(89, 118);
            this.rbSemua.Name = "rbSemua";
            this.rbSemua.Size = new System.Drawing.Size(129, 22);
            this.rbSemua.TabIndex = 71;
            this.rbSemua.TabStop = true;
            this.rbSemua.Text = "Semua Tagihan";
            this.rbSemua.UseVisualStyleBackColor = true;
            this.rbSemua.CheckedChanged += new System.EventHandler(this.rbSemua_CheckedChanged_1);
            // 
            // rbSudahLunas1
            // 
            this.rbSudahLunas1.AutoSize = true;
            this.rbSudahLunas1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.rbSudahLunas1.ForeColor = System.Drawing.Color.White;
            this.rbSudahLunas1.Location = new System.Drawing.Point(398, 118);
            this.rbSudahLunas1.Name = "rbSudahLunas1";
            this.rbSudahLunas1.Size = new System.Drawing.Size(122, 22);
            this.rbSudahLunas1.TabIndex = 73;
            this.rbSudahLunas1.TabStop = true;
            this.rbSudahLunas1.Text = "Tagihan Lunas";
            this.rbSudahLunas1.UseVisualStyleBackColor = true;
            this.rbSudahLunas1.CheckedChanged += new System.EventHandler(this.rbSudahLunas1_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(45, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(258, 42);
            this.label3.TabIndex = 75;
            this.label3.Text = "Lihat Tagihan";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(88, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 18);
            this.label1.TabIndex = 114;
            this.label1.Text = "Cari :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(88, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 15);
            this.label5.TabIndex = 115;
            this.label5.Text = "Table Tagihan";
            // 
            // UCLihatTagihan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rbSudahLunas1);
            this.Controls.Add(this.rbBelumLunas);
            this.Controls.Add(this.rbSemua);
            this.Controls.Add(this.txtCari);
            this.Controls.Add(this.dgTagihan);
            this.Name = "UCLihatTagihan";
            this.Size = new System.Drawing.Size(1116, 608);
            this.Load += new System.EventHandler(this.UCLihatTagihan_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgTagihan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtCari;
        private MetroFramework.Controls.MetroGrid dgTagihan;
        private System.Windows.Forms.RadioButton rbBelumLunas;
        private System.Windows.Forms.RadioButton rbSemua;
        private System.Windows.Forms.RadioButton rbSudahLunas1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
    }
}
