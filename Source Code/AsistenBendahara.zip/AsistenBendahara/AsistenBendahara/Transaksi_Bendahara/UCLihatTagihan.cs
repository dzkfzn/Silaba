﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AsistenBendahara.Transaksi
{
    public partial class UCLihatTagihan : UserControl
    {
        public UCLihatTagihan()
        {
            InitializeComponent();
        }

        private void UCLihatTagihan_Load(object sender, EventArgs e)
        {
            rbSemua.Checked = true;
            LoadForm();
        }

        public void LoadForm()
        {
            dgTagihan.DataSource = null;

            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";

            var select = @"SELECT        tr_tagihan.tagihan_id as 'ID Tagihan', ms_acara.acara_nama as 'Nama Acara', ms_user.user_nama as 'Nama Anggota', tr_tagihan.tagihan_status as 'Status Tagihan', tr_tagihan.tagihan_nilai as 'Jumlah Tagihan', tr_tagihan.tagihan_tgl_deadline as 'Deadline'
FROM            ms_user INNER JOIN
                         tr_tagihan ON ms_user.user_id = tr_tagihan.user_id INNER JOIN
                         ms_acara ON tr_tagihan.acara_id = ms_acara.acara_id";
            var c = new SqlConnection(ConnectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dgTagihan.ReadOnly = true;
            dgTagihan.DataSource = ds.Tables[0];

            this.dgTagihan.Columns["Deadline"].DefaultCellStyle.Format = "D";
            this.dgTagihan.Columns["Jumlah Tagihan"].DefaultCellStyle.Format = "C0";

            //    rbSemua.Checked = true;
        }

        private void rbBelumLunas_CheckedChanged(object sender, EventArgs e)
        {
            dgTagihan.DataSource = null;

            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";

            var select = @"SELECT        tr_tagihan.tagihan_id as 'ID Tagihan', ms_acara.acara_nama as 'Nama Acara', ms_user.user_nama as 'Nama Anggota', tr_tagihan.tagihan_status as 'Status Tagihan', tr_tagihan.tagihan_nilai as 'Jumlah Tagihan', tr_tagihan.tagihan_tgl_deadline as 'Deadline'
FROM            ms_user INNER JOIN
                         tr_tagihan ON ms_user.user_id = tr_tagihan.user_id INNER JOIN
                         ms_acara ON tr_tagihan.acara_id = ms_acara.acara_id
						 WHERE tr_tagihan.tagihan_status = 'Belum Lunas'";
            var c = new SqlConnection(ConnectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dgTagihan.ReadOnly = true;
            dgTagihan.DataSource = ds.Tables[0];

            this.dgTagihan.Columns["Deadline"].DefaultCellStyle.Format = "D";
        }

        private void rbSudahLunas_CheckedChanged(object sender, EventArgs e)
        {
            dgTagihan.DataSource = null;

            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";

            var select = @"SELECT        tr_tagihan.tagihan_id as 'ID Tagihan', ms_acara.acara_nama as 'Nama Acara', ms_user.user_nama as 'Nama Anggota', tr_tagihan.tagihan_status as 'Status Tagihan', tr_tagihan.tagihan_nilai as 'Jumlah Tagihan', tr_tagihan.tagihan_tgl_deadline as 'Deadline'
FROM            ms_user INNER JOIN
                         tr_tagihan ON ms_user.user_id = tr_tagihan.user_id INNER JOIN
                         ms_acara ON tr_tagihan.acara_id = ms_acara.acara_id
						 WHERE tr_tagihan.tagihan_status = 'Lunas'";
            var c = new SqlConnection(ConnectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dgTagihan.ReadOnly = true;
            dgTagihan.DataSource = ds.Tables[0];

            this.dgTagihan.Columns["Deadline"].DefaultCellStyle.Format = "D";
        }

        private void rbSemua_CheckedChanged(object sender, EventArgs e)
        {
            LoadForm();
        }

        private void txtCari_TextChanged(object sender, EventArgs e)
        {
            int tipe = 0;
            if (rbSemua.Checked == true)
            {
                tipe = 0;
            }
            else if (rbBelumLunas.Checked == true)
            {
                tipe = -1;
            }
            else if (rbSudahLunas1.Checked == true)
            {
                tipe = 1;
            }
            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
            SqlConnection myConnection = new SqlConnection(ConnectionString);

            SqlCommand search = new SqlCommand("sp_SearchTagihan", myConnection);
            search.CommandType = CommandType.StoredProcedure;

            search.Parameters.AddWithValue("@kata_kunci", txtCari.Text);
            search.Parameters.AddWithValue("@tipe", tipe);
            // this.dgTagihan.Columns["Deadline"].DefaultCellStyle.Format = "D";
            using (var adapter = new SqlDataAdapter(search))
            {
                myConnection.Open();
                var myTable = new DataTable();
                adapter.Fill(myTable);
                dgTagihan.DataSource = myTable;
                myConnection.Close();

            }
        }

        private void btnBatal_Click(object sender, EventArgs e)
        {

        }

        private void rbSemua_CheckedChanged_1(object sender, EventArgs e)
        {
            LoadForm();
        }

        private void rbBelumLunas_CheckedChanged_1(object sender, EventArgs e)
        {
            dgTagihan.DataSource = null;

            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";

            var select = @"SELECT        tr_tagihan.tagihan_id as 'ID Tagihan', ms_acara.acara_nama as 'Nama Acara', ms_user.user_nama as 'Nama Anggota', tr_tagihan.tagihan_status as 'Status Tagihan', tr_tagihan.tagihan_nilai as 'Jumlah Tagihan', tr_tagihan.tagihan_tgl_deadline as 'Deadline'
FROM            ms_user INNER JOIN
                         tr_tagihan ON ms_user.user_id = tr_tagihan.user_id INNER JOIN
                         ms_acara ON tr_tagihan.acara_id = ms_acara.acara_id
						 WHERE tr_tagihan.tagihan_status = 'Belum Lunas'";
            var c = new SqlConnection(ConnectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dgTagihan.ReadOnly = true;
            dgTagihan.DataSource = ds.Tables[0];

            this.dgTagihan.Columns["Deadline"].DefaultCellStyle.Format = "D";
        }

        private void rbSudahLunas1_CheckedChanged(object sender, EventArgs e)
        {
            dgTagihan.DataSource = null;

            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";

            var select = @"SELECT        tr_tagihan.tagihan_id as 'ID Tagihan', ms_acara.acara_nama as 'Nama Acara', ms_user.user_nama as 'Nama Anggota', tr_tagihan.tagihan_status as 'Status Tagihan', tr_tagihan.tagihan_nilai as 'Jumlah Tagihan', tr_tagihan.tagihan_tgl_deadline as 'Deadline'
FROM            ms_user INNER JOIN
                         tr_tagihan ON ms_user.user_id = tr_tagihan.user_id INNER JOIN
                         ms_acara ON tr_tagihan.acara_id = ms_acara.acara_id
						 WHERE tr_tagihan.tagihan_status = 'Lunas'";
            var c = new SqlConnection(ConnectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dgTagihan.ReadOnly = true;
            dgTagihan.DataSource = ds.Tables[0];

            this.dgTagihan.Columns["Deadline"].DefaultCellStyle.Format = "D";
        }
    }
}
