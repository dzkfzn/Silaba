﻿namespace AsistenBendahara.Transaksi
{
    partial class UCtrPemasukanAcara
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtKeterangan = new System.Windows.Forms.TextBox();
            this.txtNama = new System.Windows.Forms.TextBox();
            this.txtJumlah = new System.Windows.Forms.TextBox();
            this.txtNamaAcara = new System.Windows.Forms.TextBox();
            this.dtTglSumbang = new MetroFramework.Controls.MetroDateTime();
            this.txtCari = new System.Windows.Forms.TextBox();
            this.dgAcara = new MetroFramework.Controls.MetroGrid();
            this.acaraidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.acaranamaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.acarabudgetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.msacaraBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsAcara_update = new AsistenBendahara.dsAcara_update();
            this.ms_acaraTableAdapter = new AsistenBendahara.dsAcara_updateTableAdapters.ms_acaraTableAdapter();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBayar1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgAcara)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAcara_update)).BeginInit();
            this.SuspendLayout();
            // 
            // txtKeterangan
            // 
            this.txtKeterangan.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.txtKeterangan.Location = new System.Drawing.Point(273, 454);
            this.txtKeterangan.Multiline = true;
            this.txtKeterangan.Name = "txtKeterangan";
            this.txtKeterangan.Size = new System.Drawing.Size(157, 40);
            this.txtKeterangan.TabIndex = 56;
            // 
            // txtNama
            // 
            this.txtNama.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.txtNama.Location = new System.Drawing.Point(273, 214);
            this.txtNama.MaxLength = 50;
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(157, 23);
            this.txtNama.TabIndex = 35;
            // 
            // txtJumlah
            // 
            this.txtJumlah.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.txtJumlah.Location = new System.Drawing.Point(273, 371);
            this.txtJumlah.MaxLength = 15;
            this.txtJumlah.Name = "txtJumlah";
            this.txtJumlah.Size = new System.Drawing.Size(157, 23);
            this.txtJumlah.TabIndex = 36;
            this.txtJumlah.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtJumlah_KeyPress);
            // 
            // txtNamaAcara
            // 
            this.txtNamaAcara.Enabled = false;
            this.txtNamaAcara.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNamaAcara.Location = new System.Drawing.Point(273, 119);
            this.txtNamaAcara.Name = "txtNamaAcara";
            this.txtNamaAcara.Size = new System.Drawing.Size(157, 23);
            this.txtNamaAcara.TabIndex = 34;
            // 
            // dtTglSumbang
            // 
            this.dtTglSumbang.CustomFormat = "dd-MM-yyyy";
            this.dtTglSumbang.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTglSumbang.Location = new System.Drawing.Point(273, 283);
            this.dtTglSumbang.MinimumSize = new System.Drawing.Size(0, 29);
            this.dtTglSumbang.Name = "dtTglSumbang";
            this.dtTglSumbang.Size = new System.Drawing.Size(157, 29);
            this.dtTglSumbang.TabIndex = 38;
            // 
            // txtCari
            // 
            this.txtCari.Location = new System.Drawing.Point(526, 69);
            this.txtCari.Name = "txtCari";
            this.txtCari.Size = new System.Drawing.Size(538, 20);
            this.txtCari.TabIndex = 58;
            this.txtCari.TextChanged += new System.EventHandler(this.txtCari_TextChanged);
            // 
            // dgAcara
            // 
            this.dgAcara.AllowUserToAddRows = false;
            this.dgAcara.AllowUserToDeleteRows = false;
            this.dgAcara.AllowUserToResizeRows = false;
            this.dgAcara.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgAcara.AutoGenerateColumns = false;
            this.dgAcara.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.dgAcara.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgAcara.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgAcara.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgAcara.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgAcara.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAcara.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.acaraidDataGridViewTextBoxColumn,
            this.acaranamaDataGridViewTextBoxColumn,
            this.acarabudgetDataGridViewTextBoxColumn});
            this.dgAcara.DataSource = this.msacaraBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgAcara.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgAcara.EnableHeadersVisualStyles = false;
            this.dgAcara.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgAcara.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgAcara.Location = new System.Drawing.Point(480, 108);
            this.dgAcara.Name = "dgAcara";
            this.dgAcara.ReadOnly = true;
            this.dgAcara.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgAcara.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgAcara.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgAcara.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgAcara.Size = new System.Drawing.Size(584, 470);
            this.dgAcara.TabIndex = 56;
            this.dgAcara.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgAcara_CellClick);
            // 
            // acaraidDataGridViewTextBoxColumn
            // 
            this.acaraidDataGridViewTextBoxColumn.DataPropertyName = "acara_id";
            this.acaraidDataGridViewTextBoxColumn.HeaderText = "ID Acara";
            this.acaraidDataGridViewTextBoxColumn.Name = "acaraidDataGridViewTextBoxColumn";
            this.acaraidDataGridViewTextBoxColumn.ReadOnly = true;
            this.acaraidDataGridViewTextBoxColumn.Visible = false;
            // 
            // acaranamaDataGridViewTextBoxColumn
            // 
            this.acaranamaDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.acaranamaDataGridViewTextBoxColumn.DataPropertyName = "acara_nama";
            this.acaranamaDataGridViewTextBoxColumn.HeaderText = "Nama Acara";
            this.acaranamaDataGridViewTextBoxColumn.Name = "acaranamaDataGridViewTextBoxColumn";
            this.acaranamaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // acarabudgetDataGridViewTextBoxColumn
            // 
            this.acarabudgetDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.acarabudgetDataGridViewTextBoxColumn.DataPropertyName = "acara_budget";
            dataGridViewCellStyle2.Format = "C0";
            dataGridViewCellStyle2.NullValue = "Rp#.###";
            this.acarabudgetDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.acarabudgetDataGridViewTextBoxColumn.HeaderText = "Budget Acara";
            this.acarabudgetDataGridViewTextBoxColumn.Name = "acarabudgetDataGridViewTextBoxColumn";
            this.acarabudgetDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // msacaraBindingSource
            // 
            this.msacaraBindingSource.DataMember = "ms_acara";
            this.msacaraBindingSource.DataSource = this.dsAcara_update;
            // 
            // dsAcara_update
            // 
            this.dsAcara_update.DataSetName = "dsAcara_update";
            this.dsAcara_update.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ms_acaraTableAdapter
            // 
            this.ms_acaraTableAdapter.ClearBeforeFill = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label11.Location = new System.Drawing.Point(156, 467);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 14);
            this.label11.TabIndex = 110;
            this.label11.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label10.Location = new System.Drawing.Point(213, 385);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 14);
            this.label10.TabIndex = 109;
            this.label10.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label9.Location = new System.Drawing.Point(202, 302);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 14);
            this.label9.TabIndex = 108;
            this.label9.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label8.Location = new System.Drawing.Point(156, 210);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 14);
            this.label8.TabIndex = 107;
            this.label8.Text = "*";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label7.Location = new System.Drawing.Point(165, 134);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 14);
            this.label7.TabIndex = 106;
            this.label7.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(79, 463);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 18);
            this.label6.TabIndex = 105;
            this.label6.Text = "Keterangan";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(79, 380);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 18);
            this.label1.TabIndex = 104;
            this.label1.Text = "Jumlah Sumbangan";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(79, 297);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 18);
            this.label4.TabIndex = 103;
            this.label4.Text = "Tanggal Sumbang";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(79, 206);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 18);
            this.label13.TabIndex = 102;
            this.label13.Text = "Atas Nama";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(79, 131);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 18);
            this.label14.TabIndex = 101;
            this.label14.Text = "Nama Acara";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(48, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(323, 42);
            this.label2.TabIndex = 111;
            this.label2.Text = "Input Pemasukan";
            // 
            // btnBayar1
            // 
            this.btnBayar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnBayar1.FlatAppearance.BorderSize = 0;
            this.btnBayar1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBayar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBayar1.ForeColor = System.Drawing.Color.White;
            this.btnBayar1.Location = new System.Drawing.Point(82, 543);
            this.btnBayar1.Name = "btnBayar1";
            this.btnBayar1.Size = new System.Drawing.Size(348, 35);
            this.btnBayar1.TabIndex = 112;
            this.btnBayar1.Text = "Bayar";
            this.btnBayar1.UseVisualStyleBackColor = false;
            this.btnBayar1.Click += new System.EventHandler(this.btnHapus_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(477, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 18);
            this.label3.TabIndex = 113;
            this.label3.Text = "Cari :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(477, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 15);
            this.label5.TabIndex = 114;
            this.label5.Text = "Table Acara";
            // 
            // UCtrPemasukanAcara
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnBayar1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtKeterangan);
            this.Controls.Add(this.txtNama);
            this.Controls.Add(this.txtCari);
            this.Controls.Add(this.txtJumlah);
            this.Controls.Add(this.dgAcara);
            this.Controls.Add(this.txtNamaAcara);
            this.Controls.Add(this.dtTglSumbang);
            this.Name = "UCtrPemasukanAcara";
            this.Size = new System.Drawing.Size(1116, 608);
            this.Load += new System.EventHandler(this.UCtrPemasukanAcara_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgAcara)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAcara_update)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtNama;
        private System.Windows.Forms.TextBox txtJumlah;
        private MetroFramework.Controls.MetroDateTime dtTglSumbang;
        private System.Windows.Forms.TextBox txtNamaAcara;
        private System.Windows.Forms.TextBox txtKeterangan;
        private System.Windows.Forms.TextBox txtCari;
        private MetroFramework.Controls.MetroGrid dgAcara;
        private System.Windows.Forms.BindingSource msacaraBindingSource;
        private dsAcara_update dsAcara_update;
        private dsAcara_updateTableAdapters.ms_acaraTableAdapter ms_acaraTableAdapter;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBayar1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn acaraidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn acaranamaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn acarabudgetDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label5;
    }
}
