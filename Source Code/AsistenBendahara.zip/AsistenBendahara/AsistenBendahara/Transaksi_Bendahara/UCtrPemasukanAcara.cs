﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AsistenBendahara.Transaksi
{
    public partial class UCtrPemasukanAcara : UserControl
    {
        public UCtrPemasukanAcara()
        {
            InitializeComponent();
        }

        private void UCtrPemasukanAcara_Load(object sender, EventArgs e)
        {
            this.ms_acaraTableAdapter.Fill(this.dsAcara_update.ms_acara);
        }

        public string generateID()
        {
            return Guid.NewGuid().ToString("N");
        }
        string acara_id = "";
        private void btnBayar_Click(object sender, EventArgs e)
        {
            
        }

        private void clear()
        {
            txtCari.Clear();
            txtJumlah.Clear();
            txtKeterangan.Clear();
            txtNama.Clear();
            txtNamaAcara.Clear();

            btnBayar1.Enabled = false;
            tagihan = "";
        }

        private void dgAcara_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btnBayar1.Enabled = true;


            foreach (DataGridViewRow row in dgAcara.SelectedRows)
            {
                try
                {
                    acara_id = row.Cells[0].Value.ToString();
                    txtNamaAcara.Text = row.Cells[1].Value.ToString();    

                }
                catch
                {

                }

            }
        }

        private void txtCari_TextChanged(object sender, EventArgs e)
        {

        }
        string tagihan = "";
        private void txtJumlah_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {


                if (char.IsNumber(e.KeyChar) && !char.IsControl(e.KeyChar))
                {

                    e.Handled = true;

                }

                if (char.IsLetter(e.KeyChar))
                {

                    e.Handled = true;

                }

                if (char.IsControl(e.KeyChar))
                {

                    txtJumlah.Text = "";
                    tagihan = "";

                }

                if (char.IsNumber(e.KeyChar))
                {

                    tagihan = tagihan + e.KeyChar.ToString();
                    decimal moneyvalue = decimal.Parse(tagihan);
                    txtJumlah.Text = String.Format("{0:C} ", moneyvalue);
                }
            }
            catch
            {
                e.Handled = true;
            }
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Ingin Bayar Ini?", "Konfirmasi", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    string connectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                    connectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                    SqlConnection connection = new SqlConnection(connectionstring);
                    SqlCommand insert = new SqlCommand("sp_InputPemasukan", connection);

                    insert.CommandType = CommandType.StoredProcedure;

                    insert.Parameters.AddWithValue("dtl_id", generateID());
                    insert.Parameters.AddWithValue("acara_id", acara_id);
                    insert.Parameters.AddWithValue("dtl_keterangan", txtKeterangan.Text);
                    insert.Parameters.AddWithValue("dtl_jumlah", tagihan);
                    insert.Parameters.AddWithValue("dtl_tanggal", dtTglSumbang.Value.Date);
                    insert.Parameters.AddWithValue("dtl_nama", txtNama.Text);
                    try
                    {
                        connection.Open();
                        insert.ExecuteNonQuery();
                        MessageBox.Show(this, "Pembayaran Tagihan Berhasil", "Information",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        clear();


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Data Tidak Boleh Kosong!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                catch
                {
                    MessageBox.Show(this, "Data Tidak Boleh Kosong!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else if (dr == DialogResult.No)
            {

            }
        }
    }
}
