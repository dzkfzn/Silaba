﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AsistenBendahara.Transaksi
{
    public partial class UCtrPengeluaranAcara : UserControl
    {
        public UCtrPengeluaranAcara()
        {
            InitializeComponent();
        }

        public void LoadFormAcara()
        {
            dgAcara.DataSource = null;

            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";

            var select = @"SELECT        acara_nama as [Nama Acara], acara_budget as [Budget], acara_id
FROM            ms_acara";
            var c = new SqlConnection(ConnectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dgAcara.ReadOnly = true;
            dgAcara.DataSource = ds.Tables[0];
            this.dgAcara.Columns["acara_id"].Visible = false;
            this.dgAcara.Columns["Budget"].DefaultCellStyle.Format = "C0";

            label1.Hide();
            //    rbSemua.Checked = true;
        }

        

        string username;
        private void UCtrPengeluaranAcara_Load(object sender, EventArgs e)
        {
            //LoadFormUser();
            LoadFormAcara();
            //Lain_Lain.Login login = new Lain_Lain.Login();
            //username = Lain_Lain.Login.passingUsername;
            //txtKeterangan.Text = username;
        }
        String acara_id = "";
        String user_id = "";
        String budget_acara = "";
        String jumlah_tarik = "";
        decimal moneyvalue_budget=0;
        decimal moneyvalue = 0;
        private void clear()
        {
            txtCari.Clear();
            txtJumlah.Clear();
            txtKeterangan.Clear();
            txtNama.Clear();
            txtNamaAcara.Clear();
            txtJumlahPengeluaran.Clear();
            acara_id = "";
            user_id = "";
            budget_acara = "";
            jumlah_tarik = "";
            moneyvalue_budget = 0;
            moneyvalue = 0;
           

            btnBayar.Enabled = false;
            txtJumlahPengeluaran.Enabled = false;
            txtKeterangan.Enabled = false;
            //dgAnggota.DataSource = null;
            label1.Hide();
        }
        private void dgAcara_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            clear();


            foreach (DataGridViewRow row in dgAcara.SelectedRows)
            {
                try
                {
                    acara_id = row.Cells[2].Value.ToString();
                    txtNamaAcara.Text = row.Cells[0].Value.ToString();

                    budget_acara = row.Cells[1].Value.ToString();
                    
                    moneyvalue_budget = decimal.Parse(budget_acara);
                    txtJumlah.Text = String.Format("{0:C} ", moneyvalue_budget);

                    
                }
                catch
                {

                }
            }
            //LoadFormUser();
        }

        private void dgAnggota_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btnBayar.Enabled = true;
            txtJumlahPengeluaran.Enabled = true;
            txtKeterangan.Enabled = true;

            foreach (DataGridViewRow row in dgAcara.SelectedRows)
            {
                try
                {
                    user_id = row.Cells[1].Value.ToString();
                    txtNama.Text = row.Cells[0].Value.ToString();
      
                }
                catch
                {

                }
            }
         
        }

        private void btnBersih_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void txtJumlahPengeluaran_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {


                if (char.IsNumber(e.KeyChar) && !char.IsControl(e.KeyChar))
                {

                    e.Handled = true;

                }

                if (char.IsLetter(e.KeyChar))
                {

                    e.Handled = true;

                }

                if (char.IsControl(e.KeyChar))
                {

                    txtJumlahPengeluaran.Text = "";
                    jumlah_tarik = "";
                    moneyvalue = 0;
                }
                

                if (char.IsNumber(e.KeyChar))
                {

                    jumlah_tarik = jumlah_tarik + e.KeyChar.ToString();
                    moneyvalue = decimal.Parse(jumlah_tarik);
                    txtJumlahPengeluaran.Text = String.Format("{0:C} ", moneyvalue);
                }
                if(moneyvalue_budget < moneyvalue)
                {
                    label1.Show();
                    btnBayar.Enabled = false;
                }
                else
                {
                    label1.Hide();
                    btnBayar.Enabled = true;
                }

            }
            catch
            {
                e.Handled = true;
            }
        }
        public string generateID()
        {
            return Guid.NewGuid().ToString("N");
        }
        private void btnBayar_Click(object sender, EventArgs e)
        {
            string connectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand insert = new SqlCommand("sp_InputPengeluaran", connection);

            insert.CommandType = CommandType.StoredProcedure;
            try
            {
                if (txtNama.Text == "" || txtJumlahPengeluaran.Text == "" || txtKeterangan.Text == "")
                {
                    MessageBox.Show(this, "Data Tidak Boleh Kosong!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {

                    insert.Parameters.AddWithValue("dtl_id", generateID());
                    insert.Parameters.AddWithValue("acara_id", acara_id);
                    insert.Parameters.AddWithValue("user_id", user_id);
                    insert.Parameters.AddWithValue("dtl_jumlah", jumlah_tarik);
                    insert.Parameters.AddWithValue("dtl_tanggal", dtTglSumbang.Value.Date);
                    insert.Parameters.AddWithValue("dtl_keterangan", txtKeterangan.Text);

                    try
                    {
                        connection.Open();
                        insert.ExecuteNonQuery();
                        MessageBox.Show(this, "Data berhasil disimpan", "Information",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //LoadFormUser();
                        LoadFormAcara();
                        clear();


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Tidak berhasil disimpan!: " + ex.Message);
                    }
                }
            }
            catch
            {
                MessageBox.Show(this, "Data Tidak Boleh Kosong!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void txtCari_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtNamaAcara_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
