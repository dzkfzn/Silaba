﻿namespace AsistenBendahara.Transaksi
{
    partial class UCtrTagihanAdminView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgTagihan = new MetroFramework.Controls.MetroGrid();
            this.trtagihanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pRG2_SILABIDataSet9 = new AsistenBendahara.PRG2_SILABIDataSet9();
            this.txtCari = new System.Windows.Forms.TextBox();
            this.tr_tagihanTableAdapter = new AsistenBendahara.PRG2_SILABIDataSet9TableAdapters.tr_tagihanTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.txtNamaAnggota = new System.Windows.Forms.TextBox();
            this.txtJumlah = new System.Windows.Forms.TextBox();
            this.dtDeadline = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtIDTagihan = new System.Windows.Forms.TextBox();
            this.labelBudgetAwal = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.txtNamaAcara = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSimpan = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgTagihan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trtagihanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet9)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgTagihan
            // 
            this.dgTagihan.AllowUserToAddRows = false;
            this.dgTagihan.AllowUserToDeleteRows = false;
            this.dgTagihan.AllowUserToResizeRows = false;
            this.dgTagihan.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.dgTagihan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgTagihan.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dgTagihan.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgTagihan.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgTagihan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgTagihan.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgTagihan.EnableHeadersVisualStyles = false;
            this.dgTagihan.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgTagihan.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgTagihan.Location = new System.Drawing.Point(41, 134);
            this.dgTagihan.Name = "dgTagihan";
            this.dgTagihan.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgTagihan.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgTagihan.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgTagihan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgTagihan.Size = new System.Drawing.Size(1047, 314);
            this.dgTagihan.TabIndex = 43;
            this.dgTagihan.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgTagihan_CellClick);
            this.dgTagihan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgTagihan_CellContentClick);
            // 
            // trtagihanBindingSource
            // 
            this.trtagihanBindingSource.DataMember = "tr_tagihan";
            this.trtagihanBindingSource.DataSource = this.pRG2_SILABIDataSet9;
            // 
            // pRG2_SILABIDataSet9
            // 
            this.pRG2_SILABIDataSet9.DataSetName = "PRG2_SILABIDataSet9";
            this.pRG2_SILABIDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txtCari
            // 
            this.txtCari.Location = new System.Drawing.Point(88, 94);
            this.txtCari.Name = "txtCari";
            this.txtCari.Size = new System.Drawing.Size(1000, 20);
            this.txtCari.TabIndex = 47;
            this.txtCari.TextChanged += new System.EventHandler(this.txtCariAnggota_TextChanged);
            // 
            // tr_tagihanTableAdapter
            // 
            this.tr_tagihanTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Minion Pro", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1118, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 39);
            this.label1.TabIndex = 53;
            this.label1.Text = "Detail Tagihan";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.45098F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.54902F));
            this.tableLayoutPanel1.Controls.Add(this.txtNamaAnggota, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtJumlah, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.dtDeadline, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.metroLabel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtIDTagihan, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelBudgetAwal, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.metroLabel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.metroLabel4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.metroLabel7, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtNamaAcara, 1, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(25, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(408, 351);
            this.tableLayoutPanel1.TabIndex = 52;
            // 
            // txtNamaAnggota
            // 
            this.txtNamaAnggota.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtNamaAnggota.Enabled = false;
            this.txtNamaAnggota.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.txtNamaAnggota.Location = new System.Drawing.Point(114, 93);
            this.txtNamaAnggota.MaxLength = 15;
            this.txtNamaAnggota.Name = "txtNamaAnggota";
            this.txtNamaAnggota.Size = new System.Drawing.Size(222, 23);
            this.txtNamaAnggota.TabIndex = 35;
            // 
            // txtJumlah
            // 
            this.txtJumlah.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtJumlah.Enabled = false;
            this.txtJumlah.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.txtJumlah.Location = new System.Drawing.Point(114, 233);
            this.txtJumlah.MaxLength = 15;
            this.txtJumlah.Name = "txtJumlah";
            this.txtJumlah.Size = new System.Drawing.Size(222, 23);
            this.txtJumlah.TabIndex = 36;
            this.txtJumlah.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtJumlah_KeyPress);
            // 
            // dtDeadline
            // 
            this.dtDeadline.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dtDeadline.CustomFormat = "dd-MM-yyyy";
            this.dtDeadline.Enabled = false;
            this.dtDeadline.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtDeadline.Location = new System.Drawing.Point(114, 301);
            this.dtDeadline.MinimumSize = new System.Drawing.Size(4, 29);
            this.dtDeadline.Name = "dtDeadline";
            this.dtDeadline.Size = new System.Drawing.Size(225, 29);
            this.dtDeadline.TabIndex = 38;
            // 
            // metroLabel1
            // 
            this.metroLabel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(3, 25);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(69, 19);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "ID Tagihan";
            // 
            // txtIDTagihan
            // 
            this.txtIDTagihan.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtIDTagihan.Enabled = false;
            this.txtIDTagihan.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDTagihan.Location = new System.Drawing.Point(114, 23);
            this.txtIDTagihan.Name = "txtIDTagihan";
            this.txtIDTagihan.Size = new System.Drawing.Size(222, 23);
            this.txtIDTagihan.TabIndex = 34;
            // 
            // labelBudgetAwal
            // 
            this.labelBudgetAwal.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.labelBudgetAwal.AutoSize = true;
            this.labelBudgetAwal.Location = new System.Drawing.Point(3, 95);
            this.labelBudgetAwal.Name = "labelBudgetAwal";
            this.labelBudgetAwal.Size = new System.Drawing.Size(100, 19);
            this.labelBudgetAwal.TabIndex = 1;
            this.labelBudgetAwal.Text = "Nama Anggota";
            // 
            // metroLabel3
            // 
            this.metroLabel3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(3, 165);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(83, 19);
            this.metroLabel3.TabIndex = 2;
            this.metroLabel3.Text = "Nama Acara";
            // 
            // metroLabel4
            // 
            this.metroLabel4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(3, 235);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(98, 19);
            this.metroLabel4.TabIndex = 3;
            this.metroLabel4.Text = "Jumlah Tagihan";
            // 
            // metroLabel7
            // 
            this.metroLabel7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(3, 306);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(63, 19);
            this.metroLabel7.TabIndex = 31;
            this.metroLabel7.Text = "DeadLine";
            // 
            // txtNamaAcara
            // 
            this.txtNamaAcara.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtNamaAcara.Enabled = false;
            this.txtNamaAcara.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.txtNamaAcara.Location = new System.Drawing.Point(114, 163);
            this.txtNamaAcara.MaxLength = 15;
            this.txtNamaAcara.Name = "txtNamaAcara";
            this.txtNamaAcara.Size = new System.Drawing.Size(225, 23);
            this.txtNamaAcara.TabIndex = 36;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(1130, 154);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(448, 357);
            this.panel1.TabIndex = 54;
            this.panel1.Visible = false;
            // 
            // btnSimpan
            // 
            this.btnSimpan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnSimpan.FlatAppearance.BorderSize = 0;
            this.btnSimpan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSimpan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSimpan.ForeColor = System.Drawing.Color.White;
            this.btnSimpan.Location = new System.Drawing.Point(42, 497);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(1046, 35);
            this.btnSimpan.TabIndex = 57;
            this.btnSimpan.Text = "Bayar";
            this.btnSimpan.UseVisualStyleBackColor = false;
            this.btnSimpan.Click += new System.EventHandler(this.btnSimpan_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(34, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(275, 42);
            this.label3.TabIndex = 58;
            this.label3.Text = "Bayar Tagihan";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(42, 538);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(1046, 35);
            this.button2.TabIndex = 59;
            this.button2.Text = "Bersihkan";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(39, 93);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 18);
            this.label13.TabIndex = 60;
            this.label13.Text = "Cari :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(39, 451);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(318, 18);
            this.label14.TabIndex = 61;
            this.label14.Text = "*Row Berbaris Merah sudah Melebihi DeadLine";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(39, 469);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(213, 18);
            this.label2.TabIndex = 62;
            this.label2.Text = "*Tandai CheckBox untuk Bayar";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(38, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(259, 15);
            this.label4.TabIndex = 65;
            this.label4.Text = "Table Anggota yang belum membayar tagihan";
            // 
            // UCtrTagihanAdminView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCari);
            this.Controls.Add(this.dgTagihan);
            this.Name = "UCtrTagihanAdminView";
            this.Size = new System.Drawing.Size(1116, 608);
            this.Load += new System.EventHandler(this.UCtrTagihanAdminView_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dgTagihan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trtagihanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet9)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroGrid dgTagihan;
        private System.Windows.Forms.TextBox txtCari;
        private System.Windows.Forms.BindingSource trtagihanBindingSource;
        private PRG2_SILABIDataSet9 pRG2_SILABIDataSet9;
        private PRG2_SILABIDataSet9TableAdapters.tr_tagihanTableAdapter tr_tagihanTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox txtNamaAcara;
        private System.Windows.Forms.TextBox txtNamaAnggota;
        private System.Windows.Forms.TextBox txtJumlah;
        private MetroFramework.Controls.MetroDateTime dtDeadline;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.TextBox txtIDTagihan;
        private MetroFramework.Controls.MetroLabel labelBudgetAwal;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSimpan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
    }
}
