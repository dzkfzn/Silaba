﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AsistenBendahara.Transaksi
{
    public partial class UCtrTagihanAdminView : UserControl
    {
        public UCtrTagihanAdminView()
        {
            InitializeComponent();
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tr_tagihanTableAdapter.FillBy(this.pRG2_SILABIDataSet9.tr_tagihan);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBy1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tr_tagihanTableAdapter.FillBy1(this.pRG2_SILABIDataSet9.tr_tagihan);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void metroGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void UCtrTagihanAdminView_Load(object sender, EventArgs e)
        {

        }

        private void UCtrTagihanAdminView_Load_1(object sender, EventArgs e)
        {
           
            LoadForm();
            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            checkBoxColumn.HeaderText = "";
            checkBoxColumn.Width = 30;
            checkBoxColumn.Name = "checkBoxColumn";
            dgTagihan.Columns.Insert(0, checkBoxColumn);
        }

        public void LoadForm()
        {
            dgTagihan.DataSource = null;

            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";

            var select = @"SELECT        tr_tagihan.tagihan_id as 'ID Tagihan', ms_acara.acara_nama as 'Nama Acara', ms_user.user_nama as 'Nama Anggota', tr_tagihan.tagihan_status as 'Status Tagihan', tr_tagihan.tagihan_nilai as 'Jumlah Tagihan', tr_tagihan.tagihan_tgl_deadline as 'Deadline'
                            ,ms_acara.acara_id,  ms_user.user_id FROM            ms_user INNER JOIN
                         tr_tagihan ON ms_user.user_id = tr_tagihan.user_id INNER JOIN
                         ms_acara ON tr_tagihan.acara_id = ms_acara.acara_id
						 WHERE tr_tagihan.tagihan_status = 'Belum Lunas'";
            var c = new SqlConnection(ConnectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
           // dgTagihan.ReadOnly = true;
            dgTagihan.DataSource = ds.Tables[0];

            //Add a CheckBox Column to the DataGridView at the first position.
            

            this.dgTagihan.Columns["Deadline"].DefaultCellStyle.Format = "D";
            this.dgTagihan.Columns["user_id"].Visible = false;
            this.dgTagihan.Columns["acara_id"].Visible = false;
            this.dgTagihan.Columns["Jumlah Tagihan"].DefaultCellStyle.Format = "C0";

            foreach (DataGridViewRow row in dgTagihan.Rows)
            {
                try
                {
                    DateTime oDate = Convert.ToDateTime(row.Cells[5].Value.ToString());
                    if (oDate < DateTime.Now)
                    {
                        row.DefaultCellStyle.BackColor = Color.Orange;
                    }
                    else
                    {

                    }
                }
                catch
                {

                }
                

                
            }

        }

        public void LoadForm(string a)
        {
            dgTagihan.DataSource = null;

            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";

            var select = @"SELECT        tr_tagihan.tagihan_id as 'ID Tagihan', ms_acara.acara_nama as 'Nama Acara', ms_user.user_nama as 'Nama Anggota', tr_tagihan.tagihan_status as 'Status Tagihan', tr_tagihan.tagihan_nilai as 'Jumlah Tagihan', tr_tagihan.tagihan_tgl_deadline as 'Deadline'
                            ,ms_acara.acara_id,  ms_user.user_id FROM            ms_user INNER JOIN
                         tr_tagihan ON ms_user.user_id = tr_tagihan.user_id INNER JOIN
                         ms_acara ON tr_tagihan.acara_id = ms_acara.acara_id
						 WHERE tr_tagihan.tagihan_status = 'Belum Lunas'";
            var c = new SqlConnection(ConnectionString); // Your Connection String here
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            // dgTagihan.ReadOnly = true;
            dgTagihan.DataSource = ds.Tables[0];

            //Add a CheckBox Column to the DataGridView at the first position.


            this.dgTagihan.Columns["Deadline"].DefaultCellStyle.Format = "D";
            this.dgTagihan.Columns["user_id"].Visible = false;
            this.dgTagihan.Columns["acara_id"].Visible = false;
            this.dgTagihan.Columns["Jumlah Tagihan"].DefaultCellStyle.Format = "C0";

            foreach (DataGridViewRow row in dgTagihan.Rows)
            {
                try
                {
                    DateTime oDate = Convert.ToDateTime(row.Cells[6].Value.ToString());
                    if (oDate < DateTime.Now)
                    {
                        row.DefaultCellStyle.BackColor = Color.Orange;
                    }
                    else
                    {

                    }
                }
                catch
                {

                }



            }

        }

        private void rbBelumLunas_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void rbSudahLunas_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void rbSemua_CheckedChanged(object sender, EventArgs e)
        {
            LoadForm();
        }

        private void txtCariAnggota_TextChanged(object sender, EventArgs e)
        {
           
            string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
            SqlConnection myConnection = new SqlConnection(ConnectionString);

            SqlCommand search = new SqlCommand("sp_SearchTagihan", myConnection);
            search.CommandType = CommandType.StoredProcedure;

            search.Parameters.AddWithValue("@kata_kunci", txtCari.Text);
            search.Parameters.AddWithValue("@tipe", -1);
            // this.dgTagihan.Columns["Deadline"].DefaultCellStyle.Format = "D";
            using (var adapter = new SqlDataAdapter(search))
            {
                myConnection.Open();
                var myTable = new DataTable();
                adapter.Fill(myTable);
                dgTagihan.DataSource = myTable;
                myConnection.Close();

            }

            foreach (DataGridViewRow row in dgTagihan.Rows)
            {
                DateTime oDate = Convert.ToDateTime(row.Cells[6].Value.ToString());

                if (oDate < DateTime.Now)
                {
                    row.DefaultCellStyle.BackColor = Color.Orange;
                }
                else
                {

                }
            }
        }
        string tagihan="";
        string acara_id = "";
        string user_id = "";
        private void dgTagihan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //btnBayar.Enabled = true;


            foreach (DataGridViewRow row in dgTagihan.SelectedRows)
            {
                try
                {
                txtIDTagihan.Text   = row.Cells[0].Value.ToString();
                txtNamaAcara.Text   = row.Cells[1].Value.ToString();
                txtNamaAnggota.Text = row.Cells[2].Value.ToString();
                tagihan = row.Cells[4].Value.ToString();
                dtDeadline.Value    = Convert.ToDateTime(dgTagihan.Rows[e.RowIndex].Cells[5].Value);
                decimal moneyvalue  = decimal.Parse(tagihan);
                    txtJumlah.Text      = String.Format("{0:C} ", moneyvalue);
                    
                    
                acara_id            = row.Cells[6].Value.ToString();
                user_id             = row.Cells[7].Value.ToString();
                }
                catch
                {

                }

                


            }

            
        }
        public string generateID()
        {
            return Guid.NewGuid().ToString("N");
        }

        private void btnBayar_Click(object sender, EventArgs e)
        {
           
        }

        private void clear()
        {
            txtCari.Clear();
            txtIDTagihan.Clear();
            txtJumlah.Clear();
            txtNamaAcara.Clear();
            txtNamaAnggota.Clear();
            dtDeadline.Value = DateTime.Now;
            LoadForm("");
            string tagihan = "";
            string acara_id = "";
            string user_id = "";
            //btnBayar.Enabled = false;
        }

        private void btnBatal_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void txtJumlah_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Apakah Yakin Ingin Bayar?", "Konfirmasi", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int inserted = 0;
                foreach (DataGridViewRow row in dgTagihan.Rows)
                {
                    bool isSelected = Convert.ToBoolean(row.Cells["checkBoxColumn"].Value);
                    if (isSelected)
                    {
                        try
                        {
                            string connectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                            connectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                            SqlConnection connection = new SqlConnection(connectionstring);
                            SqlCommand insert = new SqlCommand("sp_InputPemasukan_Tagihan", connection);

                            insert.CommandType = CommandType.StoredProcedure;


                            insert.Parameters.AddWithValue("tagihan_status", "Lunas");


                            insert.Parameters.AddWithValue("dtl_id", generateID());
                            insert.Parameters.AddWithValue("tagihan_id", row.Cells["ID Tagihan"].Value);
                            insert.Parameters.AddWithValue("acara_id", row.Cells["acara_id"].Value);
                            insert.Parameters.AddWithValue("user_id", row.Cells["user_id"].Value);
                            insert.Parameters.AddWithValue("tagihan_nilai", row.Cells["Jumlah Tagihan"].Value);
                            insert.Parameters.AddWithValue("tagihan_tgl", DateTime.Now.ToString("yyyy-MM-dd"));

                            connection.Open();
                            insert.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(this, "Tidak berhasil disimpan!: " + ex.Message);
                        }
                        

                        try
                        {
                            
                            // MessageBox.Show(this, "Pembayaran Tagihan Berhasil", "Information",
                            //     MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //


                        }
                        catch 
                        {
                            
                        }
                        inserted++;
                    }
                }

                if (inserted > 0)
                {
                    MessageBox.Show(string.Format("{0} Tagihan Berhasil DiBayarkan", inserted), "Message");
                }
                clear();
            }
            else {
                //tus codigos
            }
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void dgTagihan_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

