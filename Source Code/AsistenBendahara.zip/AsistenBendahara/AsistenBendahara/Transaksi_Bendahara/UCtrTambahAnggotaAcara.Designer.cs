﻿namespace AsistenBendahara.Transaksi
{
    partial class UCtrTambahAnggotaAcara
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCtrTambahAnggotaAcara));
            this.msuserBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pRG2_SILABIDataSet2 = new AsistenBendahara.PRG2_SILABIDataSet2();
            this.msacaraBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pRG2_SILABIDataSet1 = new AsistenBendahara.PRG2_SILABIDataSet1();
            this.ms_acaraTableAdapter = new AsistenBendahara.PRG2_SILABIDataSet1TableAdapters.ms_acaraTableAdapter();
            this.ms_userTableAdapter = new AsistenBendahara.PRG2_SILABIDataSet2TableAdapters.ms_userTableAdapter();
            this.dgAnggotaAcara = new MetroFramework.Controls.MetroGrid();
            this.dgAnggotaTerpilih = new MetroFramework.Controls.MetroGrid();
            this.msuserBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.pRG2_SILABIDataSet7 = new AsistenBendahara.PRG2_SILABIDataSet7();
            this.txtNamaAcara = new System.Windows.Forms.TextBox();
            this.pRG2_SILABIDataSet = new AsistenBendahara.PRG2_SILABIDataSet();
            this.pRG2SILABIDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.msuserBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ms_userTableAdapter1 = new AsistenBendahara.PRG2_SILABIDataSetTableAdapters.ms_userTableAdapter();
            this.pRG2_SILABIDataSet21 = new AsistenBendahara.PRG2_SILABIDataSet2();
            this.msuserBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.pRG2_SILABIDataSet6 = new AsistenBendahara.PRG2_SILABIDataSet6();
            this.msuserBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.ms_userTableAdapter2 = new AsistenBendahara.PRG2_SILABIDataSet6TableAdapters.ms_userTableAdapter();
            this.ms_userTableAdapter3 = new AsistenBendahara.PRG2_SILABIDataSet7TableAdapters.ms_userTableAdapter();
            this.dgAcara = new MetroFramework.Controls.MetroGrid();
            this.acaraidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.acaranamaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.msacaraBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.aCARA_ID_NAMA = new AsistenBendahara.ACARA_ID_NAMA();
            this.pRG2_SILABIDataSet3 = new AsistenBendahara.PRG2_SILABIDataSet3();
            this.msacaraBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ms_acaraTableAdapter1 = new AsistenBendahara.PRG2_SILABIDataSet3TableAdapters.ms_acaraTableAdapter();
            this.msacaraBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.dsACARA_ANGGOTA = new AsistenBendahara.dsACARA_ANGGOTA();
            this.msuserBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.ms_userTableAdapter4 = new AsistenBendahara.dsACARA_ANGGOTATableAdapters.ms_userTableAdapter();
            this.dsACARAANGGOTABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ms_acaraTableAdapter2 = new AsistenBendahara.dsACARA_ANGGOTATableAdapters.ms_acaraTableAdapter();
            this.tr_detail_anggota_acaraTableAdapter = new AsistenBendahara.dsACARA_ANGGOTATableAdapters.tr_detail_anggota_acaraTableAdapter();
            this.aCARA_NAMA = new AsistenBendahara.ACARA_NAMA();
            this.msacaraBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.ms_acaraTableAdapter3 = new AsistenBendahara.ACARA_NAMATableAdapters.ms_acaraTableAdapter();
            this.pRG2_SILABIDataSet8 = new AsistenBendahara.PRG2_SILABIDataSet8();
            this.trdetailanggotaacaraBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tr_detail_anggota_acaraTableAdapter1 = new AsistenBendahara.PRG2_SILABIDataSet8TableAdapters.tr_detail_anggota_acaraTableAdapter();
            this.aCARA_NAMA_ID = new AsistenBendahara.ACARA_NAMA_ID();
            this.msuserBindingSource7 = new System.Windows.Forms.BindingSource(this.components);
            this.ms_userTableAdapter6 = new AsistenBendahara.ACARA_NAMA_IDTableAdapters.ms_userTableAdapter();
            this.ms_acaraTableAdapter4 = new AsistenBendahara.ACARA_ID_NAMATableAdapters.ms_acaraTableAdapter();
            this.dgSemuaAnggota = new MetroFramework.Controls.MetroGrid();
            this.usernamaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.msuserBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.uSER_NAMA = new AsistenBendahara.USER_NAMA();
            this.fKtrdetailanggotaacaramsacaraBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panelKiri = new System.Windows.Forms.Panel();
            this.next = new System.Windows.Forms.PictureBox();
            this.back = new System.Windows.Forms.PictureBox();
            this.btnHapusAll = new System.Windows.Forms.Button();
            this.btnHapus = new System.Windows.Forms.Button();
            this.ms_userTableAdapter5 = new AsistenBendahara.USER_NAMATableAdapters.ms_userTableAdapter();
            this.btnTambah = new System.Windows.Forms.Button();
            this.panelUtama = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgAnggotaAcara)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgAnggotaTerpilih)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2SILABIDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgAcara)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCARA_ID_NAMA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsACARA_ANGGOTA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsACARAANGGOTABindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCARA_NAMA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trdetailanggotaacaraBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCARA_NAMA_ID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgSemuaAnggota)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSER_NAMA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKtrdetailanggotaacaramsacaraBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.panelKiri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.next)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.back)).BeginInit();
            this.panelUtama.SuspendLayout();
            this.SuspendLayout();
            // 
            // msuserBindingSource
            // 
            this.msuserBindingSource.DataMember = "ms_user";
            this.msuserBindingSource.DataSource = this.pRG2_SILABIDataSet2;
            // 
            // pRG2_SILABIDataSet2
            // 
            this.pRG2_SILABIDataSet2.DataSetName = "PRG2_SILABIDataSet2";
            this.pRG2_SILABIDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // msacaraBindingSource
            // 
            this.msacaraBindingSource.DataMember = "ms_acara";
            this.msacaraBindingSource.DataSource = this.pRG2_SILABIDataSet1;
            // 
            // pRG2_SILABIDataSet1
            // 
            this.pRG2_SILABIDataSet1.DataSetName = "PRG2_SILABIDataSet1";
            this.pRG2_SILABIDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ms_acaraTableAdapter
            // 
            this.ms_acaraTableAdapter.ClearBeforeFill = true;
            // 
            // ms_userTableAdapter
            // 
            this.ms_userTableAdapter.ClearBeforeFill = true;
            // 
            // dgAnggotaAcara
            // 
            this.dgAnggotaAcara.AllowUserToDeleteRows = false;
            this.dgAnggotaAcara.AllowUserToResizeRows = false;
            this.dgAnggotaAcara.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgAnggotaAcara.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.dgAnggotaAcara.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgAnggotaAcara.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgAnggotaAcara.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgAnggotaAcara.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgAnggotaAcara.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgAnggotaAcara.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgAnggotaAcara.EnableHeadersVisualStyles = false;
            this.dgAnggotaAcara.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgAnggotaAcara.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgAnggotaAcara.Location = new System.Drawing.Point(18, 29);
            this.dgAnggotaAcara.Name = "dgAnggotaAcara";
            this.dgAnggotaAcara.ReadOnly = true;
            this.dgAnggotaAcara.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgAnggotaAcara.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgAnggotaAcara.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgAnggotaAcara.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgAnggotaAcara.Size = new System.Drawing.Size(212, 376);
            this.dgAnggotaAcara.TabIndex = 47;
            this.dgAnggotaAcara.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgAnggotaAcara_CellClick);
            // 
            // dgAnggotaTerpilih
            // 
            this.dgAnggotaTerpilih.AllowUserToResizeRows = false;
            this.dgAnggotaTerpilih.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgAnggotaTerpilih.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgAnggotaTerpilih.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgAnggotaTerpilih.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgAnggotaTerpilih.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgAnggotaTerpilih.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgAnggotaTerpilih.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgAnggotaTerpilih.Enabled = false;
            this.dgAnggotaTerpilih.EnableHeadersVisualStyles = false;
            this.dgAnggotaTerpilih.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgAnggotaTerpilih.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.dgAnggotaTerpilih.Location = new System.Drawing.Point(1266, 117);
            this.dgAnggotaTerpilih.Name = "dgAnggotaTerpilih";
            this.dgAnggotaTerpilih.ReadOnly = true;
            this.dgAnggotaTerpilih.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgAnggotaTerpilih.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgAnggotaTerpilih.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgAnggotaTerpilih.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgAnggotaTerpilih.Size = new System.Drawing.Size(181, 407);
            this.dgAnggotaTerpilih.TabIndex = 45;
            this.dgAnggotaTerpilih.Visible = false;
            this.dgAnggotaTerpilih.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgAnggotaTerpilih_KeyDown);
            this.dgAnggotaTerpilih.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgAnggotaTerpilih_MouseUp);
            // 
            // msuserBindingSource4
            // 
            this.msuserBindingSource4.DataMember = "ms_user";
            this.msuserBindingSource4.DataSource = this.pRG2_SILABIDataSet7;
            // 
            // pRG2_SILABIDataSet7
            // 
            this.pRG2_SILABIDataSet7.DataSetName = "PRG2_SILABIDataSet7";
            this.pRG2_SILABIDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txtNamaAcara
            // 
            this.txtNamaAcara.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtNamaAcara.Enabled = false;
            this.txtNamaAcara.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.txtNamaAcara.Location = new System.Drawing.Point(116, 89);
            this.txtNamaAcara.MaxLength = 13;
            this.txtNamaAcara.Name = "txtNamaAcara";
            this.txtNamaAcara.Size = new System.Drawing.Size(198, 23);
            this.txtNamaAcara.TabIndex = 51;
            // 
            // pRG2_SILABIDataSet
            // 
            this.pRG2_SILABIDataSet.DataSetName = "PRG2_SILABIDataSet";
            this.pRG2_SILABIDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pRG2SILABIDataSetBindingSource
            // 
            this.pRG2SILABIDataSetBindingSource.DataSource = this.pRG2_SILABIDataSet;
            this.pRG2SILABIDataSetBindingSource.Position = 0;
            // 
            // msuserBindingSource1
            // 
            this.msuserBindingSource1.DataMember = "ms_user";
            this.msuserBindingSource1.DataSource = this.pRG2SILABIDataSetBindingSource;
            // 
            // ms_userTableAdapter1
            // 
            this.ms_userTableAdapter1.ClearBeforeFill = true;
            // 
            // pRG2_SILABIDataSet21
            // 
            this.pRG2_SILABIDataSet21.DataSetName = "PRG2_SILABIDataSet2";
            this.pRG2_SILABIDataSet21.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // msuserBindingSource2
            // 
            this.msuserBindingSource2.DataMember = "ms_user";
            this.msuserBindingSource2.DataSource = this.pRG2_SILABIDataSet21;
            // 
            // pRG2_SILABIDataSet6
            // 
            this.pRG2_SILABIDataSet6.DataSetName = "PRG2_SILABIDataSet6";
            this.pRG2_SILABIDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // msuserBindingSource3
            // 
            this.msuserBindingSource3.DataMember = "ms_user";
            this.msuserBindingSource3.DataSource = this.pRG2_SILABIDataSet6;
            // 
            // ms_userTableAdapter2
            // 
            this.ms_userTableAdapter2.ClearBeforeFill = true;
            // 
            // ms_userTableAdapter3
            // 
            this.ms_userTableAdapter3.ClearBeforeFill = true;
            // 
            // dgAcara
            // 
            this.dgAcara.AllowUserToAddRows = false;
            this.dgAcara.AllowUserToDeleteRows = false;
            this.dgAcara.AllowUserToResizeRows = false;
            this.dgAcara.AutoGenerateColumns = false;
            this.dgAcara.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.dgAcara.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgAcara.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgAcara.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgAcara.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgAcara.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAcara.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.acaraidDataGridViewTextBoxColumn,
            this.acaranamaDataGridViewTextBoxColumn});
            this.dgAcara.DataSource = this.msacaraBindingSource4;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgAcara.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgAcara.EnableHeadersVisualStyles = false;
            this.dgAcara.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgAcara.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgAcara.Location = new System.Drawing.Point(23, 15);
            this.dgAcara.Name = "dgAcara";
            this.dgAcara.ReadOnly = true;
            this.dgAcara.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgAcara.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgAcara.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgAcara.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgAcara.Size = new System.Drawing.Size(144, 390);
            this.dgAcara.TabIndex = 50;
            this.dgAcara.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgAcara_CellClick);
            // 
            // acaraidDataGridViewTextBoxColumn
            // 
            this.acaraidDataGridViewTextBoxColumn.DataPropertyName = "acara_id";
            this.acaraidDataGridViewTextBoxColumn.HeaderText = "ID Acara";
            this.acaraidDataGridViewTextBoxColumn.Name = "acaraidDataGridViewTextBoxColumn";
            this.acaraidDataGridViewTextBoxColumn.ReadOnly = true;
            this.acaraidDataGridViewTextBoxColumn.Visible = false;
            this.acaraidDataGridViewTextBoxColumn.Width = 50;
            // 
            // acaranamaDataGridViewTextBoxColumn
            // 
            this.acaranamaDataGridViewTextBoxColumn.DataPropertyName = "acara_nama";
            this.acaranamaDataGridViewTextBoxColumn.HeaderText = "Nama Acara";
            this.acaranamaDataGridViewTextBoxColumn.Name = "acaranamaDataGridViewTextBoxColumn";
            this.acaranamaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // msacaraBindingSource4
            // 
            this.msacaraBindingSource4.DataMember = "ms_acara";
            this.msacaraBindingSource4.DataSource = this.aCARA_ID_NAMA;
            // 
            // aCARA_ID_NAMA
            // 
            this.aCARA_ID_NAMA.DataSetName = "ACARA_ID_NAMA";
            this.aCARA_ID_NAMA.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pRG2_SILABIDataSet3
            // 
            this.pRG2_SILABIDataSet3.DataSetName = "PRG2_SILABIDataSet3";
            this.pRG2_SILABIDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // msacaraBindingSource1
            // 
            this.msacaraBindingSource1.DataMember = "ms_acara";
            this.msacaraBindingSource1.DataSource = this.pRG2_SILABIDataSet3;
            // 
            // ms_acaraTableAdapter1
            // 
            this.ms_acaraTableAdapter1.ClearBeforeFill = true;
            // 
            // msacaraBindingSource2
            // 
            this.msacaraBindingSource2.DataMember = "ms_acara";
            this.msacaraBindingSource2.DataSource = this.dsACARA_ANGGOTA;
            // 
            // dsACARA_ANGGOTA
            // 
            this.dsACARA_ANGGOTA.DataSetName = "dsACARA_ANGGOTA";
            this.dsACARA_ANGGOTA.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // msuserBindingSource5
            // 
            this.msuserBindingSource5.DataMember = "ms_user";
            this.msuserBindingSource5.DataSource = this.dsACARA_ANGGOTA;
            // 
            // ms_userTableAdapter4
            // 
            this.ms_userTableAdapter4.ClearBeforeFill = true;
            // 
            // dsACARAANGGOTABindingSource
            // 
            this.dsACARAANGGOTABindingSource.DataSource = this.dsACARA_ANGGOTA;
            this.dsACARAANGGOTABindingSource.Position = 0;
            // 
            // ms_acaraTableAdapter2
            // 
            this.ms_acaraTableAdapter2.ClearBeforeFill = true;
            // 
            // tr_detail_anggota_acaraTableAdapter
            // 
            this.tr_detail_anggota_acaraTableAdapter.ClearBeforeFill = true;
            // 
            // aCARA_NAMA
            // 
            this.aCARA_NAMA.DataSetName = "ACARA_NAMA";
            this.aCARA_NAMA.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // msacaraBindingSource3
            // 
            this.msacaraBindingSource3.DataMember = "ms_acara";
            this.msacaraBindingSource3.DataSource = this.aCARA_NAMA;
            // 
            // ms_acaraTableAdapter3
            // 
            this.ms_acaraTableAdapter3.ClearBeforeFill = true;
            // 
            // pRG2_SILABIDataSet8
            // 
            this.pRG2_SILABIDataSet8.DataSetName = "PRG2_SILABIDataSet8";
            this.pRG2_SILABIDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // trdetailanggotaacaraBindingSource
            // 
            this.trdetailanggotaacaraBindingSource.DataMember = "tr_detail_anggota_acara";
            this.trdetailanggotaacaraBindingSource.DataSource = this.pRG2_SILABIDataSet8;
            // 
            // tr_detail_anggota_acaraTableAdapter1
            // 
            this.tr_detail_anggota_acaraTableAdapter1.ClearBeforeFill = true;
            // 
            // aCARA_NAMA_ID
            // 
            this.aCARA_NAMA_ID.DataSetName = "ACARA_NAMA_ID";
            this.aCARA_NAMA_ID.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // msuserBindingSource7
            // 
            this.msuserBindingSource7.DataMember = "ms_user";
            this.msuserBindingSource7.DataSource = this.aCARA_NAMA_ID;
            // 
            // ms_userTableAdapter6
            // 
            this.ms_userTableAdapter6.ClearBeforeFill = true;
            // 
            // ms_acaraTableAdapter4
            // 
            this.ms_acaraTableAdapter4.ClearBeforeFill = true;
            // 
            // dgSemuaAnggota
            // 
            this.dgSemuaAnggota.AllowUserToAddRows = false;
            this.dgSemuaAnggota.AllowUserToDeleteRows = false;
            this.dgSemuaAnggota.AllowUserToResizeRows = false;
            this.dgSemuaAnggota.AutoGenerateColumns = false;
            this.dgSemuaAnggota.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.dgSemuaAnggota.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgSemuaAnggota.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgSemuaAnggota.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgSemuaAnggota.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgSemuaAnggota.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSemuaAnggota.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.usernamaDataGridViewTextBoxColumn});
            this.dgSemuaAnggota.DataSource = this.msuserBindingSource6;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgSemuaAnggota.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgSemuaAnggota.Enabled = false;
            this.dgSemuaAnggota.EnableHeadersVisualStyles = false;
            this.dgSemuaAnggota.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgSemuaAnggota.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgSemuaAnggota.Location = new System.Drawing.Point(264, 29);
            this.dgSemuaAnggota.Name = "dgSemuaAnggota";
            this.dgSemuaAnggota.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgSemuaAnggota.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgSemuaAnggota.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgSemuaAnggota.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgSemuaAnggota.Size = new System.Drawing.Size(629, 376);
            this.dgSemuaAnggota.TabIndex = 42;
            this.dgSemuaAnggota.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSemuaAnggota_CellClick);
            // 
            // usernamaDataGridViewTextBoxColumn
            // 
            this.usernamaDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.usernamaDataGridViewTextBoxColumn.DataPropertyName = "user_nama";
            this.usernamaDataGridViewTextBoxColumn.HeaderText = "Nama Anggota";
            this.usernamaDataGridViewTextBoxColumn.Name = "usernamaDataGridViewTextBoxColumn";
            this.usernamaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // msuserBindingSource6
            // 
            this.msuserBindingSource6.DataMember = "ms_user";
            this.msuserBindingSource6.DataSource = this.uSER_NAMA;
            // 
            // uSER_NAMA
            // 
            this.uSER_NAMA.DataSetName = "USER_NAMA";
            this.uSER_NAMA.EnforceConstraints = false;
            this.uSER_NAMA.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fKtrdetailanggotaacaramsacaraBindingSource
            // 
            this.fKtrdetailanggotaacaramsacaraBindingSource.DataMember = "FK_tr_detail_anggota_acara_ms_acara";
            this.fKtrdetailanggotaacaramsacaraBindingSource.DataSource = this.msacaraBindingSource2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtNamaAcara);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1116, 120);
            this.panel1.TabIndex = 59;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(53, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(242, 42);
            this.label2.TabIndex = 64;
            this.label2.Text = "Kelola Acara";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(20, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 18);
            this.label4.TabIndex = 52;
            this.label4.Text = "Nama Acara";
            // 
            // panelKiri
            // 
            this.panelKiri.Controls.Add(this.next);
            this.panelKiri.Controls.Add(this.back);
            this.panelKiri.Controls.Add(this.dgAcara);
            this.panelKiri.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelKiri.Location = new System.Drawing.Point(0, 120);
            this.panelKiri.Name = "panelKiri";
            this.panelKiri.Size = new System.Drawing.Size(200, 488);
            this.panelKiri.TabIndex = 60;
            // 
            // next
            // 
            this.next.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.next.Cursor = System.Windows.Forms.Cursors.Hand;
            this.next.Image = ((System.Drawing.Image)(resources.GetObject("next.Image")));
            this.next.Location = new System.Drawing.Point(176, 0);
            this.next.Name = "next";
            this.next.Size = new System.Drawing.Size(25, 30);
            this.next.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.next.TabIndex = 62;
            this.next.TabStop = false;
            this.next.Visible = false;
            this.next.Click += new System.EventHandler(this.next_Click);
            // 
            // back
            // 
            this.back.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back.Image = ((System.Drawing.Image)(resources.GetObject("back.Image")));
            this.back.Location = new System.Drawing.Point(176, 0);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(25, 30);
            this.back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.back.TabIndex = 61;
            this.back.TabStop = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // btnHapusAll
            // 
            this.btnHapusAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnHapusAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHapusAll.FlatAppearance.BorderSize = 0;
            this.btnHapusAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHapusAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnHapusAll.ForeColor = System.Drawing.Color.White;
            this.btnHapusAll.Location = new System.Drawing.Point(120, 411);
            this.btnHapusAll.Name = "btnHapusAll";
            this.btnHapusAll.Size = new System.Drawing.Size(110, 35);
            this.btnHapusAll.TabIndex = 63;
            this.btnHapusAll.Text = "Tendang\r\nSemua";
            this.btnHapusAll.UseVisualStyleBackColor = false;
            this.btnHapusAll.Click += new System.EventHandler(this.btnHapusAll_Click_1);
            // 
            // btnHapus
            // 
            this.btnHapus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnHapus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHapus.FlatAppearance.BorderSize = 0;
            this.btnHapus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHapus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHapus.ForeColor = System.Drawing.Color.White;
            this.btnHapus.Location = new System.Drawing.Point(18, 411);
            this.btnHapus.Name = "btnHapus";
            this.btnHapus.Size = new System.Drawing.Size(96, 35);
            this.btnHapus.TabIndex = 61;
            this.btnHapus.Text = "Tendang";
            this.btnHapus.UseVisualStyleBackColor = false;
            this.btnHapus.Click += new System.EventHandler(this.btnHapus_Click_1);
            // 
            // ms_userTableAdapter5
            // 
            this.ms_userTableAdapter5.ClearBeforeFill = true;
            // 
            // btnTambah
            // 
            this.btnTambah.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(182)))));
            this.btnTambah.FlatAppearance.BorderSize = 0;
            this.btnTambah.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTambah.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTambah.ForeColor = System.Drawing.Color.White;
            this.btnTambah.Location = new System.Drawing.Point(264, 410);
            this.btnTambah.Name = "btnTambah";
            this.btnTambah.Size = new System.Drawing.Size(629, 35);
            this.btnTambah.TabIndex = 62;
            this.btnTambah.Text = "Bergabung";
            this.btnTambah.UseVisualStyleBackColor = false;
            this.btnTambah.Click += new System.EventHandler(this.button1_Click);
            // 
            // panelUtama
            // 
            this.panelUtama.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.panelUtama.Controls.Add(this.label3);
            this.panelUtama.Controls.Add(this.label1);
            this.panelUtama.Controls.Add(this.btnTambah);
            this.panelUtama.Controls.Add(this.btnHapusAll);
            this.panelUtama.Controls.Add(this.btnHapus);
            this.panelUtama.Controls.Add(this.dgSemuaAnggota);
            this.panelUtama.Controls.Add(this.dgAnggotaAcara);
            this.panelUtama.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelUtama.Location = new System.Drawing.Point(200, 120);
            this.panelUtama.Name = "panelUtama";
            this.panelUtama.Size = new System.Drawing.Size(916, 488);
            this.panelUtama.TabIndex = 63;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(15, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 15);
            this.label3.TabIndex = 65;
            this.label3.Text = "Table Anggota yang berhabung";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(261, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 15);
            this.label1.TabIndex = 64;
            this.label1.Text = "Table Anggota yang belum berhabung";
            // 
            // UCtrTambahAnggotaAcara
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.Controls.Add(this.panelUtama);
            this.Controls.Add(this.panelKiri);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgAnggotaTerpilih);
            this.Name = "UCtrTambahAnggotaAcara";
            this.Size = new System.Drawing.Size(1116, 608);
            this.Load += new System.EventHandler(this.UCtrTambahAnggotaAcara_Load);
            this.MouseHover += new System.EventHandler(this.UCtrTambahAnggotaAcara_MouseHover);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.UCtrTambahAnggotaAcara_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgAnggotaAcara)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgAnggotaTerpilih)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2SILABIDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgAcara)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCARA_ID_NAMA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsACARA_ANGGOTA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsACARAANGGOTABindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCARA_NAMA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msacaraBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRG2_SILABIDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trdetailanggotaacaraBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCARA_NAMA_ID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgSemuaAnggota)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msuserBindingSource6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSER_NAMA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKtrdetailanggotaacaramsacaraBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelKiri.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.next)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.back)).EndInit();
            this.panelUtama.ResumeLayout(false);
            this.panelUtama.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource msuserBindingSource;
        private PRG2_SILABIDataSet2 pRG2_SILABIDataSet2;
        private System.Windows.Forms.BindingSource msacaraBindingSource;
        private PRG2_SILABIDataSet1 pRG2_SILABIDataSet1;
        private PRG2_SILABIDataSet1TableAdapters.ms_acaraTableAdapter ms_acaraTableAdapter;
        private PRG2_SILABIDataSet2TableAdapters.ms_userTableAdapter ms_userTableAdapter;
        private MetroFramework.Controls.MetroGrid dgAnggotaAcara;
        private MetroFramework.Controls.MetroGrid dgAnggotaTerpilih;
        private System.Windows.Forms.BindingSource msuserBindingSource1;
        private System.Windows.Forms.BindingSource pRG2SILABIDataSetBindingSource;
        private PRG2_SILABIDataSet pRG2_SILABIDataSet;
        private PRG2_SILABIDataSetTableAdapters.ms_userTableAdapter ms_userTableAdapter1;
        private System.Windows.Forms.BindingSource msuserBindingSource2;
        private PRG2_SILABIDataSet2 pRG2_SILABIDataSet21;
        private System.Windows.Forms.BindingSource msuserBindingSource3;
        private PRG2_SILABIDataSet6 pRG2_SILABIDataSet6;
        private PRG2_SILABIDataSet6TableAdapters.ms_userTableAdapter ms_userTableAdapter2;
        private System.Windows.Forms.BindingSource msuserBindingSource4;
        private PRG2_SILABIDataSet7 pRG2_SILABIDataSet7;
        private PRG2_SILABIDataSet7TableAdapters.ms_userTableAdapter ms_userTableAdapter3;
        private MetroFramework.Controls.MetroGrid dgAcara;
        private System.Windows.Forms.TextBox txtNamaAcara;
        private System.Windows.Forms.BindingSource msacaraBindingSource1;
        private PRG2_SILABIDataSet3 pRG2_SILABIDataSet3;
        private PRG2_SILABIDataSet3TableAdapters.ms_acaraTableAdapter ms_acaraTableAdapter1;
        private System.Windows.Forms.BindingSource msuserBindingSource5;
        private dsACARA_ANGGOTA dsACARA_ANGGOTA;
        private System.Windows.Forms.BindingSource msacaraBindingSource2;
        private dsACARA_ANGGOTATableAdapters.ms_userTableAdapter ms_userTableAdapter4;
        private System.Windows.Forms.BindingSource dsACARAANGGOTABindingSource;
        private dsACARA_ANGGOTATableAdapters.ms_acaraTableAdapter ms_acaraTableAdapter2;
        private System.Windows.Forms.BindingSource msacaraBindingSource3;
        private ACARA_NAMA aCARA_NAMA;
        private System.Windows.Forms.BindingSource fKtrdetailanggotaacaramsacaraBindingSource;
        private dsACARA_ANGGOTATableAdapters.tr_detail_anggota_acaraTableAdapter tr_detail_anggota_acaraTableAdapter;
        private ACARA_NAMATableAdapters.ms_acaraTableAdapter ms_acaraTableAdapter3;
        private System.Windows.Forms.BindingSource trdetailanggotaacaraBindingSource;
        private PRG2_SILABIDataSet8 pRG2_SILABIDataSet8;
        private System.Windows.Forms.BindingSource msuserBindingSource6;
        private USER_NAMA uSER_NAMA;
        private PRG2_SILABIDataSet8TableAdapters.tr_detail_anggota_acaraTableAdapter tr_detail_anggota_acaraTableAdapter1;
        private USER_NAMATableAdapters.ms_userTableAdapter ms_userTableAdapter5;
        private System.Windows.Forms.BindingSource msuserBindingSource7;
        private ACARA_NAMA_ID aCARA_NAMA_ID;
        private ACARA_NAMA_IDTableAdapters.ms_userTableAdapter ms_userTableAdapter6;
        private System.Windows.Forms.BindingSource msacaraBindingSource4;
        private ACARA_ID_NAMA aCARA_ID_NAMA;
        private ACARA_ID_NAMATableAdapters.ms_acaraTableAdapter ms_acaraTableAdapter4;
        private MetroFramework.Controls.MetroGrid dgSemuaAnggota;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn acaraidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn acaranamaDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panelKiri;
        private System.Windows.Forms.PictureBox back;
        private System.Windows.Forms.PictureBox next;
        private System.Windows.Forms.Button btnHapusAll;
        private System.Windows.Forms.Button btnHapus;
        private System.Windows.Forms.Button btnTambah;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panelUtama;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernamaDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
    }
}
