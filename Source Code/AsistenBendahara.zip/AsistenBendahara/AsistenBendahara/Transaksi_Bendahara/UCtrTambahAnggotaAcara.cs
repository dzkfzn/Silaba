﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MetroFramework;

using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace AsistenBendahara.Transaksi
{
    public partial class UCtrTambahAnggotaAcara : UserControl
    {
        public UCtrTambahAnggotaAcara()
        {
            InitializeComponent();
            
        }


        private void clear()
        {
            dgAnggotaTerpilih.DataSource = null;
           // dgSemuaAnggota.DataSource = null;

            DataTable dt = new DataTable();
            dt.Columns.Add("Calon Anggota");
            dgAnggotaTerpilih.DataSource = dt;
            DataGridViewColumn column = dgAnggotaTerpilih.Columns[0];
            column.Width = 150;

            dgSemuaAnggota.Enabled = true;
            dgAnggotaTerpilih.Enabled = true;
            foreach (DataGridViewRow row in dgAcara.SelectedRows)
            {
                id_acara = row.Cells[0].Value.ToString();
                txtNamaAcara.Text = row.Cells[1].Value.ToString();
            }
            BindGrid();
            txtNamaAcara.Text = "";
            id_acara = "";
            //txtCariAnggota.Text = "";
            btnTambah.Enabled = false;
            btnHapus.Enabled = false;
            btnHapusAll.Enabled = false;
            dgAnggotaAcara.DataSource = null;

            foreach (DataGridViewRow row in dgSemuaAnggota.Rows)
            {
                DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)row.Cells[0];
                if (chk.Value == chk.FalseValue || chk.Value == null)
                {
                    chk.Value = chk.TrueValue;
                }
                else
                {
                    chk.Value = chk.FalseValue;
                }

            }
            dgSemuaAnggota.EndEdit();



        }

        string tanggal_mulai;
        decimal total_tagihan;
        string jenis_tagihan;
        int total_jumlah_tagihan;
        string id_tagihan;
        string id_acara = "";
        string ConnectionString = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";

        private void BindGrid()
        {
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                string join = "SELECT ms_user.user_nama AS 'Anggota Acara' FROM ms_acara  " +
                    " INNER JOIN tr_detail_anggota_acara ON ms_acara.acara_id = tr_detail_anggota_acara.acara_id INNER JOIN " +
                    " ms_user ON tr_detail_anggota_acara.user_id = ms_user.user_id " +
                    " WHERE (tr_detail_anggota_acara.acara_id = '" + id_acara + "')";
                using (SqlCommand cmd = new SqlCommand(join, con))
                {
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            dgAnggotaAcara.DataSource = dt;
                        }
                    }
                }
            }
            DataGridViewColumn column = dgAnggotaAcara.Columns[0];
            column.Width = 150;
        }

        public void UCtrTambahAnggotaAcara_Load(object sender, EventArgs e)
        {
            this.ms_acaraTableAdapter4.Fill(this.aCARA_ID_NAMA.ms_acara);
           // this.ms_userTableAdapter5.Fill(this.uSER_NAMA.ms_user, id_acara);
            this.tr_detail_anggota_acaraTableAdapter.Fill(this.dsACARA_ANGGOTA.tr_detail_anggota_acara);
            

            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            checkBoxColumn.HeaderText = "";
            checkBoxColumn.Width = 30;
            checkBoxColumn.Name = "checkBoxColumn";
            dgSemuaAnggota.Columns.Insert(0, checkBoxColumn);

            DataTable dt = new DataTable();
            dt.Columns.Add("Calon Anggota");
            dgAnggotaTerpilih.DataSource = dt;
            DataGridViewColumn column = dgAnggotaTerpilih.Columns[0];
            column.Width = 150;
           // this.dgAcara.Columns["ID Acara"].Visible = false;
        }

        public void refreshData()
        {
            this.ms_acaraTableAdapter4.Fill(this.aCARA_ID_NAMA.ms_acara);
           // this.ms_userTableAdapter5.Fill(this.uSER_NAMA.ms_user, id_acara);
            this.tr_detail_anggota_acaraTableAdapter.Fill(this.dsACARA_ANGGOTA.tr_detail_anggota_acara);
            clear();

            //DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            //checkBoxColumn.HeaderText = "";
            //checkBoxColumn.Width = 30;
            //checkBoxColumn.Name = "checkBoxColumn";
            //dgSemuaAnggota.Columns.Insert(0, checkBoxColumn);

            //DataTable dt = new DataTable();
            //dt.Columns.Add("Calon Anggota");
            //dgAnggotaTerpilih.DataSource = dt;
            //DataGridViewColumn column = dgAnggotaTerpilih.Columns[0];
            //column.Width = 150;
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {

        }

        private void dgSemuaAnggota_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnBatal_Click(object sender, EventArgs e)
        {
            
        }

        private void dgAcara_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            btnHapus.Enabled = true;
            btnHapusAll.Enabled = true;

            dgSemuaAnggota.Enabled = true;
            dgAnggotaTerpilih.Enabled = true;
            foreach (DataGridViewRow row in dgAcara.SelectedRows)
            {
                id_acara = row.Cells[0].Value.ToString();
                txtNamaAcara.Text = row.Cells[1].Value.ToString();
            }
            BindGrid();
            this.ms_userTableAdapter5.Fill(this.uSER_NAMA.ms_user, id_acara);
            //foreach (DataGridViewRow row in dgSemuaAnggota.Rows)
            //{
            //    foreach (DataGridViewRow rowAnggota in dgAnggotaAcara.Rows)
            //    {
            //        if(row.Cells[1].Value.ToString() == rowAnggota.Cells[0].Value.ToString())
            //        {
            //            txtNamaAcara.Text = "yes";
            //        }

            //    }
            //}
        }
        int keluar = 0;
        int keluarv2 = 0;
        string dateTime = "";

        private void btnTambah_Click(object sender, EventArgs e)
        {
            
           
        }

        private void tambah()
        {
            int isAda = 0;
            int habis = 0;
            string anggota_terpilih = "";
            string anggota_acara = "";

            foreach (DataGridViewRow row in dgAnggotaTerpilih.Rows)
            {
                try
                {
                    anggota_terpilih = row.Cells[0].Value.ToString();
                }
                catch
                {
                    foreach (DataGridViewRow row3 in dgAnggotaTerpilih.Rows)
                    {
                        try
                        {
                            anggota_terpilih = row3.Cells[0].Value.ToString();
                        }
                        catch
                        {
                            habis = 1;
                            this.ms_userTableAdapter5.Fill(this.uSER_NAMA.ms_user, id_acara);
                            MessageBox.Show(this, "Anggota Berhasil Ditambah!", "Information",
                               MessageBoxButtons.OK, MessageBoxIcon.Information);
                            BindGrid();
                            //  clear();
                        }

                        if (habis == 1)
                        {
                            habis = 0;
                            return;
                        }



                        string user_id;
                        string sql = "SELECT user_id FROM ms_user WHERE (user_nama = '" + anggota_terpilih + "') ";

                        SqlConnection myConn = new SqlConnection(ConnectionString);
                        try
                        {
                            SqlCommand myCmd = new SqlCommand(sql, myConn);
                            if (myConn.State != ConnectionState.Open)
                                myConn.Open();
                            user_id = Convert.ToString(myCmd.ExecuteScalar());
                        }
                        finally
                        {
                            if (myConn.State != ConnectionState.Closed)
                                myConn.Close();
                        }

                        SqlConnection connection = new SqlConnection(ConnectionString);
                        SqlCommand insert = new SqlCommand("sp_InputAnggotaAcara", connection);

                        insert.CommandType = CommandType.StoredProcedure;

                        insert.Parameters.AddWithValue("acara_id", id_acara);
                        insert.Parameters.AddWithValue("user_id", user_id);
                        connection.Open();
                        insert.ExecuteNonQuery();
                        connection.Close();

                        int hari;

                        try
                        {


                            // ===== INPUT TAGIHAN ======

                            // ===== NGAMBIL JUMLAH HARI DAN JENIS TAGIHAN
                            string sql2 = "SELECT acara_hari FROM ms_acara WHERE (acara_id = '" + id_acara + "') ";
                            using (SqlConnection conn = new SqlConnection(ConnectionString))
                            {
                                SqlCommand cmd = new SqlCommand(sql2, conn);
                                conn.Open();
                                hari = (int)cmd.ExecuteScalar();
                                conn.Close();
                            }

                            // ===== NGAMBIL JENIS TAGIHAN
                            string sql3 = "SELECT acara_jenis_tagihan FROM ms_acara WHERE (acara_id = '" + id_acara + "') ";
                            using (SqlConnection conn = new SqlConnection(ConnectionString))
                            {
                                SqlCommand cmd = new SqlCommand(sql3, conn);
                                conn.Open();
                                jenis_tagihan = Convert.ToString(cmd.ExecuteScalar());
                                conn.Close();
                            }

                            // ===== NGAMBIL  TAGIHAN
                            string sql4 = "SELECT acara_jumlah_tagihan FROM ms_acara WHERE (acara_id = '" + id_acara + "') ";
                            using (SqlConnection conn = new SqlConnection(ConnectionString))
                            {
                                SqlCommand cmd = new SqlCommand(sql4, conn);
                                conn.Open();
                                total_tagihan = (decimal)cmd.ExecuteScalar();
                                conn.Close();
                            }
                            DateTime tanggal_deadline = DateTime.MinValue;
                            keluar = 0;




                            if (jenis_tagihan == "Mingguan")
                            {
                                total_jumlah_tagihan = hari / 7;
                            }
                            if (jenis_tagihan == "Bulanan")
                            {
                                total_jumlah_tagihan = hari / 30;
                            }
                            if (jenis_tagihan == "Tahunan")
                            {
                                total_jumlah_tagihan = hari / 365;
                            }
                            for (int i = 0; i < total_jumlah_tagihan; i++)
                            {
                                id_tagihan = autoid();


                                if (jenis_tagihan == "Mingguan")
                                {
                                    if (keluar == 0)
                                    {
                                        string sql5 = "SELECT DATEADD(Day, 7, acara_tanggal_mulai) FROM ms_acara WHERE (acara_id = '" + id_acara + "') ";
                                        using (SqlConnection conn = new SqlConnection(ConnectionString))
                                        {
                                            SqlCommand cmd = new SqlCommand(sql5, conn);
                                            conn.Open();
                                            tanggal_deadline = Convert.ToDateTime(cmd.ExecuteScalar());
                                            dateTime = tanggal_deadline.ToString("yyyy-MM-dd");
                                            conn.Close();
                                            keluar = 1;
                                        }
                                    }
                                    else
                                    if (keluar == 1)
                                    {
                                        //tanggal_deadline = Convert.ToDateTime(dateTime);
                                        tanggal_deadline = tanggal_deadline.AddDays(7);
                                        dateTime = tanggal_deadline.ToString("yyyy-MM-dd");
                                    }


                                }


                                if (jenis_tagihan == "Bulanan")
                                {
                                    if (keluar == 0)
                                    {
                                        string sql5 = "SELECT DATEADD(month, 1, acara_tanggal_mulai) FROM ms_acara WHERE (acara_id = '" + id_acara + "') ";
                                        using (SqlConnection conn = new SqlConnection(ConnectionString))
                                        {
                                            SqlCommand cmd = new SqlCommand(sql5, conn);
                                            conn.Open();
                                            tanggal_deadline = Convert.ToDateTime(cmd.ExecuteScalar());
                                            dateTime = tanggal_deadline.ToString("yyyy-MM-dd");
                                            conn.Close();
                                            keluar = 1;
                                        }
                                    }
                                    else
                                    if (keluar == 1)
                                    {
                                        //tanggal_deadline = Convert.ToDateTime(dateTime);
                                        tanggal_deadline = tanggal_deadline.AddMonths(1);
                                        dateTime = tanggal_deadline.ToString("yyyy-MM-dd");
                                    }
                                }

                                if (jenis_tagihan == "Tahunan")
                                {
                                    if (keluar == 0)
                                    {
                                        string sql5 = "SELECT DATEADD(Year, 1, acara_tanggal_mulai) FROM ms_acara WHERE (acara_id = '" + id_acara + "') ";
                                        using (SqlConnection conn = new SqlConnection(ConnectionString))
                                        {
                                            SqlCommand cmd = new SqlCommand(sql5, conn);
                                            conn.Open();
                                            tanggal_deadline = Convert.ToDateTime(cmd.ExecuteScalar());
                                            dateTime = tanggal_deadline.ToString("yyyy-MM-dd");
                                            conn.Close();
                                            keluar = 1;
                                        }
                                    }
                                    else
                                     if (keluar == 1)
                                    {
                                        //tanggal_deadline = Convert.ToDateTime(dateTime);
                                        tanggal_deadline = tanggal_deadline.AddYears(1);
                                        dateTime = tanggal_deadline.ToString("yyyy-MM-dd");
                                    }
                                }


                                string connectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                                SqlConnection connection2 = new SqlConnection(connectionstring);
                                SqlCommand insert2 = new SqlCommand("sp_InputTagihan", connection2);

                                insert2.CommandType = CommandType.StoredProcedure;

                                int total_tagihan_string = (int)total_tagihan;
                                insert2.Parameters.AddWithValue("tagihan_id", id_tagihan);
                                insert2.Parameters.AddWithValue("acara_id", id_acara);
                                insert2.Parameters.AddWithValue("user_id", user_id);
                                insert2.Parameters.AddWithValue("tagihan_status", "Belum Lunas");
                                insert2.Parameters.AddWithValue("tagihan_nilai", total_tagihan_string);
                                insert2.Parameters.AddWithValue("tagihan_tgl_deadline", dateTime);


                                connection2.Open();
                                insert2.ExecuteNonQuery();
                                //  MessageBox.Show(this, "Data berhasil disimpan", "Information",
                                //      MessageBoxButtons.OK, MessageBoxIcon.Information);
                                connection2.Close();

                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(this, "Tidak berhasil disimpan!: " + ex.Message);
                        }


                    }
                }

                if (habis == 1)
                {
                    habis = 0;
                    return;
                }


                foreach (DataGridViewRow row2 in dgAnggotaAcara.Rows)
                {

                    try
                    {
                        anggota_acara = row2.Cells[0].Value.ToString();
                        if (anggota_terpilih == anggota_acara)
                        {
                            isAda = 1;

                        }
                    }
                    catch
                    {

                    }
                }
                if (isAda == 1)
                {
                    MessageBox.Show(this, "Anggota " + "Gagal ditambahkan karena data sudah ada yang terdapat menjadi Anggota!", "Warning",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    isAda = 0;
                    return;
                }

            }



        }

        private string autoid()
        {
            DataSet myDataSet = new DataSet();
            string maxid = "";
            int id_tagihan;
            string id = "";
            try
            {

                string myConnectionString = "integrated security=true;data source =.; initial catalog = PRG2_SILABI";

                SqlConnection myConnection = new SqlConnection(myConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Connection = myConnection;

                myCommand.CommandText = "SELECT MAX(tagihan_id) AS tagihan_id FROM tr_tagihan";
                myCommand.CommandType = CommandType.Text;

                SqlDataAdapter myDataAdapter = new SqlDataAdapter();
                myDataAdapter.SelectCommand = myCommand;
                myDataAdapter.TableMappings.Add("Table", "tr_tagihan");
                myDataAdapter.Fill(myDataSet);

                maxid = Convert.ToString(myDataSet.Tables[0].Rows[0]["tagihan_id"]);

                if (maxid != "")
                {
                    //Substring digunakan untuk memecah string id_karyawan jadi KRY + 05
                    //Substring(3, 2) maksudnya, mulai dari digit ke 3 (K = 0, R = 1, Y = 2, 0 = 3) dan diambil 2 karakter (0 dan 5)
                    //Kemudian di convert ke int, sehingga 5 + 1 = 6
                    id_tagihan = Convert.ToInt32(maxid.Substring(3, 5)) + 1;
                    //Jika idbrg nya kurang dari 10 maka "KRY0" + 6 = "KRY06"
                    if (id_tagihan < 10)
                    {
                        id = "TGR0000" + id_tagihan;
                    }
                    //Jika idbrg nya lebih dari sama dengan 10 dan kurang dari 100 (10 - 99) maka "KRY" + idbrg, idbrg = 10 jadi KRY10
                    else if (id_tagihan >= 10 && id_tagihan < 100)
                    {
                        id = "TGR000" + id_tagihan;
                    }
                    else if (id_tagihan >= 100 && id_tagihan < 1000)
                    {
                        id = "TGR00" + id_tagihan;
                    }
                    else if (id_tagihan >= 1000 && id_tagihan < 10000)
                    {
                        id = "TGR0" + id_tagihan;
                    }
                }
                //Jika maxid kosong berarti tidak ada data karyawan, maka id dimulai dari KRY01
                else
                {
                    id = "TGR00001";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            return id;
        }


        private void dgAnggotaTerpilih_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void dgAnggotaTerpilih_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                Int32 selectedRowCount = dgAnggotaTerpilih.Rows.GetRowCount(DataGridViewElementStates.Selected);
                if (selectedRowCount > 0)
                {
                    for (int i = 0; i < selectedRowCount; i++)
                    {
                        dgAnggotaTerpilih.Rows.RemoveAt(dgAnggotaTerpilih.SelectedRows[0].Index);
                    }
                }
            }
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            
        }

        string nama_anggota = "";
        private void DeleteSelectedItem()
        {
            if (this.dgAnggotaAcara.SelectedRows.Count > 0)
            {


                DialogResult dr = MessageBox.Show("Anda yakin ingin menghapus data ini?", "Konfirmasi", MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    

                    string myConnectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                    SqlConnection myConnection = new SqlConnection(myConnectionstring);

                    // buka connection
                    myConnection.Open();

                    // membuat data adapter
                    SqlDataAdapter myAdapter = new SqlDataAdapter();

                    // update command
                    SqlCommand delete = new SqlCommand("sp_DeleteAnggotaAcara", myConnection);
                    delete.CommandType = CommandType.StoredProcedure;

                    delete.Parameters.Add("@user_nama", SqlDbType.VarChar, 10).Value = nama_anggota;
                    delete.Parameters.Add("@acara_id", SqlDbType.VarChar, 10).Value = id_acara;

                    myAdapter.UpdateCommand = delete;

                    // coba untuk update, jika sukses commit
                    // jika tidak roll back
                    try
                    {
                        delete.ExecuteNonQuery();

                        // tampilkan pesan jumlah baros data yang diupdate ke layar
                        MessageBox.Show(this, "Data berhasil dihapus! ", "Informasi",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgAnggotaAcara.Rows.RemoveAt(this.dgAnggotaAcara.SelectedRows[0].Index);
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Data gagal dihapus! : " + ex.Message);
                        // jika terjadi kegagalan dalam transaksi, batalkan semua (rollback)
                    }
                }
                else if (dr == DialogResult.No)
                {

                }


               
            }

            
        }

        private void btnHapusAll_Click(object sender, EventArgs e)
        {
            
        }

        private void dgAnggotaAcara_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                nama_anggota = dgAnggotaAcara.Rows[e.RowIndex].Cells["Anggota Acara"].Value.ToString();
            }
            catch
            {

            }
           
        }

        private void txtCariDataAcara_TextChanged(object sender, EventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            if (panelKiri.Width == 200)
            {
                panelKiri.Width = 22;
                back.Visible = false;
                next.Visible = true;

            }
            else
            {
                
            }
        }

        private void next_Click(object sender, EventArgs e)
        {
            if (panelKiri.Width == 22)
            {
                panelKiri.Width = 200;
                back.Visible = true;
                next.Visible = false;
            }
        }

        private void btnHapus_Click_1(object sender, EventArgs e)
        {
            try
            {
                dgAnggotaAcara.Rows[0].Selected = true;
                if (dgAnggotaAcara.Rows[0].Cells[0].Value == null)
                {
                    MessageBox.Show(this, "Data sudah kosong", "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                DeleteSelectedItem();
            }
            catch
            {
                MessageBox.Show(this, "Pilih Acara!", "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void btnHapusAll_Click_1(object sender, EventArgs e)
        {
            try
            {
                dgAnggotaAcara.Rows[0].Selected = true;
                if (dgAnggotaAcara.Rows[0].Cells[0].Value == null)
                {
                    MessageBox.Show(this, "Data sudah kosong", "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            catch
            {
                MessageBox.Show(this, "Pilih Acara!", "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
            DialogResult dr = MessageBox.Show("Anda yakin ingin menghapus semua anggota?", "Konfirmasi", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {

                string myConnectionstring = "integrated security=true;data source=.;initial catalog=PRG2_SILABI";
                SqlConnection myConnection = new SqlConnection(myConnectionstring);

                // buka connection
                myConnection.Open();

                // membuat data adapter
                SqlDataAdapter myAdapter = new SqlDataAdapter();

                // update command
                SqlCommand delete = new SqlCommand("sp_DeleteSemuaAnggotaAcara", myConnection);
                delete.CommandType = CommandType.StoredProcedure;


                delete.Parameters.Add("@acara_id", SqlDbType.VarChar, 10).Value = id_acara;

                myAdapter.UpdateCommand = delete;

                // coba untuk update, jika sukses commit
                // jika tidak roll back
                try
                {
                    delete.ExecuteNonQuery();

                    // tampilkan pesan jumlah baros data yang diupdate ke layar
                    MessageBox.Show(this, "Data berhasil dihapus! ", "Informasi",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    BindGrid();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Data gagal dihapus! : ");
                    // jika terjadi kegagalan dalam transaksi, batalkan semua (rollback)
                }
            }
            else if (dr == DialogResult.No)
            {

            }
        }

        private void UCtrTambahAnggotaAcara_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void UCtrTambahAnggotaAcara_MouseMove(object sender, MouseEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            btnTambah.Enabled = true;
            DataTable dt = new DataTable();
            dt.Columns.Add("Calon Anggota");
            DataGridViewColumn column = dgAnggotaTerpilih.Columns[0];
            column.Width = 150;

            foreach (DataGridViewRow row in dgSemuaAnggota.Rows)
            {

                bool isSelected = Convert.ToBoolean(row.Cells["checkBoxColumn"].Value);
                if (isSelected)
                {
                    dt.Rows.Add(row.Cells[1].Value);

                }
            }
            dgAnggotaTerpilih.DataSource = dt;
            tambah();
        }
    }
}
