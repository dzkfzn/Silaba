﻿namespace AsistenBendahara
{


    partial class USER_NAMA
    {
        partial class tableAdapter_newDataTable
        {
        }
    }
}

namespace AsistenBendahara.USER_NAMATableAdapters
{


    public partial class namaTableAdapter_new
    {
    }
}
