﻿namespace AsistenBendahara
{


    partial class silaba
    {
    }
}

namespace AsistenBendahara.silabaTableAdapters {
    
    
    public partial class lihatPengeluaranTableAdapter {
    }
}
