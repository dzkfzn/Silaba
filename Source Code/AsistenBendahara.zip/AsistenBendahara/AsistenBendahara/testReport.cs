﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsistenBendahara
{
    public partial class testReport : MetroFramework.Forms.MetroForm
    {
        public testReport()
        {
            InitializeComponent();
        }

        private void testReport_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pRG2_SILABIDataSet11.ms_acara' table. You can move, or remove it, as needed.
            this.ms_acaraTableAdapter.Fill(this.pRG2_SILABIDataSet11.ms_acara);
            // TODO: This line of code loads data into the 'ReportBaru.DataTable1' table. You can move, or remove it, as needed.

        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            this.DataTable1TableAdapter.Fill(this.ReportBaru.DataTable1, dtTglMulai.Value.ToShortDateString(), dtTglAkhir.Value.ToShortDateString(), cbJenisTagihan.SelectedValue.ToString());

            this.reportViewer1.RefreshReport();
        }

        private void materialFlatButton4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Lain_Lain.Login a = new Lain_Lain.Login();
            a.Show();
        }

        private void materialFlatButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Lain_Lain.Menu_Utama a = new Lain_Lain.Menu_Utama();
            a.Show();
        }

        private void materialFlatButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Lain_Lain.Menu_Utama a = new Lain_Lain.Menu_Utama();
            a.Show();
        }
    }
}
